// not stdp rule induced: 
// output neuron is not spike neuron.
// total strength of connections to post neurons is fixed.
// nmda5.cpp: 2014.8.13 output connection is randomly chosen

#include <iostream>
#include <vector>
#include <string>
#include <deque>
#include <set>
#include <algorithm>
#include <cmath>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <sstream>

using namespace std;
double const pi = 3.14159265;
double const e = 2.71828182;
double const h = 0.1;
double const dbl_eps=1.0e-10;

double const T = 0.3*1000.0;
double const Tstart = 0.1*1000.0;
double const Tend   = 0.2*1000.0;
double const Tflush = 0.20*1000.0;
double const Trwd   = 0.25*1000.0;  


//input
int const Ninp  = 100;
int const Nstim = 2000;
double const GEInp  = 0.1;
double const cEInp  = 0.2;
double const Rinp_max = 50;
double const Sigma_inp = 1;

// output
int const Nout  = 2;
int const NNout = 3000;
double const Goutave = 0.01;
double const VP  = 5;
double const g_inh = 0.1;
double const g_diff = 30;
double const p_out  = 0.3;
double const max_gfb = 10.0;

// plasticity
double const tstdp = 15; // time const of stdp
double const gelg = 0.1;
double const Kltp = 1;
double const Kltd = 1.5;
double const Kdcy = 5;
double const Max_elg=0.1;


//check point
double tmout;
double inv_t_elg;
double Fthr;
double const rna  = 0.1;


int const NE = 5000;
int const NI = 1000;
int const N = NE + NI;

double const cEE = 0.1;
double const cIE = 0.1;
double const cEI = 0.5;
double const cII = 0.5;

double sigma = 1.0;
//check point (original) double mu = log(0.2) + sigma*sigma;
double mu = log(0.05) + sigma*sigma;
double gm = 0.0098;

//check point 
// original GEI = 0.0018, GIE=0.018, GII=0.0025
double GEI = 0.002;
double GIE = 0.01;
double GII = 0.0025;
double Ga = 0.0010;

double VE = 0.0;
double VI = -80.0;
double VL = -70.0;
double Vr = -60.0;
//check point
//double Vth = -50.0;
double Vth_ext = -45.0;
double Vth_inh = -45.0;
double Vmax = 20.0;

double mub = 0.2;
double beta = 10.0;
double rhoEE = 0.25;
double rhoEI = 0.35;

//time constants 
double const tmE = 20.0;
double const tmI = 10.0;
//check point
//double ts = 2.0;
double ts = 8.0;
double tgaba = 8.0;
double tnmda = 100.0;
double tsout = 2.0;
//check point tref=1.0
double tref = 1.0;

//synaptic delay
int dEmax = 30;  // h dependent
int dEmin = 10;
int dImax = 15;
int dImin = 5;

//external input
double Vex = 10.0; //mV
double rex = 10.0; //Hz
double tinit = 1.0*1000.0; //msec

//external stimulus
double Vstm = 1.0; //mv;
double rstmo = 100.0;
double mustm = 0.5;
double sigstm = 0.1;
double GIstm = GEI;
double rIstm = 100.0;
double t1 = 300.0;

vector<double> dvec;
vector<int> ivec;
deque<double> ddeque;
deque<int> ideque;

typedef vector< vector<double> > DBLMAT;


double dice(){
	return rand()/(RAND_MAX + 1.0);
}

double ngn(){
	double u = dice(); double v = dice();
	return sqrt(-2.0*log(u))*cos(2.0*pi*v);
}

double VlogN(){
	double vtmp = exp( mu + sigma*ngn() );
	while( vtmp > Vmax ){
		vtmp = exp( mu + sigma*ngn() );
	}
	return vtmp;
}

double v_to_g(double v, double gm){
	return gm*v;
}	

double calc_qEE(int i){
	double xi = i/((double)NE);
	double qoEE = 1.0 + log( (1.0 + exp(-beta*mub))/(1.0 + exp(beta*(1.0-mub))) )/beta;
	double qEE = 1.0 + rhoEE*( 1.0/(1.0 + exp(beta*(xi-mub))) - qoEE );
	return qEE;
}

double calc_qEI(int i){
	double xi = i/((double)NE);
	double qoEI = 1.0 + log( (1.0 + exp(-beta*mub))/(1.0 + exp(beta*(1.0-mub))) )/beta;
	double qEI = 1.0 + rhoEI*( 1.0/(1.0 + exp(beta*(xi-mub))) - qoEI );
	return qEI;
}

double calc_rstm(int i){
	double xi = i/((double)NE);
	return rstmo*exp( -(xi-mustm)*(xi-mustm)/(2.0*sigstm*sigstm) )/sqrt( 2.0*pi*sigstm*sigstm );
}

double calc_nrnd(void){
  static int sw=0;
  static double t,u;

  if(sw==0){
    sw=1;
    t=sqrt(-2*log(1-dice())); u = 2*pi*dice();
    return t*cos(u);
  }
  else{
    sw=0;
    return t*sin(u);
  }

}


DBLMAT Change_Gout(DBLMAT &pG, DBLMAT &pElg, vector< int > Goutnetidx, double kelg){
  DBLMAT Gtmp;
  double Elgave[Nout];
  double Gtot[Nout];
  double Gtot_tmp[Nout];
  double ktmp=kelg;
  int cnt[Nout];

  for(int i=0; i<Nout; i++){
    Elgave[i]=0.0;
    Gtot[i]=0.0;
    cnt[i]=0;
  }
  for(int j=NE-NNout;j<NE;j++){
    if(Goutnetidx[j]==0){
      Elgave[0]+=pElg[0][j];
      Elgave[1]+=pElg[1][j];
      Gtot[0]+=pG[0][j];
      Gtot[1]+=pG[1][j];
      cnt[0]++;
      cnt[1]++;
    }
    else if(Goutnetidx[j]==1){
      Elgave[0]+=pElg[0][j];
      Gtot[0]+=pG[0][j];
      cnt[0]++;
    }
    else if(Goutnetidx[j]==2){
      Elgave[1]+=pElg[1][j];
      Gtot[1]+=pG[1][j];
      cnt[1]++;
    }
  }
  for(int i=0; i<Nout; i++){
    Elgave[i]/=cnt[i];
    Gtot[i]/=cnt[i];
  }

  for(int i=0; i<Nout; i++){
    Gtmp.push_back(dvec);
    for(int j=0; j<NE; j++){
      Gtmp[i].push_back(0.0);
    }
  }


  while(1){
      for(int j=NE-NNout;j<NE;j++){
	if(Goutnetidx[j]==0){
	  Gtmp[0][j]=pG[0][j]+ Kdcy*ktmp*(pElg[0][j]-Elgave[0])*pG[0][j];
	  if(Gtmp[0][j]<dbl_eps) Gtmp[0][j]=0.0;
	  if(Gtmp[0][j]>Max_elg) Gtmp[0][j]=Max_elg;

	  Gtmp[1][j]=pG[1][j]+ Kdcy*ktmp*(pElg[1][j]-Elgave[1])*pG[1][j];
	  if(Gtmp[1][j]<dbl_eps) Gtmp[1][j]=0.0;
	  if(Gtmp[1][j]>Max_elg) Gtmp[1][j]=Max_elg;
	}
	else if(Goutnetidx[j]==1){
	  Gtmp[0][j]=pG[0][j]+ Kdcy*ktmp*(pElg[0][j]-Elgave[0])*pG[0][j];
	  if(Gtmp[0][j]<dbl_eps) Gtmp[0][j]=0.0;
	  if(Gtmp[0][j]>Max_elg) Gtmp[0][j]=Max_elg;
	  Gtmp[1][j]=0.0;
	}
	else if(Goutnetidx[j]==2){
	  Gtmp[1][j]=pG[1][j]+ Kdcy*ktmp*(pElg[1][j]-Elgave[1])*pG[1][j];
	  if(Gtmp[1][j]<dbl_eps) Gtmp[1][j]=0.0;
	  if(Gtmp[1][j]>Max_elg) Gtmp[1][j]=Max_elg;
	  Gtmp[0][j]=0.0;
	}
	else{
	  Gtmp[0][j]=0.0;
	  Gtmp[1][j]=0.0;
	}
      }


      for(int i=0; i<Nout; i++) Gtot_tmp[i]=0.0;
      for(int j=NE-NNout;j<NE;j++){
	if(Goutnetidx[j]==0){
	  Gtot_tmp[0]+=Gtmp[0][j];
	  Gtot_tmp[1]+=Gtmp[1][j];
	}
	else if(Goutnetidx[j]==1) Gtot_tmp[0]+=Gtmp[0][j];
	else if(Goutnetidx[j]==2) Gtot_tmp[1]+=Gtmp[1][j];
      }
      for(int i=0; i<Nout; i++) Gtot_tmp[i]/=cnt[i];

      if(Gtot_tmp[0]>dbl_eps && Gtot_tmp[1]>dbl_eps)break;
      else   ktmp*=0.5;
  }


  for(int i=0; i<Nout; i++){
    for(int j=NE-NNout; j<NE; j++){
      Gtmp[i][j]*=Gtot[i]/Gtot_tmp[i];
    }
  }


  return Gtmp;
}

DBLMAT calc_fb(){
  DBLMAT gFB;

  for(int i=0;i<Nout;i++){
    gFB.push_back(dvec);
    for(int j=0;j<N;j++){
      if(dice()<cEE){
	if(j<NE) gFB[i].push_back(max_gfb*dice());
	else     gFB[i].push_back(-max_gfb*dice());
      }
      else gFB[i].push_back(0.0);
    }
  }

  return gFB;
}



DBLMAT calc_Ginp(){
  //vector< vector<double> > 
  //  vector< vector<double> > 
  DBLMAT Ginp;
  static double nratio=(double)Nstim/Ninp;

  for(int i = 0; i < Nstim; i++){
    Ginp.push_back(dvec);    
    for(int j = 0; j < Ninp; j++){
      Ginp[i].push_back(0.0);
      if(dice() < cEInp*exp(-(i-j*nratio)*(i-j*nratio)/(0.5*nratio*nratio))  && i != j) Ginp[i][j]=GEInp;
    }
  }

  return Ginp;
}

//vector< vector<double> > 
DBLMAT calc_G(){
  DBLMAT G;
//vector< vector<double> > 
	for(int i = 0; i < NE; i++){
		G.push_back(dvec);
		for(int j = 0; j < NE; j++){
			G[i].push_back(0.0);
			if( i != j && dice() < cEE ) G[i][j] = v_to_g(VlogN(), gm);//*calc_qEE(i);
		}
		for(int j = NE; j < N; j++){
			G[i].push_back(0.0);
			if( dice() < cEI ) G[i][j] = GEI;//*calc_qEI(i);
		}
	}
	for(int i = NE; i < N; i++){
		G.push_back(dvec);
		for(int j = 0; j < NE; j++){
			G[i].push_back(0.0);
			if( dice() < cIE ) G[i][j] = GIE;
		}
		for(int j = NE; j < N; j++){
			G[i].push_back(0.0);
			if( i != j && dice() < cII ) G[i][j] = GII;
		}
	}
	return G;
}

vector< vector<int> > calc_d(){
  vector< vector<int> > d;
	for(int i = 0; i < NE; i++){
		d.push_back(ivec);
		for(int j = 0; j < NE; j++) d[i].push_back( dEmin + (int)floor( (dEmax-dEmin)*dice() ) );
		for(int j = NE; j < N; j++) d[i].push_back( dImin + (int)floor( (dImax-dImin)*dice() ) );
	}
	for(int i = NE; i < N; i++){
		d.push_back(ivec);
		for(int j = 0; j < NE; j++) d[i].push_back( dEmin + (int)floor( (dEmax-dEmin)*dice() ) );
		for(int j = NE; j < N; j++) d[i].push_back( dImin + (int)floor( (dImax-dImin)*dice() ) );
	}
	return d;
}


vector< vector<int> > calc_dinp(){
	vector< vector<int> > dinp;
	for(int i = 0; i < Nstim; i++){
		dinp.push_back(ivec);
		for(int j = 0; j < Ninp; j++) dinp[i].push_back( dEmin + (int)floor( (dEmax-dEmin)*dice() ) );
	}
	return dinp;
}


vector<double> rk_vgEI_nmda(double v,double gE,double gI,double gnmda, double tm, double exI){
  double vp;
  vector<double> k1;
  k1.push_back( -(v-VL+exI)/tm - (gE+gnmda)*(v-VE)- gI*(v-VI) );
  k1.push_back( -gE/ts ); 
  k1.push_back( -gI/tgaba );
  k1.push_back( -gnmda/tnmda );
  vector<double> k2; vp = (v+0.5*h*k1[0]);
  k2.push_back( -(vp-VL+exI)/tm - (gE+0.5*h*k1[1]+gnmda+0.5*h*k1[3])*(vp-VE) - (gI+0.5*h*k1[2])*(vp-VI) );
  k2.push_back( -(gE+0.5*h*k1[1])/ts ); 
  k2.push_back( -(gI+0.5*h*k1[2])/tgaba );
  k2.push_back( -(gnmda+0.5*h*k1[3])/tnmda );
  vector<double> k3; vp = (v+0.5*h*k2[0]);
  k3.push_back( -(vp-VL+exI)/tm - (gE+0.5*h*k2[1]+gnmda+0.5*h*k2[3])*(vp-VE) - (gI+0.5*h*k2[2])*(vp-VI) );
  k3.push_back( -(gE+0.5*h*k2[1])/ts ); 
  k3.push_back( -(gI+0.5*h*k2[2])/tgaba );
  k3.push_back( -(gnmda+0.5*h*k2[3])/tnmda );
  vector<double> k4; vp = (v+1.0*h*k3[0]);
  k4.push_back( -(vp-VL+exI)/tm - (gE+1.0*h*k3[1]+gnmda+1.0*h*k3[3])*(vp-VE) - (gI+1.0*h*k3[2])*(vp-VI) );
  k4.push_back( -(gE+1.0*h*k3[1])/ts ); 
  k4.push_back( -(gI+1.0*h*k3[2])/tgaba );
  k4.push_back( -(gnmda+1.0*h*k3[3])/tnmda );
  vector<double> vgEI;
  vgEI.push_back( v     + h*(k1[0] + 2.0*k2[0] + 2.0*k3[0] + k4[0])/6.0 );
  vgEI.push_back( gE    + h*(k1[1] + 2.0*k2[1] + 2.0*k3[1] + k4[1])/6.0 );
  vgEI.push_back( gI    + h*(k1[2] + 2.0*k2[2] + 2.0*k3[2] + k4[2])/6.0 );
  vgEI.push_back( gnmda + h*(k1[3] + 2.0*k2[3] + 2.0*k3[3] + k4[3])/6.0 );
  return vgEI;
}


vector<double> rk_vgEI(double v,double gE,double gI, double tm, double exI){
  double vp;
  vector<double> k1;
  k1.push_back( -(v-VL+exI)/tm - gE*(v-VE) - gI*(v-VI) );
  k1.push_back( -gE/ts ); 
  k1.push_back( -gI/tgaba );
  vector<double> k2; vp = (v+0.5*h*k1[0]);
  k2.push_back( -(vp-VL+exI)/tm - (gE+0.5*h*k1[1])*(vp-VE) - (gI+0.5*h*k1[2])*(vp-VI) );
  k2.push_back( -(gE+0.5*h*k1[1])/ts ); 
  k2.push_back( -(gI+0.5*h*k1[2])/tgaba );
  vector<double> k3; vp = (v+0.5*h*k2[0]);
  k3.push_back( -(vp-VL+exI)/tm - (gE+0.5*h*k2[1])*(vp-VE) - (gI+0.5*h*k2[2])*(vp-VI) );
  k3.push_back( -(gE+0.5*h*k2[1])/ts ); 
  k3.push_back( -(gI+0.5*h*k2[2])/tgaba );
  vector<double> k4; vp = (v+1.0*h*k3[0]);
  k4.push_back( -(vp-VL+exI)/tm - (gE+1.0*h*k3[1])*(vp-VE) - (gI+1.0*h*k3[2])*(vp-VI) );
  k4.push_back( -(gE+1.0*h*k3[1])/ts ); 
  k4.push_back( -(gI+1.0*h*k3[2])/tgaba );
  vector<double> vgEI;
  vgEI.push_back( v + h*(k1[0] + 2.0*k2[0] + 2.0*k3[0] + k4[0])/6.0 );
  vgEI.push_back( gE + h*(k1[1] + 2.0*k2[1] + 2.0*k3[1] + k4[1])/6.0 );
  vgEI.push_back( gI + h*(k1[2] + 2.0*k2[2] + 2.0*k3[2] + k4[2])/6.0 );
  return vgEI;
}






void calc(int ik, int ilmax){
  srand(191);

  //  vector< vector<double> > 
  DBLMAT G    = calc_G();
  //  vector< vector<double> > 
  DBLMAT Ginp = calc_Ginp();
  vector< vector<int> >    d    = calc_d();
  vector< vector<int> >    dinp = calc_dinp();
  DBLMAT gFB  = calc_fb();

	vector< vector<int> > Goutidx;
	for(int i = 0; i < N; i++){
	  Goutidx.push_back(ivec);
	  for(int j = 0; j < N; j++){
	    if( G[j][i] > 0.0 ) Goutidx[i].push_back(j);
	  }
	}

	vector< vector<int> > Ginpidx;
	for(int i = 0; i < Ninp; i++){
	  Ginpidx.push_back(ivec);
	  for(int j = 0; j < Nstim; j++){
	    if( Ginp[j][i] > 0.0 ) Ginpidx[i].push_back(j);
	  }
	}

	//	vector< vector<double> >
	DBLMAT Gout,Elg;  // output filter
	for(int i = 0; i<Nout; i++){
	  Gout.push_back(dvec);
	  Elg.push_back(dvec);
	  for(int j=0; j<NE; j++){
	    if(j>NE-NNout && dice()<p_out)Gout[i].push_back(Goutave*dice());
	    else Gout[i].push_back(0.0);
	    Elg[i].push_back(0.0);
	  }
	}
	vector<int> Goutnetidx;
	for(int j=0; j<NE; j++){
	  if(Gout[0][j]>0.0 && Gout[1][j]>0.0)Goutnetidx.push_back(0);
	  else if(Gout[0][j]>0.0 && Gout[1][j]<=0.0)Goutnetidx.push_back(1);
	  else if(Gout[0][j]<=0.0 && Gout[1][j]>0.0)Goutnetidx.push_back(2);
	  else if(Gout[0][j]<=0.0 && Gout[1][j]<=0.0)Goutnetidx.push_back(3);
	  else{
	    cout << "ERROR in generation of Gout!!" << endl; 
	    exit(1);
	  }
	}


	ostringstream ossw; 
	//	ossw << "dbw1-5_k" << ik << ".txt2"; 
	//	string fstrw = ossw.str(); ofstream ofsw; ofsw.open( fstrw.c_str() );

	ostringstream ossd; 
	ossd << "dbd6" << "-Fthr" << Fthr <<"-t" << tmout <<  "-te" << inv_t_elg << Kdcy <<"-Si"<<Sigma_inp<< max_gfb<<".txt6"; 
	string fstrd = ossd.str(); ofstream ofsd; ofsd.open( fstrd.c_str() );
	ostringstream osss; 
	osss << "dbs6" << "-Fthr" << Fthr <<"-t" << tmout <<  "-te" << inv_t_elg << Kdcy <<"-Si"<<Sigma_inp<<max_gfb<<".txt6"; 
	string fstrs = osss.str(); ofstream ofss; ofss.open( fstrs.c_str() );

	/*
	for(int i = 0; i < N; i++){
		for(int j = 0; j < N; j++) ofsw << G[i][j] << " ";
		ofsw << endl;
	}
	for(int i = 0; i < N; i++){
		for(int j = 0; j < N; j++) ofsd << d[i][j] << " ";
		ofsd << endl;
	}
	*/

	for(int il = 0; il < ilmax; il++){
		ostringstream ossr; 
		//		ossr << "dbr1_l" << il << "-GEI" << GEI <<  "-GIE" << GIE << "-GII" << GII << "-" << tgaba << "-" << Vth_ext << "-" << Vex <<".non-nrm-Max_elg<<.txt6"; 
		ossr << "dbr6_l" << il << "-Fthr" << Fthr <<"-t" << tmout <<  "-te" << inv_t_elg << Kdcy <<"-Si"<<Sigma_inp<< max_gfb<<".txt6"; 
		string fstrr = ossr.str(); ofstream ofsr; ofsr.open( fstrr.c_str() );
		ofsr.precision(10);	

		ostringstream osst; 
		osst << "dbt6_l" << il << "-Fthr" << Fthr <<"-t" << tmout <<  "-te" << inv_t_elg << Kdcy  <<"-Si"<<Sigma_inp<< max_gfb<<".txt6"; 

		string fstrt = osst.str(); ofstream ofst; ofst.open( fstrt.c_str() );
		

		vector <double> rinp;
		for(int i = 0; i < Ninp; i++){
		  //		  double dtmp=Vinp_max*sin((((double)i/Nstim)-(il%2))*pi);
		  //check point
		  //		  double dtmp=Rinp_max*sin(((2*(double)i/Ninp)-(il%2))*pi);
		  double xtmp=(double)i/Ninp;
		  double dtmp=Rinp_max*exp(-(xtmp-(0.25+0.5*(il%2)))*(xtmp-(0.25+0.5*(il%2)))/(2*0.15*0.15*Sigma_inp*Sigma_inp))/Sigma_inp;
		  dtmp=(dtmp>0 ? dtmp:0);
		  rinp.push_back(dtmp);
		}


		vector<double> v,gE,gI,gnmda;
		for(int i = 0; i < N; i++){
		  v.push_back(VL); gE.push_back(0.0); gI.push_back(0.0); gnmda.push_back(0.0);
		}
		vector< deque<double> > uE,uI; //delayed input
		for(int i = 0; i < N; i++){
			uE.push_back(ddeque); uI.push_back(ddeque);
			for(int j = 0; j < dEmax+2; j++) uE[i].push_back(0.0);
			for(int j = 0; j < dImax+2; j++) uI[i].push_back(0.0);
		}

		for(int i=0; i<Nout; i++){
		  for(int j=0; j<NE; j++)  Elg[i][j]=0.0;
		}



		vector<double> tm; //membrane time const
		for(int i = 0; i < NE; i++) tm.push_back(tmE);
		for(int i = NE; i < N; i++) tm.push_back(tmI);
		vector<double> Vth; //membrane time const
		for(int i = 0; i < NE; i++) Vth.push_back(Vth_ext);
		for(int i = NE; i < N; i++) Vth.push_back(Vth_inh);

		vector<double> spts; //previous spike time
		for(int i = 0; i < N; i++) spts.push_back(-1000.0);
		vector<double> spts_out; //previous spike time
		for(int i = 0; i < Nout; i++) spts_out.push_back(-1000.0);
	
		vector<double> rstms; // firing rates of external stimulus
		for(int i = 0; i < NE; i++) rstms.push_back( calc_rstm(i) );

		vector<double> vgEI;
		double xout[Nout],xoutave[Nout],rout[Nout],gO[Nout],routave[Nout];
		for(int i=0;i<Nout;i++) xout[i]=0.0;
		for(int i=0;i<Nout;i++) xoutave[i]=0.0;
		for(int i=0;i<Nout;i++) rout[i]=0.0;
		for(int i=0;i<Nout;i++) routave[i]=0.0;
		for(int i=0;i<Nout;i++) gO[i]=0.0;




		for(double t = 0.0; t < T+h; t += h){


		  // proc of output
		  for(int i=0;i<Nout;i++){
		    if(dice()<10*rex/(1000.0/h)) gO[i]+=Goutave;
		    rout[i]   += (-rout[i]+gO[i]/h)*h/tmout;   //gO [kHz]
		    routave[i] += (-routave[i]+rout[i])*h/(tmout*10);
		    gO[i]     =0;
		      
		    for(int j=NE-NNout;j<NE;j++){
		      Elg[i][j]+=-Elg[i][j]*inv_t_elg*h;
		    }
		  }
		  for(int i=0;i<Nout;i++){
		    xout[i]   =exp(g_diff*rout[i])/(exp(g_diff*rout[0])+exp(g_diff*rout[1]));
		    xoutave[i]=exp(g_diff*routave[i])/(exp(g_diff*routave[0])+exp(g_diff*routave[1]));
		  }

		  // proc of input
		  if(t>Tstart && t<Tend){
		    for(int i = 0; i < Ninp; i++){
		      if( dice() < rinp[i]/(1000.0/h)){		    
			for(int jidx = 0; jidx < Ginpidx[i].size(); jidx++){
			  int j = Ginpidx[i][jidx];
			  uE[j][ dinp[j][i] ] += Ginp[j][i];
			}
		      }
		    }
		  }


		  if((int)(t/h)%10==0)
		    ofst << t << " " << rout[0] << " " << rout[1] << " " << xout[0] << " " << xout[1] << " " << Elg[0][3278] << " " << Elg[1][3278] << " " << Elg[0][3370] << " " << Elg[1][3370] << " " << Elg[0][3709] << " " << Elg[1][3709] << " " << Elg[0][4913] << " " << Elg[1][4913] << endl;
		  // terminal condition
		  //check point		  if(t>Trwd && (vout[0] > Fthr || vout[1] > Fthr) ){
		  if(t>Trwd && (fabs(xout[0] - xout[1]) > Fthr) ){
		    ofst << t << " " << rout[0] << " " << rout[1] << " " << xout[0] << " " << xout[1] << " " << Elg[0][3278] << " " << Elg[1][3278] << " " << Elg[0][3370] << " " << Elg[1][3370] << " " << Elg[0][3709] << " " << Elg[1][3709] << " " << Elg[0][4913] << " " << Elg[1][4913] << endl;
		    break;
		  }
		  


		  
		  for(int i = 0; i < N; i++){
		    if( t < tinit && dice() < rex/(1000.0/h)){
		      gE[i]    += v_to_g(Vex,gm);
		      gnmda[i] += rna*v_to_g(Vex,gm);
		    }
		    /*		    if( t > Tstart && t< Tend && i < Nstim*2 && dice() < rinp/(1000.0/h)){
		      gE[i]    += v_to_g(Vinp[i],gm);
		      gnmda[i] += rna*v_to_g(Vinp[i],gm);
		      }*/
		    //if( t1 < t && i < NE && dice() < rstms[i]/(1000.0/h) ) gE[i] += v_to_g(Vstm,gm);
		    //if( t1 < t && i < NE && dice() < rIstm/(1000.0/h) ) gI[i] += GIstm;
		    gE[i] += uE[i][0]; gI[i] += uI[i][0]; gnmda[i]+=rna*uE[i][0];
		    uE[i].pop_front();    uE[i].push_back(0.0);
		    uI[i].pop_front();    uI[i].push_back(0.0);			
		    if(i<NE){
		      vgEI = rk_vgEI_nmda(v[i],gE[i],gI[i],gnmda[i],tm[i],gFB[0][i]*xout[0]+gFB[1][i]*xout[1]);
		      v[i] = vgEI[0]; gE[i] = vgEI[1]; gI[i] = vgEI[2]; gnmda[i]=vgEI[3];
		    }
		    else{
		      vgEI = rk_vgEI(v[i],gE[i],gI[i],tm[i],gFB[0][i]*xout[0]+gFB[1][i]*xout[1]);
		      v[i] = vgEI[0]; gE[i] = vgEI[1]; gI[i] = vgEI[2]; gnmda[i]=0.0;
		    }


		    if( t - spts[i] < tref ){
		      v[i] = VL;
		    }else{
		      // flush input to reset a subset of neurons
		      /*		      if(t>=Tflush && t<Tflush+h && i<Nstim){
			v[i]=Vth+0.1;
		      }
		      */

		      if( v[i] > Vth[i] ){
			ofsr << t << " " << i << endl; spts[i] = t; v[i] = Vr;
			
			//check point
			//			if(t>Tstart){
			if(NE-NNout<=i && i<NE){
			  if(Goutnetidx[i]==0){
			    gO[0]+=Gout[0][i];
			    gO[1]+=Gout[1][i];
			    Elg[0][i]+=Kltp*xout[0];
			    Elg[1][i]+=Kltp*xout[1];
			  }
			  else if(Goutnetidx[i]==1){
			    gO[0]+=Gout[0][i];
			    Elg[0][i]+=Kltp*xout[0];
			  }
			  else if(Goutnetidx[i]==2){
			    gO[1]+=Gout[1][i];
			    Elg[1][i]+=Kltp*xout[1];
			  }

			}

			  //			}
			

			for(int jidx = 0; jidx < Goutidx[i].size(); jidx++){
			  int j = Goutidx[i][jidx];
			  if( i < NE ){
			    if( j < NE ){
			      if( dice() > Ga/(G[j][i] + Ga) ) uE[j][ d[j][i] ] += G[j][i];
			    }else{
			      uE[j][ d[j][i] ] += G[j][i];
			    }
			  }else{
			    uI[j][ d[j][i] ] += G[j][i];
			  }
			}
		      }
		    }
		  }
		  if( ((int)floor(t/h))%1000 == 0 ){
		    //		    cout << t << endl;
		    double nearestspiketime = 0.0;
		    for(int i = 0; i < N; i++){
		      if( spts[i] > nearestspiketime ) nearestspiketime = spts[i];
		    }
		    if( t-nearestspiketime > 1000.0 ) break;
		  }
		}

		

		//check point	
		int Rwd;
		if(xout[il%2]-xout[(il+1)%2]>Fthr) Rwd = 1;
		else             Rwd = -1;

		ofss << il << " " << Rwd << endl;

		Gout=Change_Gout(Gout,Elg,Goutnetidx,Rwd*gelg);

		//check point
		for(int i=NE-NNout;i<NE;i++){
		  ofsd << i << " " << Gout[0][i] << " " << Gout[1][i] << " " << Elg[0][i] << " " << Elg[1][i] << endl;
		}
		ofsd << endl << endl;		

		
	}
		
}

void simul(int ik, int ilmax){
	calc(ik,ilmax);
}

int main(int argc, char **argv){
	srand((unsigned int)time(NULL));
	int ik = 0; int ilmax = 0;
	if(argc > 1) ik = atoi(argv[1]);
	if(argc > 2) ilmax = atoi(argv[2]);
	if(argc > 3) tmout = atof(argv[3]);
	if(argc > 4) inv_t_elg = atof(argv[4]);
	if(argc > 5) Fthr = atof(argv[5]);

	simul(ik,ilmax);
	return 0;
}


