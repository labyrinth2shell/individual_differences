import numpy as np
import pylab as pl
from scipy import optimize

trj=np.zeros((7,50,601,2))

data=np.loadtxt("rbt56_fb_rnd_norm25-300_l00.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205")
trj[0]=data[:,1:].reshape((50,601,2))

for i in range(1,7):
    data=np.loadtxt("rbt56_fb_rnd_norm25-300_l0.%d0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % i)
    trj[i]=data[:,1:].reshape((50,601,2))


ave_trj=np.zeros((7,50,200,2))
for i in range(7):
    for j in range(50):
        for k in range(149):
            ave_trj[i,j,k]=np.mean(trj[i,j,4*k:4*k+4],axis=0)




def tmp_func(trj):
    t_init=350
    t_end=500
    thrs=0.05
    n_init=len(trj)
    flg=-1
    
    beh_list=[[],[],[]]
    time_list=[[],[],[]]
    time1_list=[]

    for j in range(n_init):

        flg=-1
        for i in range(t_init,t_end):
            if(flg==-1 and trj[j,i,0]-trj[j,i,1]>thrs):
                beh_list[0].append(j)
                time_list[0].append(i)
                flg=0
            elif(flg==-1 and trj[j,i,1]-trj[j,i,0]>thrs):
                beh_list[1].append(j)
                time_list[1].append(i)
                flg=0

            if np.fabs(trj[j,i,0]-trj[j,i,1])>0.095:
                time1_list.append([j,i])
                break
                
            if(flg==-1 and i == t_end-1):
                beh_list[2].append(j)
                time_list[2].append(i)

    return beh_list,time_list,np.array(time1_list)
        
