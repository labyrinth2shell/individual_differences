#!/opt/local/bin/python

# discrimination vector bewteen tmpdata1 and tmpdata2 read from str

import time
import pylab as pl
import numpy as np
import scipy as sp
import scipy.io as io
import scipy.sparse as sparse
import sys
import string as ST
import random 


flt_eps = 0.0000001

g=8
scale_fb=1
gns=0.05
ninit=9
nlrn=999
Ntrial=50
Dsmp=10


Flg_gen_data=0
Flg_plt=1
Flg_ipt=1


""" testdata
mu=np.random.normal(size=2)
sigma=np.random.normal(size=(2,2))

x0=np.random.multivariate_normal(mu,sigma,100)

mu=np.random.normal(size=2)
sigma=np.random.normal(size=(2,2))
sigma=sigma.T.dot(sigma)
x1=np.random.multivariate_normal(mu,sigma,100)"""




def FDA(data1,data2):

    non_zero_cell1=ex_zero(data1)
    non_zero_cell2=ex_zero(data2)
    non_zero_cell=list(set(non_zero_cell1) & set(non_zero_cell2))
    
    data1=data1[non_zero_cell,:]
    data2=data2[non_zero_cell,:]


    cov_data1=np.cov(data1)
    cov_data2=np.cov(data2)

#print len(tmpdata1),len(tmpdata1[0])
#print len(cov_data1)
    ave1=np.mean(data1,axis=1)
    ntmp=len(ave1)
    ave1=ave1.reshape(ntmp,1)
    ave2=np.mean(data2,axis=1)
    ntmp=len(ave2)
    ave2=ave2.reshape(ntmp,1)

    Sw=cov_data1+cov_data2
    Wopt=np.dot(np.linalg.inv(Sw),(ave2-ave1))
    Sb=np.dot((ave2-ave1),(ave2-ave1).T)

#    print np.dot(np.dot(Wopt.T,Sw),Wopt),np.dot(np.dot(Wopt.T,Sb),Wopt)

    J = np.dot(np.dot(Wopt.T,Sb),Wopt)/np.dot(np.dot(Wopt.T,Sw),Wopt)

    return J,Wopt,non_zero_cell


# for reservoir  network
def FDA2(data1,data2,cell_rank,n_cell):

    data1=data1[cell_rank[-n_cell:],:]
    data2=data2[cell_rank[-n_cell:],:]

    cov_data1=np.cov(data1)
    cov_data2=np.cov(data2)

#print len(tmpdata1),len(tmpdata1[0])
#print len(cov_data1)
    ave1=np.mean(data1,axis=1)
    ntmp=len(ave1)
    ave1=ave1.reshape(ntmp,1)

    ave2=np.mean(data2,axis=1)
    ntmp=len(ave2)
    ave2=ave2.reshape(ntmp,1)

#    Sw=cov_data1+cov_data2+0.001*(np.random.rand(n_cell*n_cell).reshape(n_cell,n_cell)-0.5)
    Sw=cov_data1+cov_data2
#    return Sw,np.linalg.inv(Sw)
#    Wopt=np.dot(np.linalg.inv(Sw),(ave2-ave1))
    tmp=np.linalg.matrix_rank(Sw)
    if(tmp<n_cell):
        return 1,0,0,0

    Wopt=np.linalg.solve(Sw,(ave2-ave1))
    Sb=np.dot((ave2-ave1),(ave2-ave1).T)

    J = np.dot(np.dot(Wopt.T,Sb),Wopt)/np.dot(np.dot(Wopt.T,Sw),Wopt)

    return 0,J,Wopt,cell_rank



def FDA1(data1,data2,Wopt,non_zero_cell):
    data1=data1[non_zero_cell,:]
    data2=data2[non_zero_cell,:]

    data1_prj=np.dot(Wopt,data1)
    data2_prj=np.dot(Wopt,data2)

    ave1=np.mean(data1_prj,axis=1)
    ave2=np.mean(data2_prj,axis=1)
    D_in=np.mean((ave2[:]-ave1[:])*(ave2[:]-ave1[:]))

    var1=np.var(data1_prj)
    var2=np.var(data2_prj)
    D_btw=var1+var2

    J=D_in/D_btw

    return J





def ex_zero(data):
    n_cell=len(data[:,0])
    data_tmp=np.zeros(len(data[0,:]))
    non_zero_cell=[]

    for i in range(n_cell):
        if np.sum(data[i,:])!=0.:
            data_tmp=np.vstack((data_tmp,data[i,:]))
            non_zero_cell.append(i)

    return non_zero_cell



def gen_FDA_mat(rate,list_tone):
    FDA_mat=np.zeros((8,2,7))
    t_start=10

    for i in range(8):
        data1=np.mean(rate[i][:,list_tone[i][0],t_start:],axis=2)
        data2=np.mean(rate[i][:,list_tone[i][6],t_start:],axis=2)
        J,Wopt,non_zero_cell=FDA(data1,data2)
        for j in range(7):
            data3=np.mean(rate[i][:,list_tone[i][j],t_start:],axis=2)
            FDA_mat[i,0,j]=FDA1(data1,data3,Wopt.T,non_zero_cell)
            FDA_mat[i,1,j]=FDA1(data2,data3,Wopt.T,non_zero_cell)

    return FDA_mat
 


def get_tmp_curve(irat):

    tmp=fc.get_exp_data(irat,2)
    n_cell=len(tmp[0][:,0,0])
    n_trial=len(tmp[0][0,:,0])
    n_bin=len(tmp[0][0,0,:])

    data1=np.mean(tmp[0][:,list(set(tmp[1][6]) & set(tmp[2][0])),10:20],axis=2)
    data2=np.mean(tmp[0][:,list(set(tmp[1][0]) & set(tmp[2][1])),10:20],axis=2)
    flg,J,Wopt,cell_rank=FDA2(data1,data2,range(n_cell),n_cell)

    fda=np.zeros((n_trial,n_bin))
    tmp_curve=np.zeros(7)
    for i in range(7):
        tmp_curve[i]=pl.mean(fda[tmp[1][i],10:20])


    return tmp_curve,tmp[3]
