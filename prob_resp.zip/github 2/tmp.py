import numpy as np
import pylab as pl

import gen_fig_rnd as gr

import sys

argvs = sys.argv
Si=float(argvs[1])


n_smp=1000
s_rate=0.6
n_dim=1100
diff=0.02
n_net=30




beh=np.zeros((n_net,7,2))
for i in range(n_net):
    for j in range(7):
        _,tmp,tmp1,_=gr.get_behav1(i+1,0.1*j,Si,20,n_smp,0,diff)
        beh[i,j,0]=len(tmp)
        beh[i,j,1]=len(tmp1)


suc_list=[]
for i in range(n_net):
    if beh[i,0,0]>s_rate*n_smp and beh[i,6,1]>s_rate*n_smp:
        suc_list.append((i+1))

fda_dyn,distr,t_end,listL,listR=gr.get_FDA_dyn1(suc_list,Si,n_smp,n_dim,diff)


strtmp="fda_dyn%g.npy" % Si
np.save(strtmp,fda_dyn)

strtmp="t_end%g.npy" % Si
np.save(strtmp,t_end)

for j in range(len(suc_list)):
    strtmp="distr%g-%d.npy" % (Si,suc_list[j])
    np.save(strtmp,distr[j])


strtmp="listL%g.dat" % Si
f=open(strtmp,"w")

for i in range(len(listL)):
    for j in range(7):
        for k in listL[i][j]:
            f.write("%d " % k)
        f.write("\n")

f.close()


strtmp="listR%g.dat" % Si
f=open(strtmp,"w")

for i in range(len(listR)):
    for j in range(7):
        for k in listR[i][j]:
            f.write("%d " % k)
        f.write("\n")

f.close()

