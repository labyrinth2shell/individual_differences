// not stdp rule induced: 
// output neuron is not spike neuron.
// corresponding to lognormal-nmda5-3.cpp
// corresponding to lognormal-nmda5-3_fb.cpp
// 

#include <iostream>
#include <vector>
#include <string>
#include <deque>
#include <set>
#include <algorithm>
#include <cmath>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <sstream>


/********************************************************************************/
/********************************************************************************/
/******                                                                     *****/
/******              The following program is Mersenne Twister              *****/
/******                                                                     *****/
/********************************************************************************/
/********************************************************************************/
/* Period parameters */  
#define N1 624
#define M 397
#define MATRIX_A 0x9908b0dfUL   /* constant vector a */
#define UPPER_MASK 0x80000000UL /* most significant w-r bits */
#define LOWER_MASK 0x7fffffffUL /* least significant r bits */

static unsigned long mt[N1]; /* the array for the state vector  */
static int mti=N1+1; /* mti==N+1 means mt[N1] is not initialized */

/* initializes mt[N1] with a seed */
void init_genrand(unsigned long s)
{
    mt[0]= s & 0xffffffffUL;
    for (mti=1; mti<N1; mti++) {
        mt[mti] = 
	    (1812433253UL * (mt[mti-1] ^ (mt[mti-1] >> 30)) + mti); 
        /* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
        /* In the previous versions, MSBs of the seed affect   */
        /* only MSBs of the array mt[].                        */
        /* 2002/01/09 modified by Makoto Matsumoto             */
        mt[mti] &= 0xffffffffUL;
        /* for >32 bit machines */
    }
}

/* initialize by an array with array-length */
/* init_key is the array for initializing keys */
/* key_length is its length */
/* slight change for C++, 2004/2/26 */
void init_by_array(unsigned long init_key[], int key_length)
{
    int i, j, k;
    init_genrand(19650218UL);
    i=1; j=0;
    k = (N1>key_length ? N1 : key_length);
    for (; k; k--) {
        mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1664525UL))
          + init_key[j] + j; /* non linear */
        mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
        i++; j++;
        if (i>=N1) { mt[0] = mt[N1-1]; i=1; }
        if (j>=key_length) j=0;
    }
    for (k=N1-1; k; k--) {
        mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1566083941UL))
          - i; /* non linear */
        mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
        i++;
        if (i>=N1) { mt[0] = mt[N1-1]; i=1; }
    }

    mt[0] = 0x80000000UL; /* MSB is 1; assuring non-zero initial array */ 
}

/* generates a random number on [0,0xffffffff]-interval */
unsigned long genrand_int32(void)
{
    unsigned long y;
    static unsigned long mag01[2]={0x0UL, MATRIX_A};
    /* mag01[x] = x * MATRIX_A  for x=0,1 */

    if (mti >= N1) { /* generate N1 words at one time */
        int kk;

        if (mti == N1+1)   /* if init_genrand() has not been called, */
            init_genrand(5489UL); /* a default initial seed is used */

        for (kk=0;kk<N1-M;kk++) {
            y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
            mt[kk] = mt[kk+M] ^ (y >> 1) ^ mag01[y & 0x1UL];
        }
        for (;kk<N1-1;kk++) {
            y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
            mt[kk] = mt[kk+(M-N1)] ^ (y >> 1) ^ mag01[y & 0x1UL];
        }
        y = (mt[N1-1]&UPPER_MASK)|(mt[0]&LOWER_MASK);
        mt[N1-1] = mt[M-1] ^ (y >> 1) ^ mag01[y & 0x1UL];

        mti = 0;
    }
  
    y = mt[mti++];

    /* Tempering */
    y ^= (y >> 11);
    y ^= (y << 7) & 0x9d2c5680UL;
    y ^= (y << 15) & 0xefc60000UL;
    y ^= (y >> 18);

    return y;
}

/* generates a random number on [0,0x7fffffff]-interval */
long genrand_int31(void)
{
    return (long)(genrand_int32()>>1);
}

/* generates a random number on [0,1]-real-interval */
double genrand_real1(void)
{
    return genrand_int32()*(1.0/4294967295.0); 
    /* divided by 2^32-1 */ 
}
///******************************************************/////
///******************************************************/////
///******************************************************/////

/*
#include "MersenneTwister.h"
CMersenneTwister MTwt;
*/
#define ADR "/data02/home/kurikawa/"


using namespace std;
double const pi = 3.14159265;
double const e = 2.71828182;
double const h = 0.1;
double const dbl_eps=1.0e-10;

//check point
double const T = 1.1*1000.0;
double const Tstart = 0.1*1000.0;
double const Tend   = 0.3*1000.0;
double const Trwd   = 0.35*1000.0;  
double const T_flsh_st = 0.05*1000.0;
double const T_flsh_end = 0.075*1000.0;
/*
double const T = 0.5*1000.0;
double const Tstart = 0.1*1000.0;
double const Tend   = 0.5*1000.0;
double const Trwd   = 0.6*1000.0;  
*/




//input
int const Ninp  = 100;
int const Nstim = 2000;
//check point 2015.12.17
double const GEInp  = 0.02;
double const cEInp  = 0.01;
double const Rinp_max = 100;
double Sigma_inp;
double scl_fac;

// fb
int    const FLG_fb = 2;  // 0: uniform random, 1: normal random
//double const GEfb  = 0.05;
double GEfb  = 0.02;
double cEfb  = 0.2;
double sigma_fb = 1.5;
double const amp_fb = 1000.0; // rout coded in rate -> firing raterout[i]



// output
int const Nout  = 2;
int const NNout = 3000;
double const p_out = 0.3;  // only for file name
double const MAX_r = 0.1;
double const g_inh = 1.0;


// plasticity
int Ver_lrn;
double const Kltp = 5; // only for file name
double Goutave;
double Kdcy;

//check point
double const tmout=50;
double const inv_t_elg=0.005;
double inv_t_rout;
double Fthr,Fthr1;
double const rna  = 0.1;


int const NE = 5000;
int const NI = 1000;
int const N = NE + NI;

double const cEE = 0.1;
double const cIE = 0.1;
double const cEI = 0.5;
double const cII = 0.5;

double sigma = 0.8;
//check point (original) double mu = log(0.2) + sigma*sigma;
//double mu = log(0.05) + sigma*sigma;
double mu = log(0.1) + sigma*sigma;
double gm = 0.0098;

//check point 
// original GEI = 0.0018, GIE=0.018, GII=0.0025
double GEI = 0.002;
double GIE = 0.01;
double GII = 0.0025;
double Ga = 0.0010;

double VE = 0.0;
double VI = -80.0;
double VL = -70.0;
double Vr = -60.0;
//check point
//double Vth = -50.0;
double Vth_ext = -45.0;
double Vth_inh = -45.0;
double Vmax = 20.0;

double mub = 0.2;
double beta = 10.0;
double rhoEE = 0.25;
double rhoEI = 0.35;

//time constants 
double const tmE = 20.0;
double const tmI = 10.0;
//check point
//double ts = 2.0;
double ts = 8.0;
double tgaba = 8.0;
double tnmda = 100.0;
double tsout = 2.0;
//check point tref=1.0
double tref = 1.0;

//synaptic delay
int dEmax = 30;  // h dependent
int dEmin = 10;
int dImax = 15;
int dImin = 5;

//external input
const int FLG_noise=1;
double Vex = 10.0; //mV
double rex = 20.0; //Hz
double rinh =0.0; //Hz
double rflush = 50.0;
double tinit = 1.0*1000.0; //msec

//external stimulus
double Vstm = 1.0; //mv;
double rstmo = 100.0;
double mustm = 0.5;
double sigstm = 0.1;
double GIstm = GEI;
double rIstm = 100.0;
double t1 = 300.0;

vector<double> dvec;
vector<int> ivec;
deque<double> ddeque;
deque<int> ideque;

typedef vector< vector<double> > DBLMAT;


double dice(){
  return rand()/(RAND_MAX + 1.0);
}

double dice_MT(){
  return genrand_real1();
}

double ngn(){
  double u = dice(); double v = dice();
  return sqrt(-2.0*log(u))*cos(2.0*pi*v);
}

double VlogN(){
  double vtmp = exp( mu + sigma*ngn() );
  while( vtmp > Vmax ){
    vtmp = exp( mu + sigma*ngn() );
  }
  return vtmp;
}

double v_to_g(double v, double gm){
  return gm*v;
}	

double calc_qEE(int i){
  double xi = i/((double)NE);
  double qoEE = 1.0 + log( (1.0 + exp(-beta*mub))/(1.0 + exp(beta*(1.0-mub))) )/beta;
  double qEE = 1.0 + rhoEE*( 1.0/(1.0 + exp(beta*(xi-mub))) - qoEE );
  return qEE;
}

double calc_qEI(int i){
  double xi = i/((double)NE);
  double qoEI = 1.0 + log( (1.0 + exp(-beta*mub))/(1.0 + exp(beta*(1.0-mub))) )/beta;
  double qEI = 1.0 + rhoEI*( 1.0/(1.0 + exp(beta*(xi-mub))) - qoEI );
  return qEI;
}

double calc_rstm(int i){
  double xi = i/((double)NE);
  return rstmo*exp( -(xi-mustm)*(xi-mustm)/(2.0*sigstm*sigstm) )/sqrt( 2.0*pi*sigstm*sigstm );
}

double calc_nrnd(void){
  static int sw=0;
  static double t,u;

  if(sw==0){
    sw=1;
    t=sqrt(-2*log(1-dice())); u = 2*pi*dice();
    return t*cos(u);
  }
  else{
    sw=0;
    return t*sin(u);
  }

}


DBLMAT calc_Gfb(){
  DBLMAT Gfb;
  double mu_fb=log(GEfb/2.0)-(sigma_fb*sigma_fb)/2.0;

  for(int i = 0; i < NE; i++){
    Gfb.push_back(dvec);    
    for(int j = 0; j < Nout; j++){
      Gfb[i].push_back(0.0);
      if(FLG_fb==0 && i>(NE-NNout) && dice() < cEfb) Gfb[i][j]=GEfb*dice();
      else if(FLG_fb==1 && dice() < cEfb)
	Gfb[i][j]=GEfb*dice();
      else if(FLG_fb==2 && i>(NE-NNout) && dice() < cEfb) // check point: lognormal distr
	Gfb[i][j]=exp(mu_fb + sigma_fb*ngn());
    }
  }

  return Gfb;
}



DBLMAT calc_Ginp(){
  //vector< vector<double> > 
  //  vector< vector<double> > 
  DBLMAT Ginp;

  for(int i = 0; i < Nstim; i++){
    Ginp.push_back(dvec);    
    for(int j = 0; j < Ninp; j++){
      Ginp[i].push_back(0.0);
      if(dice() < cEInp) Ginp[i][j]=GEInp;
    }
  }

  return Ginp;
}

//vector< vector<double> > 
DBLMAT calc_G(){
  DBLMAT G;
  //vector< vector<double> > 
  for(int i = 0; i < NE; i++){
    G.push_back(dvec);
    for(int j = 0; j < NE; j++){
      G[i].push_back(0.0);
      if( i != j && dice() < cEE ) G[i][j] = v_to_g(VlogN(), gm);//*calc_qEE(i);
    }
    for(int j = NE; j < N; j++){
      G[i].push_back(0.0);
      if( dice() < cEI ) G[i][j] = GEI;//*calc_qEI(i);
    }
  }
  for(int i = NE; i < N; i++){
    G.push_back(dvec);
    for(int j = 0; j < NE; j++){
      G[i].push_back(0.0);
      if( dice() < cIE ) G[i][j] = GIE;
    }
    for(int j = NE; j < N; j++){
      G[i].push_back(0.0);
      if( i != j && dice() < cII ) G[i][j] = GII;
    }
  }
  return G;
}

vector< vector<int> > calc_d(){
  vector< vector<int> > d;
  for(int i = 0; i < NE; i++){
    d.push_back(ivec);
    for(int j = 0; j < NE; j++) d[i].push_back( dEmin + (int)floor( (dEmax-dEmin)*dice() ) );
    for(int j = NE; j < N; j++) d[i].push_back( dImin + (int)floor( (dImax-dImin)*dice() ) );
  }
  for(int i = NE; i < N; i++){
    d.push_back(ivec);
    for(int j = 0; j < NE; j++) d[i].push_back( dEmin + (int)floor( (dEmax-dEmin)*dice() ) );
    for(int j = NE; j < N; j++) d[i].push_back( dImin + (int)floor( (dImax-dImin)*dice() ) );
  }
  return d;
}


vector< vector<int> > calc_dinp(){
  vector< vector<int> > dinp;
  for(int i = 0; i < Nstim; i++){
    dinp.push_back(ivec);
    for(int j = 0; j < Ninp; j++) dinp[i].push_back( dEmin + (int)floor( (dEmax-dEmin)*dice() ) );
  }
  return dinp;
}


vector<double> rk_vgEI_nmda(double v,double gE,double gI,double gnmda, double tm){
  double vp;
  vector<double> k1;
  k1.push_back( -(v-VL)/tm - (gE+gnmda)*(v-VE)- gI*(v-VI) );
  k1.push_back( -gE/ts ); 
  k1.push_back( -gI/tgaba );
  k1.push_back( -gnmda/tnmda );
  vector<double> k2; vp = (v+0.5*h*k1[0]);
  k2.push_back( -(vp-VL)/tm - (gE+0.5*h*k1[1]+gnmda+0.5*h*k1[3])*(vp-VE) - (gI+0.5*h*k1[2])*(vp-VI) );
  k2.push_back( -(gE+0.5*h*k1[1])/ts ); 
  k2.push_back( -(gI+0.5*h*k1[2])/tgaba );
  k2.push_back( -(gnmda+0.5*h*k1[3])/tnmda );
  vector<double> k3; vp = (v+0.5*h*k2[0]);
  k3.push_back( -(vp-VL)/tm - (gE+0.5*h*k2[1]+gnmda+0.5*h*k2[3])*(vp-VE) - (gI+0.5*h*k2[2])*(vp-VI) );
  k3.push_back( -(gE+0.5*h*k2[1])/ts ); 
  k3.push_back( -(gI+0.5*h*k2[2])/tgaba );
  k3.push_back( -(gnmda+0.5*h*k2[3])/tnmda );
  vector<double> k4; vp = (v+1.0*h*k3[0]);
  k4.push_back( -(vp-VL)/tm - (gE+1.0*h*k3[1]+gnmda+1.0*h*k3[3])*(vp-VE) - (gI+1.0*h*k3[2])*(vp-VI) );
  k4.push_back( -(gE+1.0*h*k3[1])/ts ); 
  k4.push_back( -(gI+1.0*h*k3[2])/tgaba );
  k4.push_back( -(gnmda+1.0*h*k3[3])/tnmda );
  vector<double> vgEI;
  vgEI.push_back( v     + h*(k1[0] + 2.0*k2[0] + 2.0*k3[0] + k4[0])/6.0 );
  vgEI.push_back( gE    + h*(k1[1] + 2.0*k2[1] + 2.0*k3[1] + k4[1])/6.0 );
  vgEI.push_back( gI    + h*(k1[2] + 2.0*k2[2] + 2.0*k3[2] + k4[2])/6.0 );
  vgEI.push_back( gnmda + h*(k1[3] + 2.0*k2[3] + 2.0*k3[3] + k4[3])/6.0 );
  return vgEI;
}


vector<double> rk_vgEI(double v,double gE,double gI, double tm){
  double vp;
  vector<double> k1;
  k1.push_back( -(v-VL)/tm - gE*(v-VE) - gI*(v-VI) );
  k1.push_back( -gE/ts ); 
  k1.push_back( -gI/tgaba );
  vector<double> k2; vp = (v+0.5*h*k1[0]);
  k2.push_back( -(vp-VL)/tm - (gE+0.5*h*k1[1])*(vp-VE) - (gI+0.5*h*k1[2])*(vp-VI) );
  k2.push_back( -(gE+0.5*h*k1[1])/ts ); 
  k2.push_back( -(gI+0.5*h*k1[2])/tgaba );
  vector<double> k3; vp = (v+0.5*h*k2[0]);
  k3.push_back( -(vp-VL)/tm - (gE+0.5*h*k2[1])*(vp-VE) - (gI+0.5*h*k2[2])*(vp-VI) );
  k3.push_back( -(gE+0.5*h*k2[1])/ts ); 
  k3.push_back( -(gI+0.5*h*k2[2])/tgaba );
  vector<double> k4; vp = (v+1.0*h*k3[0]);
  k4.push_back( -(vp-VL)/tm - (gE+1.0*h*k3[1])*(vp-VE) - (gI+1.0*h*k3[2])*(vp-VI) );
  k4.push_back( -(gE+1.0*h*k3[1])/ts ); 
  k4.push_back( -(gI+1.0*h*k3[2])/tgaba );
  vector<double> vgEI;
  vgEI.push_back( v + h*(k1[0] + 2.0*k2[0] + 2.0*k3[0] + k4[0])/6.0 );
  vgEI.push_back( gE + h*(k1[1] + 2.0*k2[1] + 2.0*k3[1] + k4[1])/6.0 );
  vgEI.push_back( gI + h*(k1[2] + 2.0*k2[2] + 2.0*k3[2] + k4[2])/6.0 );
  return vgEI;
}






void calc(int ik, int ilmax, double frac,double max_elg){
  double dtmp;
  //  srand(191);
  //  srand(ik*31);
  srand(ik*(31+int(Sigma_inp*10)));

  //  vector< vector<double> > 
  DBLMAT G    = calc_G();
  //  vector< vector<double> > 
  DBLMAT Ginp = calc_Ginp();
  DBLMAT Gfb = calc_Gfb();

  vector< vector<int> >    d    = calc_d();
  vector< vector<int> >    dinp = calc_dinp();


  vector< vector<int> > Goutidx;
  for(int i = 0; i < N; i++){
    Goutidx.push_back(ivec);
    for(int j = 0; j < N; j++){
      if( G[j][i] > 0.0 ) Goutidx[i].push_back(j);
    }
  }

  vector< vector<int> > Ginpidx;
  for(int i = 0; i < Ninp; i++){
    Ginpidx.push_back(ivec);
    for(int j = 0; j < Nstim; j++){
      if( Ginp[j][i] > 0.0 ) Ginpidx[i].push_back(j);
    }
  }


  vector< vector<int> > Gfbidx;
  for(int i = 0; i < Nout; i++){
    Gfbidx.push_back(ivec);
    for(int j = 0; j < NE; j++){
      if( Gfb[j][i] > 0.0 ) Gfbidx[i].push_back(j);
    }
  }


  int flg_tmp_rna=0;
  if(rna<dbl_eps) flg_tmp_rna=0;
  else            flg_tmp_rna=1;

  ostringstream ossd; 
  //  ossd << ADR << "dbd56_fb_rnd_norm" <<"_" << ik<< "-Si"<<Sigma_inp<<scl_fac<<"-"<< Goutave<<Kdcy<<amp_fb<<"-"<<tmout<<inv_t_elg<<inv_t_rout<<".rnd.txt"<<flg_tmp_rna<<"_"<<FLG_fb<<"hb"<<Ver_lrn<<Kltp;
  //check point
  ossd << ADR << "dbd56_fb_rnd_norm" <<"_"<<ik<< "-Si"<<Sigma_inp<<scl_fac<<"-"<<Goutave<<Kdcy<<amp_fb<<"-"<<tmout<<inv_t_elg<<inv_t_rout<<GEfb<<cEfb<<sigma_fb<<".rnd.txt"<<flg_tmp_rna<<"_"<<FLG_fb<<FLG_noise<<"hb"<<Ver_lrn<<Kltp;



  string fstr=ossd.str();   ifstream ifs(fstr.c_str()); 

  if(ifs.fail()) {
    cerr << "File do not exist."<<fstr.c_str()<<"\n" ;
    exit(0);
  }

  int itmp;
  string str;
  // skip until ilmax-th steps
  for(int i=0;i<(NNout+2)*ilmax;i++){
    getline(ifs, str);
  }

  vector<int> Goutnetidx;
  DBLMAT Gout;  // output filter
  Gout.push_back(dvec);
  Gout.push_back(dvec);
  for(int i=0;i<NE;i++){
    Gout[0].push_back(0.0);    Gout[1].push_back(0.0);
    Goutnetidx.push_back(3);
  }
  for(int i=NE-NNout;i<NE;i++){
    getline(ifs, str);
    sscanf(str.data(), "%d %d %lg %lg ", &itmp, &Goutnetidx[i],&Gout[0][i], &Gout[1][i]);
  }


  ostringstream ossr,osst;
  //  ossr << ADR<<"rbr56_fb_rnd_norm" <<ik<<"-"<<ilmax<<"_l" << frac <<Sigma_inp<<scl_fac<<"-"<<Goutave<<Kdcy<<amp_fb<<"-"<<tmout<<inv_t_elg<<inv_t_rout<<".rnd.txt1_"<<FLG_fb<<"hb"<<Ver_lrn<<Kltp;
  //  osst << ADR<<"rbt56_fb_rnd_norm" <<ik<<"-"<<ilmax<<"_l" << frac <<Sigma_inp<<scl_fac<<"-"<<Goutave<<Kdcy<<amp_fb<<"-"<<tmout<<inv_t_elg<<inv_t_rout<<".rnd.txt1_"<<FLG_fb<<"hb"<<Ver_lrn<<Kltp;


  ossr << ADR<<"rbr56_fb_rnd_norm" <<ik<<"-"<<ilmax<<"_l" << frac <<Sigma_inp<<scl_fac<<"-"<<Goutave<<Kdcy<<amp_fb<<"-"<<tmout<<inv_t_elg<<inv_t_rout<<GEfb<<cEfb<<sigma_fb<<".rnd.txt"<<flg_tmp_rna<<"_"<<FLG_fb<<FLG_noise<<"hb"<<Ver_lrn<<Kltp;
  osst << ADR<<"rbt56_fb_rnd_norm" <<ik<<"-"<<ilmax<<"_l" << frac <<Sigma_inp<<scl_fac<<"-"<<Goutave<<Kdcy<<amp_fb<<"-"<<tmout<<inv_t_elg<<inv_t_rout<<GEfb<<cEfb<<sigma_fb<<".rnd.txt"<<flg_tmp_rna<<"_"<<FLG_fb<<FLG_noise<<"hb"<<Ver_lrn<<Kltp;


  string fstrr = ossr.str(); ofstream ofsr; ofsr.open( fstrr.c_str() );  ofsr.precision(10);	
  string fstrt = osst.str(); ofstream ofst; ofst.open( fstrt.c_str() );
  /*  
  for(int i=NE-NNout;i<NE;i++)
    ofst << Goutnetidx[i] << " " << Gout[0][i] << " " <<  Gout[1][i]<<endl;
  exit(0);
  */
  for(int il=0;il<50;il++){

    //check point
    srand((unsigned int)time(NULL)+il);
    //    srand(il);
    //    init_genrand((unsigned int)time(NULL)+il);

    // set input pattern
    vector <double> rinp;
    for(int i = 0; i < Ninp; i++){
      double xtmp=(double)i/Ninp;
      dtmp=Rinp_max*exp(-(xtmp-(0.195+frac))*(xtmp-(0.195+frac))/(2*0.15*0.15*Sigma_inp*Sigma_inp))/(Sigma_inp*scl_fac);
      dtmp=(dtmp>0 ? dtmp:0);
      //check point
      if(frac==-1)dtmp=0.;
      rinp.push_back(dtmp);
    }


    // initialize variables
    vector<double> v,gE,gI,gnmda;
    for(int i = 0; i < N; i++){
      v.push_back(VL); gE.push_back(0.0); gI.push_back(0.0); gnmda.push_back(0.0);
    }
    vector< deque<double> > uE,uI; //delayed input
    for(int i = 0; i < N; i++){
      uE.push_back(ddeque); uI.push_back(ddeque);
      for(int j = 0; j < dEmax+2; j++) uE[i].push_back(0.0);
      for(int j = 0; j < dImax+2; j++) uI[i].push_back(0.0);
    }



    vector<double> tm; //membrane time const
    for(int i = 0; i < NE; i++) tm.push_back(tmE);
    for(int i = NE; i < N; i++) tm.push_back(tmI);
    vector<double> Vth; //membrane time const
    for(int i = 0; i < NE; i++) Vth.push_back(Vth_ext);
    for(int i = NE; i < N; i++) Vth.push_back(Vth_inh);

    vector<double> spts; //previous spike time
    for(int i = 0; i < N; i++) spts.push_back(-1000.0);
    vector<double> spts_out; //previous spike time
    for(int i = 0; i < Nout; i++) spts_out.push_back(-1000.0);
	
    vector<double> rstms; // firing rates of external stimulus
    for(int i = 0; i < NE; i++) rstms.push_back( calc_rstm(i) );


    vector<double> vgEI;
    double rout[Nout],gO[Nout];
    for(int i=0;i<Nout;i++) rout[i]=0.0;
    for(int i=0;i<Nout;i++) gO[i]=0.0;

    //check point
    srand(il+300);

    for(double t = 0.0; t < T+h; t += h){
      // current from input
      if(t>Tstart && t<Tend){
	for(int i = 0; i < Ninp; i++){
	  if( dice() < rinp[i]/(1000.0/h)){		    
	    for(int jidx = 0; jidx < Ginpidx[i].size(); jidx++){
	      int j = Ginpidx[i][jidx];
	      uE[j][ dinp[j][i] ] += Ginp[j][i];
	    }
	  }
	}
      }

      // current through fb
      for(int i = 0; i < Nout; i++){
	for(int jidx = 0; jidx < Gfbidx[i].size(); jidx++){
	  if(dice() < amp_fb*rout[i]/(1000.0/h)){		    
	    int j = Gfbidx[i][jidx];
	    uE[j][0] += Gfb[j][i];
	  }
	}
      }

      // current from external noisy stimuli.
      for(int i = 0; i < N; i++){ 
	if( t < tinit && dice() < rex/(1000.0/h)){
	  if(FLG_noise==1 ||
	     (FLG_noise==0 && (i>=Nstim || (t<Tstart || t>Tend)))){
	    gE[i]    += v_to_g(Vex,gm);
	  //check point
	  //	  gnmda[i] += rna*v_to_g(Vex,gm);
	  }
	}
	if( t < tinit && dice() < rinh/(1000.0/h)){
	  gI[i]    += v_to_g(Vex,gm);
	}
      }

      // current through recurrent connections
      for(int i = 0; i < N; i++){
	if( t - spts[i] < tref ){
	  v[i] = VL;
	}else{
	  if( v[i] > Vth[i] ){
	    ofsr << t << " " << i << endl; 
	    spts[i] = t; v[i] = Vr;
			
	    for(int jidx = 0; jidx < Goutidx[i].size(); jidx++){
	      int j = Goutidx[i][jidx];
	      if( i < NE ){
		if( j < NE ){
		  if( dice() > Ga/(G[j][i] + Ga) ) uE[j][ d[j][i] ] += G[j][i];
		}else{
		  uE[j][ d[j][i] ] += G[j][i];
		}
	      }else{
		uI[j][ d[j][i] ] += G[j][i];
	      }
	    }

	    if(NE-NNout<=i && i<NE){
	      if(Goutnetidx[i]==0){
		gO[0]+=Gout[0][i];
		gO[1]+=Gout[1][i];
	      }
	      else if(Goutnetidx[i]==1)
		gO[0]+=Gout[0][i];
	      else if(Goutnetidx[i]==2)
		gO[1]+=Gout[1][i];
	    }
	  }
	}
      }
      
      if( ((int)floor(t/h))%1000 == 0 ){
	//		    cout << t << endl;
	double nearestspiketime = 0.0;
	for(int i = 0; i < N; i++){
	  if( spts[i] > nearestspiketime ) nearestspiketime = spts[i];
	}
	if( t-nearestspiketime > 1000.0 ) break;
      }

      // 1 step ahead (neurons in the main network)
      for(int i = 0; i < N; i++){
	gE[i] += uE[i][0]; gI[i] += uI[i][0]; gnmda[i]+=rna*uE[i][0];
	uE[i].pop_front();    uE[i].push_back(0.0);
	uI[i].pop_front();    uI[i].push_back(0.0);			
	if(i<NE){
	  vgEI = rk_vgEI_nmda(v[i],gE[i],gI[i],gnmda[i],tm[i]);
	  v[i] = vgEI[0]; gE[i] = vgEI[1]; gI[i] = vgEI[2]; gnmda[i]=vgEI[3];
	}
	else{
	  vgEI = rk_vgEI(v[i],gE[i],gI[i],tm[i]);
	  v[i] = vgEI[0]; gE[i] = vgEI[1]; gI[i] = vgEI[2]; gnmda[i]=0.0;
	}
      }

      // 1 step ahead (output neurons)
      double rtmp[Nout];
      rtmp[0]=rout[0];
      rtmp[1]=rout[1];

      for(int i=0;i<Nout;i++){
	dtmp=rtmp[(i+1)%2];
	dtmp=((dtmp>0.0)? dtmp:0.0);
	rout[i]   += (-rout[i]-g_inh*dtmp+gO[i]/h)*h/tmout;   //gO [kHz]
	dtmp=((rout[i]>0.0)? rout[i]:0.0);
	//check point
	dtmp=((dtmp>MAX_r)? MAX_r:dtmp);
	rout[i]=dtmp;
	gO[i]     =0;
      }

      // record part
      if((int)(t/h)%10==0)
	ofst << t << " " << rout[0] << " " << rout[1] << " " <<  endl;

      if(t>Trwd){
	if(fabs(rout[0] - rout[1]) > Fthr1 ){
	  ofst << t << " " << rout[0] << " " << rout[1] << " " << endl;
	  break;
	}
      }


    }  // end of t-loop



    ofst << endl << endl;
    ofsr << endl << endl;
  }
  
}



void simul(int ik, int ilmax, double frac, double max_elg){
  calc(ik,ilmax,frac,max_elg);
}

int main(int argc, char **argv){
  //	srand((unsigned int)time(NULL));
  int ik = 0; int ilmax = 0;
  double frac,max_elg;
  int n=1;
  if(argc > n) ik    = atoi(argv[n]);   n+=1;
  if(argc > n) ilmax = atoi(argv[n]);n+=1;
  if(argc > n) Kdcy       = atof(argv[n]);n+=1;
  if(argc > n) GEfb       = atof(argv[n]);n+=1;
  if(argc > n) cEfb       = atof(argv[n]);n+=1;
  if(argc > n) sigma_fb   = atof(argv[n]);n+=1;
  if(argc > n) frac       = atof(argv[n]);n+=1;
  if(argc > n) Sigma_inp  = atof(argv[n]);n+=1;
  if(argc > n) scl_fac    = atof(argv[n]);n+=1;


  //check point
  Goutave=0.03;
  inv_t_rout=0.02;
  Fthr=0.03;
  Fthr1=1;
  Ver_lrn=20;


  simul(ik,ilmax,frac,max_elg);
  return 0;
}
