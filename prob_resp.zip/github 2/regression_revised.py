#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 14 10:27:19 2018

@author: kurikawa

For figures in final ver in the revised manuscript
update 2018.6.14
"""

import numpy as np
from  scipy.optimize  import  curve_fit
from  scipy  import  integrate
from scipy import optimize
from scipy.ndimage import filters as flt
from scipy import linalg as LA

def PCA(P):
    m = sum(P) / float(len(P))
    P_m = P - m
    l,v = np.linalg.eig( np.dot(P_m.T,P_m) )
    idx=l.argsort()
    l=l[idx][::-1]
    v=v[:,idx][:,::-1]
    return l,v.T


def main(argset,flgs):   
    # flg=0:normlized ensemble and # of choice=2 (ncond=2,Left and Right), ncoef=3 (choice,stim, other)
    # flg=2:normlized ensemble and # of choice=3 (ncond=3,Left,Right, and other), ncoef=3 (choice,stim, other)
    # flg=3:same as flg=0 except for just fileterd ensemble
    # flg=4:normlized ensemble and # of choice=2 (ncond=2,Left,Right), ncoef=4 (choice,fam stim, nov stim,other)
    t_init=0
    t_init_smp=0
    t_init_beta_max=0
    n_cell=100
    
    ncond=2
    ncoef=3
    nstim=2  #nstim==2, only familar tones, nstim==7 all tones
    
    if_nofb=False  
    
    if len(flgs)==5:
        flg_spn,flg_pca,if_noinput_neurons,if_random_select,if_pert=flgs[0],flgs[1],flgs[2],flgs[3],flgs[4]
        if_unfam = False
    elif len(flgs)==6:
        flg_spn,flg_pca,if_noinput_neurons,if_random_select,if_pert,if_unfam=flgs[0],flgs[1],flgs[2],flgs[3],flgs[4],flgs[5]
    elif len(flgs)==7:
        flg_spn,flg_pca,if_noinput_neurons,if_random_select,if_pert,if_unfam,if_nofb=flgs[0],flgs[1],flgs[2],flgs[3],flgs[4],flgs[5],flgs[6]
    else:
        print("invalid flags")
        return
    
    # organize rate data
    rate_tmp,list_total_tmp,irat=np.copy(argset[0]),np.copy(argset[1]),argset[2]
    t_max_rate=len(rate_tmp[0,0])
    t_end_smp=t_max_rate-1

    if nstim==2:
        tmp=np.vstack((rate_tmp[0],rate_tmp[6]))
        tmp=tmp.reshape(2*50,t_max_rate,5000)
    else:
        tmp=rate_tmp.reshape(7*50,t_max_rate,5000)
    if if_noinput_neurons:
        tmp=tmp[:,:,2000:]
    tmp=np.swapaxes(tmp,0,1)
    rate=np.swapaxes(tmp,0,2)
    
   
# for some condistions, different rates are generated.
    if if_pert:
        rate_pert=np.copy(argset[3])
        tmp=np.swapaxes(rate_pert,0,1)
        if if_noinput_neurons:
            tmp=rate_pert[:,:,2000:]
            tmp=np.swapaxes(tmp,0,1)
        rate_pert=np.swapaxes(tmp,0,2)
    elif if_nofb and nstim==2:
        rate_tmp=np.copy(argset[3])
        tmp=np.vstack((rate_tmp[0],rate_tmp[6]))
        tmp=tmp.reshape(2*50,t_max_rate,5000)
        tmp=np.swapaxes(tmp,0,1)
        rate_nofb=np.swapaxes(tmp,0,2)

    if if_unfam:
        rate_unfam=np.vstack((rate_tmp[1],rate_tmp[2]))
        for i in range(3,6):
            rate_unfam=np.vstack((rate_unfam,rate_tmp[i]))
        tmp=rate_unfam.reshape(5*50,t_max_rate,5000)
        tmp=np.swapaxes(rate_unfam,0,1)
        if if_noinput_neurons:
            tmp=rate_unfam[:,:,2000:]
            tmp=np.swapaxes(tmp,0,1)
        rate_unfam=np.swapaxes(tmp,0,2)

    list_total=[]
    for i in range(2):
        list_total.append([])
        for j in range(nstim):
            if nstim==2 and j==1:
                list_total[i].append(list(np.array(list_total_tmp[6][i])+50))
            else:
                list_total[i].append(list(np.array(list_total_tmp[j][i])+j*50))
    #            list_total[i].append(tmplist[:len(tmplist)/2])
    # use only ealier half of data due to swhich of glabal activity pattern.

    n_tbin=len(rate[0,0])
    if if_random_select and if_noinput_neurons:
        fr=np.mean(rate,axis=(1,2))
        tmp_set=[i for i in range(3000) if fr[i]>0.05]  # here fr is firing number per 10ms
        tmp_ord=random.sample(tmp_set,n_cell)
    elif not if_noinput_neurons and if_random_select:
        print("this combination is invalid up to now")
        
    else:
        tmp_ord=(np.argsort(np.fabs(np.mean(rate[:,:,10:],axis=(1,2))-np.mean(rate[:,:,0:10],axis=(1,2)))))[-n_cell:] # ver for revised (2018.5.28)    
        #tmp_ord=(np.argsort(np.mean(rate[:,:,:],axis=(1,2))))[-n_cell:]  # check point ver for submitted

    rate=rate[tmp_ord]
    if if_nofb:
        rate_nofb=rate_nofb[tmp_ord]
    
    if if_pert:
        rate_pert=rate_pert[tmp_ord]
        if if_unfam:
            rate_unfam=rate_unfam[tmp_ord]
            norm_dyn,norm_pop_dyn,norm_pop_pert,norm_pop_dyn_unfam   =gen_zscored_ave_dyn([rate,rate_pert,rate_unfam],list_total,["pert",True])
        else:
            norm_dyn,norm_pop_dyn,norm_pop_pert   =gen_zscored_ave_dyn([rate,rate_pert],list_total,["pert"])
    
    if flg_spn=="spn":
        rate_spn=rate_spn[tmp_ord]
        norm_dyn,norm_pop_dyn,norm_spn_dyn    =gen_zscored_ave_dyn([rate,rate_spn],list_total,[flg_spn])        
    if if_nofb:
        norm_dyn,norm_pop_dyn,norm_nofb,norm_pop_nofb    =gen_zscored_ave_dyn([rate,rate_nofb],list_total,[flg_spn,False,if_nofb])
    else:
        norm_dyn,norm_pop_dyn      =gen_zscored_ave_dyn([rate],list_total,[flg_spn]) 
    
       
    if(ncond!=len(norm_dyn[0])):
        sys.stderr.write('ncond is invalid!')
    pca_data=norm_dyn[:,:,t_init_smp:t_end_smp,:].reshape(nstim*ncond*len(norm_dyn[0,0,t_init_smp:t_end_smp]),n_cell)
    #    norm_r15   =get_zscored_dyn(rate)
    #    pca_data=norm_r15.reshape(nsmp*n_tbin,n_cell)
    PCs=PCA(pca_data)

    if flg_pca=="get_PCA":
        if if_pert:
            if if_unfam:
                return PCs,norm_pop_dyn,norm_pop_pert,norm_pop_dyn_unfam
            return PCs,norm_pop_dyn,norm_pop_pert
        elif flg_spn=="spn":
            return PCs,norm_pop_dyn,norm_spn_dyn
        else:
            return PCs,norm_pop_dyn
    # get beta_orth
    norm_r15   =get_zscored_dyn(rate[:,:,t_init_smp:t_end_smp])
    beta       =get_beta(list_total,norm_r15,ncoef)
    pca_beta   =get_pca_beta(beta,PCs[1])
    #check point
    beta_max,QR,t_max=get_orth_beta(pca_beta[:,t_init_beta_max:,:])
    #beta_max,QR,t_max=get_orth_beta1(pca_beta[:,t_init_beta_max:,:])

    if if_pert:
        prj_dyn,prj_pop_dyn,prj_pop_pert    =get_prj_dyn(QR,[norm_dyn,norm_pop_dyn,norm_pop_pert],ncoef,nstim,"pert")
    elif if_nofb:
        prj_dyn,prj_pop_dyn,prj_nofb,prj_pop_nofb    =get_prj_dyn(QR,[norm_dyn,norm_pop_dyn,norm_nofb,norm_pop_nofb],ncoef,nstim,"nofb")
    if flg_spn=="spn":
        prj_dyn,prj_pop_dyn,prj_spn_dyn    =get_prj_dyn(QR,[norm_dyn,norm_pop_dyn,norm_spn_dyn],ncoef,nstim,flg_spn)
    else:
        prj_dyn,prj_pop_dyn    =get_prj_dyn(QR,[norm_dyn,norm_pop_dyn],ncoef,nstim,flg_spn)

    if if_pert:
        return prj_dyn,prj_pop_dyn,prj_pop_pert
    elif if_nofb:
        return prj_dyn,prj_pop_dyn,prj_nofb,prj_pop_nofb
    if flg_spn=="spn":
        return prj_dyn,prj_pop_dyn,prj_spn_dyn
    else:
        return prj_dyn,prj_pop_dyn


def get_prj_dyn(QR,dyns,ncoef,nstim,flg):
    
    norm_dyn     =dyns[0]
    norm_pop_dyn =dyns[1]
    if flg=="spn":
        norm_spn_dyn =dyns[2]
    if flg=="pert":
        norm_pop_pert=dyns[2]
    elif flg=="nofb":
        norm_nofb    =dyns[2]
        norm_pop_nofb=dyns[3]
    
    
    ncond=len(norm_dyn[0])
    n_tsmp=len(norm_dyn[0,0])
    n_trial=len(norm_pop_dyn)
    
    prj_dyn    =np.zeros((nstim,ncond,ncoef-1,n_tsmp))
    for i in range(nstim):
        for j in range(ncond):
            for k in range(ncoef-1):
                for l in range(n_tsmp):
                    prj_dyn[i,j,k,l]=np.sum(QR[0][:,k]*norm_dyn[i,j,l,:])


    prj_pop_dyn=np.zeros((n_trial,ncoef-1,n_tsmp))
    for i in range(n_trial):
        for k in range(ncoef-1):
            for l in range(n_tsmp):
                prj_pop_dyn[i,k,l]=np.sum(QR[0][:,k]*norm_pop_dyn[i,l,:])
    if flg=="pert" :
        n_trial_pert=len(norm_pop_pert)
        prj_pop_pert=np.zeros((n_trial_pert,ncoef-1,n_tsmp))
        for i in range(n_trial_pert):
            for k in range(ncoef-1):
                for l in range(n_tsmp):
                    prj_pop_pert[i,k,l]=np.sum(QR[0][:,k]*norm_pop_pert[i,l,:])
        return prj_dyn,prj_pop_dyn,prj_pop_pert
    elif flg=="nofb" :
        prj_nofb   =np.zeros((nstim,ncond,ncoef-1,n_tsmp))
        for i in range(nstim):
            for j in range(ncond):
                for k in range(ncoef-1):
                    for l in range(n_tsmp):
                        prj_nofb[i,j,k,l]=np.sum(QR[0][:,k]*norm_nofb[i,j,l,:])
                    
        prj_pop_nofb=np.zeros((n_trial,ncoef-1,n_tsmp)) 
        for i in range(n_trial):
            for k in range(ncoef-1):
                for l in range(n_tsmp):
                    prj_pop_nofb[i,k,l]=np.sum(QR[0][:,k]*norm_pop_nofb[i,l,:])
        return prj_dyn,prj_pop_dyn,prj_nofb,prj_pop_nofb
    if flg=="spn":
        n_trial_spn=len(norm_spn_dyn)
        n_tsmp_spn=len(norm_spn_dyn[0])
        prj_spn_dyn=np.zeros((n_trial_spn,ncoef-1,n_tsmp_spn))
        for i in range(n_trial_spn):
            for k in range(ncoef-1):
                for l in range(n_tsmp_spn):
                    prj_spn_dyn[i,k,l]=np.sum(QR[0][:,k]*norm_spn_dyn[i,l,:])
        return prj_dyn,prj_pop_dyn,prj_spn_dyn
    else:
        return prj_dyn,prj_pop_dyn
    
    

def get_orth_beta(beta_dyn):
    ncoef=len(beta_dyn)
    n_tsmp=len(beta_dyn[0])
    n_cell=len(beta_dyn[0,0])
    beta_max=np.zeros((ncoef,n_cell))
    t_max=np.zeros(ncoef)
    for i in range(ncoef):
        tmp=np.zeros(n_tsmp)
        for j in range(n_tsmp):
            tmp[j]=np.sum(beta_dyn[i,j,:]*beta_dyn[i,j,:])
        t_max[i]=int(np.argsort(tmp)[-1])
        beta_max[i,:]=beta_dyn[i,int(t_max[i]),:]
    
    QR=LA.qr(beta_max[:(ncoef-1),:].T)
    
    return beta_max,QR,t_max



def get_pca_beta(beta,PCs):
    ncoef=len(beta)
    n_tsmp=len(beta[0])
    pca_beta=np.zeros(beta.shape)
    n_pca=10
    
    
    for i in range(ncoef):
        for j in range(n_tsmp):
            for k in range(n_pca):
                tmp=pca_beta[i,j,:]+np.sum(PCs[k,:]*beta[i,j,:])*PCs[k,:]
                pca_beta[i,j,:]=tmp
    
    return pca_beta



def gen_F(list_total,n_trial,ncoef):
    tmp1=[]
    ncond=len(list_total)
    nstim=len(list_total[0])
    
    for i in range(n_trial):
        tmp=np.zeros(ncoef)
        for j in range(ncond):
            for k in range(nstim):
                if i in list_total[j][k]:
                    tmp[0]=j*2-1
                    if nstim==2:
                        tmp[1]=k*2-1
                    elif nstim==7:
                        tmp[1]=(k-3)/3.0
        #                    tmp[2]=tmp[0]*tmp[1]
        
        tmp[2]=1
        tmp1.append(tmp)
    
    tmp1=np.array(tmp1)
    F=tmp1.T
    return F

 
def get_beta(list_total,norm_r,ncoef):
    
    F=gen_F(list_total,len(norm_r),ncoef)
    n_tsmp=len(norm_r[0])
    n_cell=len(norm_r[0,0])
    ncond=len(list_total)
    
    beta=np.zeros((ncoef,n_tsmp,n_cell))
    for i in range(n_tsmp):
        for j in range(n_cell):
            try:
                Usvd,Ssvd,Vsvd=LA.svd(np.dot(F,F.T))
            except:
                print("error! in svd proc")
                np.save("err_mat",mat)
                return
            F_inv=np.dot(Vsvd.T,np.dot(np.diag(1/Ssvd[:]),Usvd.T))
            beta[:,i,j]=np.dot(F_inv,np.dot(F,norm_r[:,i,j]))
    
    return beta   
    
def get_zscored_dyn(rate):
    t_bin=3
    n_tsmp=len(rate[0,0])
    n_cell=len(rate)
    n_trial=len(rate[0])
    norm_rate=np.zeros((n_trial,n_tsmp-t_bin,n_cell))
    
    cnt=0
    for k in range(n_cell):
        tmp=np.zeros((n_trial,n_tsmp))
        #for i in range(n_trial):
        #            if(np.fabs(np.std(rate[k,i,:]))>eps_dbl):
        #                tmp[i,:]=flt.gaussian_filter(rate[k,i,:],2)
        for i in range(n_tsmp-t_bin):
            norm_rate[:,i,k]=(np.mean(rate[k,:,i:i+t_bin],axis=1)-np.mean(rate[k]))/np.std(rate[k])
    
    return norm_rate   
    

def gen_zscored_ave_dyn(rates,list_total,flgs):
    rate=rates[0]
    n_tsmp=len(rate[0,0])
    n_trial=len(rate[0])
    n_cell=len(rate)
    ncond=len(list_total)
    nstim=len(list_total[0])
    if_nofb=False
    
    if len(flgs)==2:
        flg_spn,if_unfam=flgs[0],flgs[1]
    elif len(flgs)==1:
        flg_spn,if_unfam=flgs[0],False
    elif len(flgs)==3:
        flg_spn,if_unfam,if_nofb=flgs[0],flgs[1],flgs[2]
        rate_nofb=np.copy(rates[1])
    else:
        print("invalid flags")
        return

    cond_dyn=np.zeros((nstim,ncond,n_tsmp,n_cell))
    for i in range(nstim):
        for j in range(ncond):
            if(len(list_total[j][i])!=0):
                cond_dyn[i,j,:,:]=np.mean(rate[:,list_total[j][i],:],axis=1).T
    
    flt_dyn=np.zeros(cond_dyn.shape)
    for i in range(len(flt_dyn)):
        for j in range(len(flt_dyn[0])):
            for k in range(n_cell):
                flt_dyn[i,j,:,k]=flt.gaussian_filter(cond_dyn[i,j,:,k],1)
    
    norm_dyn=np.zeros(flt_dyn.shape)
    ave_tmp=np.mean(flt_dyn,axis=(0,1,2))
    dev_tmp=np.std(flt_dyn,axis=(0,1,2))
    
    for i in range(len(norm_dyn)):
        for j in range(len(norm_dyn[0])):
            for k in range(n_cell):
                norm_dyn[i,j,:,k]=(flt_dyn[i,j,:,k]-ave_tmp[k])/(dev_tmp[k])


# calc. pop dynamics
    flt_pop_dyn=np.zeros((n_trial,n_tsmp,n_cell))
    for i in range(len(flt_pop_dyn)):
        for k in range(n_cell):
            flt_pop_dyn[i,:,k]=flt.gaussian_filter(rate[k,i,:],1)

    norm_pop_dyn=np.zeros(flt_pop_dyn.shape)
    for i in range(len(norm_pop_dyn)):
        for k in range(n_cell):
            norm_pop_dyn[i,:,k]=(flt_pop_dyn[i,:,k]-ave_tmp[k])/(dev_tmp[k])
    if if_nofb:
        cond_dyn=np.zeros((nstim,ncond,n_tsmp,n_cell))
        for i in range(nstim):
            for j in range(ncond):
                if(len(list_total[j][i])!=0):
                    cond_dyn[i,j,:,:]=np.mean(rate_nofb[:,list_total[j][i],:],axis=1).T
                                
        flt_dyn=np.zeros(cond_dyn.shape)
        for i in range(len(flt_dyn)):
            for j in range(len(flt_dyn[0])):
                for k in range(n_cell):
                    flt_dyn[i,j,:,k]=flt.gaussian_filter(cond_dyn[i,j,:,k],1)
    
        norm_nofb=np.zeros(flt_dyn.shape)
    
        for i in range(len(norm_nofb)):
            for j in range(len(norm_nofb[0])):
                for k in range(n_cell):
                    norm_nofb[i,j,:,k]=(flt_dyn[i,j,:,k]-ave_tmp[k])/(dev_tmp[k])                              
                
        flt_pop_nofb=np.zeros((n_trial,n_tsmp,n_cell))
        for i in range(len(flt_pop_nofb)):
            for k in range(n_cell):
                flt_pop_nofb[i,:,k]=flt.gaussian_filter(rate_nofb[k,i,:],1)
            
        norm_pop_nofb=np.zeros(flt_pop_dyn.shape)
        for i in range(len(norm_pop_nofb)):
            for k in range(n_cell):
                norm_pop_nofb[i,:,k]=(flt_pop_nofb[i,:,k]-ave_tmp[k])/(dev_tmp[k])
        
        return norm_dyn,norm_pop_dyn,norm_nofb,norm_pop_nofb

# calc. pop dynamics for unfamiliar on familiar-trajectory-based map
    if if_unfam:
        rate_unfam=rates[2]
        flt_pop_dyn_unfam=np.zeros((250,n_tsmp,n_cell))
        for i in range(len(flt_pop_dyn_unfam)):
            for k in range(n_cell):
                flt_pop_dyn_unfam[i,:,k]=flt.gaussian_filter(rate_unfam[k,i,:],1)
    
        norm_pop_dyn_unfam=np.zeros(flt_pop_dyn_unfam.shape)
        for i in range(len(norm_pop_dyn_unfam)):
            for k in range(n_cell):
                norm_pop_dyn_unfam[i,:,k]=(flt_pop_dyn_unfam[i,:,k]-ave_tmp[k])/(dev_tmp[k])


    # calc. spn dyn
    if flg_spn=="spn":
        rate_spn=rates[1]
        n_trial_spn=len(rate_spn[0])
        n_tsmp_spn =len(rate_spn[0,0])
        flt_spn_dyn=np.zeros((n_trial_spn,n_tsmp_spn,n_cell))
        for i in range(len(flt_spn_dyn)):
            for k in range(n_cell):
                flt_spn_dyn[i,:,k]=flt.gaussian_filter(rate_spn[k,i,:],1)

        norm_spn_dyn=np.zeros(flt_spn_dyn.shape)
        for i in range(len(norm_spn_dyn)):
            for k in range(n_cell):
                norm_spn_dyn[i,:,k]=(flt_spn_dyn[i,:,k]-ave_tmp[k])/(dev_tmp[k])


        return norm_dyn,norm_pop_dyn,norm_spn_dyn

    if flg_spn=="pert":
        rate_pert=rates[1]
        n_trial_pert=len(rate_pert[0])
        n_tsmp_pert =len(rate_pert[0,0])
        flt_pop_dyn_pert=np.zeros((n_trial_pert,n_tsmp_pert,n_cell))
        for i in range(len(flt_pop_dyn_pert)):
            for k in range(n_cell):
                flt_pop_dyn_pert[i,:,k]=flt.gaussian_filter(rate_pert[k,i,:],1)
    
        norm_pop_dyn_pert=np.zeros(flt_pop_dyn_pert.shape)
        for i in range(len(norm_pop_dyn_pert)):
            for k in range(n_cell):
                norm_pop_dyn_pert[i,:,k]=(flt_pop_dyn_pert[i,:,k]-ave_tmp[k])/(dev_tmp[k])
        if if_unfam:
            return norm_dyn,norm_pop_dyn,norm_pop_dyn_pert,norm_pop_dyn_unfam
        else:
            return norm_dyn,norm_pop_dyn,norm_pop_dyn_pert
    return norm_dyn,norm_pop_dyn
