import numpy as np
from scipy import linalg as LA


cEInp=0.01
GEInp=0.03
cEfb =0.05
GEfb =0.05

def get_rate_trial(inet,ipat,Si,nsmp,rex,spn_evk,ver):
    cnt=0
    scl=get_scl(Si)

    inv_bin_smp=0.1 #[ms-1]
#    inv_bin_smp=0.2 #[ms-1]  used only for analysis of sequence
    if spn_evk == 1:
#check point
        t_smp = 300
#        scl=get_scl(Si)

    #  check point  
#        str="rbr53_fb_rnd_norm%d_l%g%g-0.050.051-0.05200.05.rnd.txt1" %(inet,ipat,Si)
#        str="rbr53_fb_rnd_norm%d_l%g%g-0.050.050.5-0.120.txt1" %(inet,ipat,Si)
#        str="rbr52_rnd_norm%d_l%g%g-%g%g510.txt" % (inet,ipat,Si,cEInp,GEInp)    
#        str="rbr1_rnd_norm%d_l%g%g%g-%g-%g.txt3" % (inet,ipat,Si,scl,cEInp,GEInp)    
#        str="rbr1_rnd_%d_l%g%g1-0.01-0.05.txt3" % (inet,ipat,Si)
#        str="rbr53_fb_rnd_norm%d_l%g%g1-0.050.1-20-0.0080.32.rnd.txt1" %(inet,ipat,Si)    
        if ver==0:
            strtmp="rbr54_fb_rnd_norm%d_l%g%g%g-0.20.05-%d50-1.rnd.txt23" %(inet,ipat,Si,scl,rex)
        elif ver==1:
            strtmp="rbr54_fb_rnd_norm%d_l%g%g%g-0.20.05-%d50-1.rnd.txt21" %(inet,ipat,Si,scl,rex)
        elif ver==2:
            strtmp="rbr54_fb_rnd_norm%d_l%g%g%g-0.20.05-%d50-1.rnd.txt2" %(inet,ipat,Si,scl,rex)

    n_bin      =int(t_smp*inv_bin_smp)
    rate_tmp=np.zeros((nsmp,n_bin+1,3000))
    
    tmp=np.loadtxt(strtmp)

    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:
            cnt+=1
            if nsmp<=cnt:
                break
        if tmp[i,1]>=2000 and tmp[i,1]<5000:
            rate_tmp[cnt,int(tmp[i,0]*inv_bin_smp),tmp[i,1]-2000]+=1

    del tmp
    return rate_tmp[:,:,:]


def get_rate_inp(inet,ipat,Si,nsmp,rex,spn_evk,ver):
    cnt=0
    scl=get_scl(Si)

    inv_bin_smp=0.1 #[ms-1]
    if spn_evk == 1:
        t_smp = 300

        if ver==0:
            strtmp="rbr54_fb_rnd_norm%d_l%g%g%g-0.20.05-%d50-1.rnd.txt2" %(inet,ipat,Si,scl,rex)
        elif ver==1:
            strtmp="rbr54_fb_rnd_norm%d_l%g%g%g-0.20.05-%d50-1.rnd.txt21" %(inet,ipat,Si,scl,rex)

    n_bin      =int(t_smp*inv_bin_smp)
    rate_tmp=np.zeros((nsmp,n_bin+1,2000))
    
    tmp=np.loadtxt(strtmp)

    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:
            cnt+=1
            if nsmp<=cnt:
                break
        if tmp[i,1]<2000:
            rate_tmp[cnt,int(tmp[i,0]*inv_bin_smp),tmp[i,1]]+=1

    del tmp
    return rate_tmp[:,:,:]


def get_rate_trial_ext(inet,ipat,Si,nsmp,rex,spn_evk):
    cnt=0
    scl=get_scl(Si)
    scl=1.5

    inv_bin_smp=0.1 #[ms-1]
    if spn_evk == 1:
        t_smp = 500
#        scl=get_scl(Si)
#        str="rbr1_rnd_norm%d_l%g%g%g-%g-%g.txt3" % (inet,ipat,Si,scl,cEInp,GEInp)
#        str="rbr52_rnd_norm%d_l%g%g-%g%g510.txt" % (inet,ipat,Si,cEInp,GEInp)    
#        str="dbr6_1_0.txt"
#        str="rbr53_fb_rnd_norm%d_l%g%g-0.050.050.5-0.120.txt1" %(inet,ipat,Si)
#        str="rbr53_fb_rnd_norm%d_l%g0.4-0.050.050.7-0.05200.05.rnd.txt1" %(inet,ipat)
#        str="rbr53_fb_rnd_norm%d_l%g%g-0.050.051-0.05200.05.rnd.txt1" %(inet,ipat,Si)
#        str="rbr53_fb_rnd_norm%d_l%g%g1-0.050.1-20-0.0080.32.rnd.txt1" %(inet,ipat,Si)
#        str="rbr53_fb_rnd_norm%d_l%g%g2-0.050.1-20-0.0080.32500.rnd.txt1" %(inet,ipat,Si)
        str="rbr54_fb_rnd_norm%d_l%g%g%g-0.20.05-%d50-1.rnd.txt2" %(inet,ipat,Si,scl,rex)
    n_bin      =int(t_smp*inv_bin_smp)
    rate_tmp=np.zeros((nsmp,n_bin+1,5000))


    tmp=np.loadtxt(str)
    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:
            cnt+=1
            if nsmp<=cnt:
                break
        if tmp[i,1]<5000:
            rate_tmp[cnt,int(tmp[i,0]*inv_bin_smp),tmp[i,1]]+=1

    return rate_tmp




def get_scl(Si):

    """
    if Si==1:
        scl=1
    elif Si==0.9:
        scl=1.054
    elif Si==0.8:
        scl=1.118
    elif Si==0.7:
        scl=1.195
    elif Si==0.6:
        scl=1.291
    elif Si==0.5:
        scl=1.414
    elif Si==0.4:
        scl=1.581
    """

    if Si==0.6:
        scl=1
    elif Si==0.5:
        scl=1.2
    elif Si==0.4:
        scl=1.5
    elif Si==0.3:
        scl=2


    return scl



def get_behav(inet,ipat,Si,rex,nsmp):
    cnt=0
    behav_ind=np.zeros(nsmp)
    behav_list=[]
    colist=[]


#    scl=get_scl(Si)
#  check point  
#    str="rbt1_rnd_norm%d_l%g%g%g-%g-%g.txt3" % (inet,ipat,Si,scl,cEInp,GEInp)    
#    str="rbt52_rnd_norm%d_l%g%g-%g%g1010.txt" % (inet,ipat,Si,cEInp,GEInp)    
#    str="rbt_fb_rnd_norm%d_l%g0.41.581-0.010.03%g%g.txt" % (inet,ipat,cEfb,GEfb)    
#    str="rbt1_rnd_%d_l%g%g%g-0.01-0.05.txt3" % (inet,ipat,Si,scl)    
#    str="rbt53_fb_rnd_norm%d_l%g%g-0.050.050.5-0.120.txt1" %(inet,ipat,Si)

    str="rbt54_fb_rnd_norm%d_l%g%g1-0.20.05-%d50-1.rnd.txt2" %(inet,ipat,Si,rex)


#    str="rbt54_fb_rnd_norm%d_l%g%g1.5-0.20.05-%d50-0.004.rnd.txt22" %(inet,ipat,Si,rex)
    #    str="rbt53_fb_rnd_norm%d_l%g%g1-0.20.05-20-0.0050.30.003500.rnd.txt2" %(inet,ipat,Si)
#    str="rbt53_fb_rnd_norm%d_l%g%g1-0.20.1-200.0050.32500.rnd.txt1" %(inet,ipat,Si)
#    str="rbt53_fb_rnd_norm%d_l%g%g1-0.050.1-20-0.010.32500.rnd.txt1" %(inet,ipat,Si)
#    str="rbt53_fb_rnd_norm%d_l%g%g1-0.050.1-20-0.010.32.rnd.txt1" %(inet,ipat,Si)

    tmp=np.loadtxt(str)
    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:
            if tmp[i-1,1]>tmp[i-1,2]:
                behav_ind[cnt]=0
                behav_list.append(cnt)
            else:
                behav_ind[cnt]=1
                colist.append(cnt)
            cnt+=1
            if cnt>=nsmp-1:
                break

    if tmp[-1,1]>tmp[-1,2]:
        behav_ind[cnt]=0
        behav_list.append(cnt)
    else:
        behav_ind[cnt]=1
        colist.append(cnt)

    del tmp

    return behav_ind,behav_list,colist




def tmptmp_func(inet,Si):
    rate=np.zeros((7,50,31,3000))
    ave =np.zeros((7,3000))

    for i in range(7):
        rate[i,:,:,:]=get_rate_trial(inet,0.1*i,Si,50,1)
        ave[i,:]     =np.mean(np.mean(rate[i,:,10:25,:],axis=0),axis=0)

    rank=np.argsort(ave[0,:]-ave[6,:])
        
    return rate,ave,rank


def get_tune_curve(list_suc,Si):
    n_net=len(list_suc)
    n_smp=200
    n_inp=2000
    curve=np.zeros((n_net,n_inp,7))
    rate=np.zeros((n_net,7,n_inp))


    for i in range(n_net):
        rate_inp=np.zeros((7,n_smp,31,n_inp))
        for j in range(7):
            rate_inp[j,:,:,:]=get_rate_trial_ext(list_suc[i],0.1*j,Si,n_smp,1)[:,:,:2000]
            
        tmp=np.mean(np.mean(rate_inp[:,:,10:20,:],axis=1),axis=1)
        rate[i,:,:]=tmp[:,:]
        rank=np.argsort(np.mean(tmp[:,:],axis=0))
        curve[i,:,:]=np.transpose(tmp[:,rank])
        
    return curve,rate




def get_sim_reserver_act(list_suc,Si):
    n_net=len(list_suc)
    sim=np.zeros((n_net,2,7))

    for i in range(n_net):
        rate,ave,rank=tmptmp_func(list_suc[i],Si)

        for j in range(7):
            sim[i,0,j]=np.mean(ave[0,:]*ave[j,:])
            sim[i,1,j]=np.mean(ave[6,:]*ave[j,:])
            
    return sim




def calc_score_curve(inet,Si):
#    str="dbs6_rnd_%d--Fthr0.05-t20-te0.10.1-Si%g250-3.txt6" % (inet+1,Si)
#    if Si==1:
#        str="dbs6_rnd_%d-Si%g-3-0.010.05.txt6" % (inet,Si)
#    elif Si==0.25:
#        str="dbs6_rnd_norm_%d-Si%g2-3-0.010.05.txt6" % (inet,Si)
    
    scl=get_scl(Si)
#    str="dbs6_rnd_norm_%d-Si%g%g-0.010.05.txt6" % (inet,Si,scl)    
#    str="dbs53_fb_rnd_norm_%d-Si%g-0.050.051-0.0520-0.0050.05.rnd.txt1" % (inet,Si)
    str="dbs54_fb_rnd_norm_%d-Si%g1.5-0.20.05-2050-0.004.rnd.txt2" % (inet,Si)
    data=np.loadtxt(str)
    
    bin_size=50
    Tlrn=len(data[:,0])
    ave_score=np.zeros(Tlrn)

    for i in range(Tlrn-bin_size):
        ave_score[i]=np.mean(data[i:i+bin_size,1])

#    pl.plot(range(Tlrn-bin_size),ave_score[0:(Tlrn-bin_size)])
#    return

#    return 1-(1-ave_score[449])/2.0
    return ave_score



def get_ave_out_dyn(inet,ipat,Si,nsmp):
#check point     str="rbt1_rnd_%d_l%g%g1-0.01-0.05.txt3" % (inet,ipat,Si)
     str="rbt1_rnd_norm%d_l%g%g1-%g-%g.txt3" % (inet,ipat,Si,cEInp,GEInp)
     tmp=np.loadtxt(str)
     cnt=0
     i_strt=0
     ave_dyn=np.zeros((nsmp,3000,3))


     for i in range(len(tmp[:,0])):
         if i>0 and tmp[i,0]<tmp[i-1,0]:
             cnt+=1
             i_strt=i
             if cnt>=nsmp:
                 break


         ave_dyn[cnt,i-i_strt,:]=tmp[i,:3]


     return ave_dyn






def make_color_map(data_2d):
    (lx,ly)=data_2d.shape
    f=open("tmp.dat","w")
    for i in range(lx):
        for j in range(ly):
            str="%d %d %g\n" % (i,j,data_2d[i,j])
            f.write(str)
            str="%d %d %g\n" %(i,j+1,data_2d[i,j])
            f.write(str)
        f.write("\n")
        for j in range(ly):
            str="%d %d %g\n" % (i+1,j,data_2d[i,j])
            f.write(str)
            str="%d %d %g\n" % (i+1,j+1,data_2d[i,j])
            f.write(str)
        f.write("\n")

    f.close()
    

def gen_sim_core(rate025):

#    for i in range(7):
#        rate025[i,:,:,:]=gen_fig_rnd.get_rate_trial(7,i*0.1,1,50,1)
    ave025_trial=np.mean(rate025[:,:,:,:],axis=1)

    rank025=np.zeros((7,3000))
    for i in range(7):
        rank025[i,:]=np.argsort(np.mean(ave025_trial[i,17:20,:],axis=0))


    cores025=[]
    for i in range(7):
        cores025.append(list(rank025[i,-100:]))

    sim_core025=np.zeros((2,7))


    for i in range(7):
        sim_core025[0,i]=len(set(cores025[0])&set(cores025[i]))
        sim_core025[1,i]=len(set(cores025[6])&set(cores025[i]))

        
    """
    pl.plot(range(7),sim_core025[0,:])
    pl.plot(range(7),sim_core025[1,:])
    pl.show()
    """

    tmp_set=np.zeros((7,100))
    for i in range(7):
        for j in range(100):
            if cores025[i][j] in cores025[0]:
                tmp_set[i,j]=1
            else:
                tmp_set[i,j]=0

    make_color_map(tmp_set)


    return


def make_adj_curve(curve):
    n_net=len(curve)
    dev_curve=[]
    for i in range(n_net):

        # limitted neurons by cut off 
        """
        n_cell=len(curve[i][:,0])
        mean_act=np.mean(curve[i][:,:],axis=1)
        tot_mean=np.mean(mean_act)
        list_hi=[]
        for j in range(n_cell):
            if(mean_act[j]>tot_mean):
                list_hi.append(j)

        tmp_ary=np.zeros(len(list_hi))
        """
        """
        for j in list_hi:
            tmp=(curve[i][j,:]-np.mean(curve[i][j,:]))
            tmptmp=tmp/np.sum(np.abs(tmp[:]))
            tmp_ary[j]=np.std(tmptmp[:])
        """
        """
        tmptmp=np.zeros((len(list_hi),7))
        for j in range(len(list_hi)):
            tmp=(curve[i][list_hi[j],:]-np.mean(curve[i][list_hi[j],:]))
            tmptmp[j,:]=tmp[:]
        norm_fac=np.mean(np.abs(tmptmp))
        for j in range(len(list_hi)):
            tmp=tmptmp[j,:]/norm_fac
            tmp_ary[j]=np.std(tmp[:])
        """
        

        n_cell=len(curve[i][:,0])
        tmp_ary=np.zeros(n_cell)


        # normalized by vol of spikes of each cell
        """
        for j in range(n_cell):
#            tmp=(curve[i][j,:]-np.min(curve[i][j,:]))/(np.max(curve[i][j,:])-np.min(curve[i][j,:]))
#            tmp=curve[i][j,:]/np.sum(curve[i][j,:])
            tmp=(curve[i][j,:]-np.mean(curve[i][j,:]))
            tmptmp=tmp/np.sum(np.abs(tmp[:]))
            tmp_ary[j]=np.std(tmptmp[:])
        """

        # normalized by vol of spikes of all cells

        tmptmp=np.zeros((n_cell,7))
        for j in range(n_cell):
            tmp=(curve[i][j,:]-np.mean(curve[i][j,:]))
            tmptmp[j,:]=tmp[:]
        for j in range(n_cell):
            tmp=tmptmp[j,:]/np.mean(np.abs(tmptmp))
            tmp_ary[j]=np.std(tmp[:])


        dev_curve.append(tmp_ary)

    return dev_curve



def calc_var(dev_curve):
    rank=np.argsort(dev_curve[:])
    n=len(dev_curve)

    return dev_curve[rank[int(2*n/4.)]]-dev_curve[rank[int(n/4.)]],dev_curve[rank[int(2*n/4.)]],dev_curve[rank[int(3*n/4.)]]-dev_curve[rank[int(2*n/4.)]]
#    return dev_curve[rank[int(n/4.)]],dev_curve[rank[int(2*n/4.)]],dev_curve[rank[int(3*n/4.)]]





def make_overlp_curve(curve):
    n_cell=len(curve)
    over=np.zeros((n_cell,7,7))
    sum_ovr=np.zeros(n_cell)

    for i in range(n_cell):
        for j in range(7):
            for k in range(7):
                over[i,j,k]=np.mean(curve[i][:,j]*curve[i][:,k])

            over[i,j,:]/=np.mean(curve[i][:,j]*curve[i][:,j])

        for j in range(7):
            for k in range(7):
                if j != k:
                    sum_ovr[i]+=over[i,j,k]

    return over,sum_ovr

"""
for i in range(7):
...     for j in range(7):
...             sim_pat.append(behav[list_suc[i]-1][j])
...             sim_pat1.append((sim[i,0,j]-sim[i,1,j]))




for i in range(7):
...     x=np.linspace(0,6,7)
...     cor_beh07[i]=np.corrcoef(np.vstack((x,beh07[list_suc07[i]-1,:])))[0,1]



 for i in range(7):
...     tmp_ary=np.zeros(len(curve1[i][:,0]))
for j in range(100):
...             tmp=(curve1[i][j,:]-np.mean(curve1[i][j,:]))
...             tmp_ary[j]=np.std(tmp[:])
...     dev_curve[i,:]=tmp_ary[:]



or i in range(10):
...     for j in range(7):
...             beh025[i,j]=len(gen_fig_rnd.get_behav(i+1,j*0.1,0.25,200)[1])


curve025=gen_fig_rnd.get_tune_curve(list_suc025,0.25)


 for i in range(6):
...     inet=rd.randrange(2000)
...     mod_curve[3,i,:]=curve_tmp[6][0][0][10][inet][:]-np.mean(curve_tmp[6][0][0][10][inet][:])
mod_curve[2,i,:]=curve_tmp[0][0][0][16][inet][:]-np.mean(curve_tmp[0][0][0][16][inet][:]
"""




def gen_seq_figs(inet,S):
    npos=200

    rate=np.zeros((6,50,61,3000))
    for i in range(6):
        rate[i,:,:,:]=get_rate_trial(inet,i*0.1,1,50,1)


    ave_rate=np.mean(rate[:,:,:,:],axis=1)
    norm_ave_rate=np.zeros((6,61,3000))
    for j in range(6):
        for i in range(3000):
            norm_ave_rate[j,:,i]=ave_rate[j,:,i]/np.max(ave_rate[j,15:55,i])

    ave_pos=np.zeros((6,npos))
    peak_pos=np.zeros((6,npos))
    pos=range(40)
    rank_pos=np.zeros((6,npos))


    rank_frq_all=np.zeros(3000)
    rank_frq_all=np.argsort((np.mean(ave_rate[0,15:55,:],axis=0)+np.mean(ave_rate[5,15:55,:],axis=0)))


    rank_frq=np.zeros((6,3000))
    
    for i in range(6):
        rank_frq[i,:]=np.argsort(np.mean(ave_rate[i,15:55,:],axis=0))


    for j in range(6):
        for i in range(npos):
            idx_tmp=rank_frq[j,-(i+1)]
#1            idx_tmp=rank_frq_all[-(i+1)]
            ave_pos[j,i] =np.mean(ave_rate[j,15:55,idx_tmp]*pos[:],axis=0)*len(pos[:])/np.sum(ave_rate[j,15:55,idx_tmp],axis=0)
            peak_pos[j,i]=np.argmax(ave_rate[j,15:55,idx_tmp])

#        rank_pos[j,:]=map(int,np.argsort(ave_pos[j,:]))
        rank_pos[j,:]=map(int,np.argsort(peak_pos[j,:]))
    
#    return rank_pos,rank_frq_all,norm_ave_rate

 
#    return norm_ave_rate,rank_pos
    """
    for i in range(6):
        for j in range(6):
            pl.subplot(6,6,i*6+j+1)
    """

def PCA(P):
    m = sum(P) / float(len(P))
    P_m = P - m
    l,v = np.linalg.eig( np.dot(P_m.T,P_m) )
    idx=l.argsort()
    l=l[idx][::-1]
    v=v[:,idx][:,::-1]
    return l,v.T



def get_selected_raster(list_sort,nsmp,tmp): # tmp: raster data
    cnt=0
    rstr=[]
    #check point
    Nstim=2000


    for i in range(nsmp):
        rstr.append([])
        rstr[i].append(np.zeros(2))

    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:
            cnt+=1
            if cnt>=nsmp:
                break
        if (tmp[i,1]-Nstim) in list_sort:
            idx_tmp=int(tmp[i,1]-Nstim)
            tmp_ary=np.array([tmp[i,0],list_sort.index(idx_tmp)])
            rstr[cnt]=np.vstack((rstr[cnt],tmp_ary))
    return rstr

    


def get_tune_curve_all(list_suc):
    curve=[[],[],[],[],[],[]]

    for i in range(1,6):
        curve[i].append(get_tune_curve(list_suc[i],(1-i*0.1)))

    return curve




#####  analysis exp data #####
"""
list_rat=[807,879,880,897,940,941,949,902]
curve=np.zeros((5,10,7))

for i in range(5):
...     tmp=functions.get_exp_data(list_rat[i],1)
...     curve.append(tmp[0])
...     freq[i,:]=tmp[1]

for i in range(5):
...     for j in range(len(curve[i])):
...             for k in range(len(curve[i][j,:])):
...                     f.write("%g " % curve[i][j,k])
...             f.write("\n")


for i in range(5):
...     f.write("%g %d\n" % (cor_beh[i],len(curve[i])))
"""





def calc_coreff(data):
    if data[0]==0 and data[6] ==0:
        return 0

    x=np.linspace(0,6,7)
    data=data[:]/(data[0]-data[6])
    cor_behav=np.corrcoef(np.vstack((x,data[:])))[0,1]

    return cor_behav






def tmp_fig_coreff(cor_beh,cor_FDA,list_beh):
    for i in range(7):
        for j in range(30):
            if(list_beh[i,j,0]+(50-list_beh[i,j,6])>75):
                print i,j,cor_beh[i,j],cor_FDA[i,j,0]
#                pl.scatter(-cor_beh[i,j],-(cor_FDA[i,j,0]+cor_FDA[i,j,1])/2,1)


 #   pl.show()


def gen_smp_PCA(rate):
    smp=rate[0,:,10,:]

    for i in range(1,15):
        smp=np.vstack((smp,rate[0,:,10+i,:]))


    for i in range(15):
        smp=np.vstack((smp,rate[6,:,10+i,:]))

    rank=np.argsort(np.mean(np.mean((rate[0,:,10:25,:]+rate[6,:,10:25,:]),axis=0),axis=0)) 

    PCs=PCA(smp[:,rank[-500:]])


    return PCs





def gen_PCA_dyn(PCs,rate,beh):

    PCA_dyn=np.zeros((7,200,15,3))

    for i in range(7):
        for j in range(15):
            for k in range(200):
                PCA_dyn[i,k,j,0]=np.mean(PCs[1][0,:]*rate[i,k,j+10,:])
                PCA_dyn[i,k,j,1]=np.mean(PCs[1][1,:]*rate[i,k,j+10,:])
                PCA_dyn[i,k,j,2]=np.mean(PCs[1][2,:]*rate[i,k,j+10,:])


    PCA_dyn_ave=np.zeros((7,2,15,3))

    for i in range(7):
        PCA_dyn_ave[i,0,:,:]=np.mean(PCA_dyn[i,beh[i],:,:],axis=0)

    for i in range(7):
        tmp=list(set(range(200))-set(beh[i]))
        PCA_dyn_ave[i,1,:,:]=np.mean(PCA_dyn[i,tmp,:,:],axis=0)


    return PCA_dyn,PCA_dyn_ave





def gen_distr_FDA(rate,n_smp):
    n_dim=300


    data11=np.mean(rate[0,:,10:15,:],axis=1).T
    data12=np.mean(rate[6,:,10:15,:],axis=1).T
    data21=np.mean(rate[0,:,15:20,:],axis=1).T
    data22=np.mean(rate[6,:,15:20,:],axis=1).T
    data31=np.mean(rate[0,:,20:25,:],axis=1).T
    data32=np.mean(rate[6,:,20:25,:],axis=1).T

    rank=np.argsort(np.mean(np.mean((rate[0,:,10:25,:]+rate[6,:,10:25,:]),axis=0),axis=0)) 



    distr=np.zeros((3,7,n_smp,3))

    for i in range(7):
        data=np.mean(rate[i,:,10:15,:],axis=1).T
        distr[0,i,:,0]=np.dot(Wopt1.T,data[non_zero_cell[-n_dim:],:])
        distr[0,i,:,1]=np.dot(Wopt2.T,data[non_zero_cell[-n_dim:],:])
        distr[0,i,:,2]=np.dot(Wopt3.T,data[non_zero_cell[-n_dim:],:])

        data=np.mean(rate[i,:,15:20,:],axis=1).T
        distr[1,i,:,0]=np.dot(Wopt1.T,data[non_zero_cell[-n_dim:],:])
        distr[1,i,:,1]=np.dot(Wopt2.T,data[non_zero_cell[-n_dim:],:])
        distr[1,i,:,2]=np.dot(Wopt3.T,data[non_zero_cell[-n_dim:],:])

        data=np.mean(rate[i,:,20:25,:],axis=1).T
        distr[2,i,:,0]=np.dot(Wopt1.T,data[non_zero_cell[-n_dim:],:])
        distr[2,i,:,1]=np.dot(Wopt2.T,data[non_zero_cell[-n_dim:],:])
        distr[2,i,:,2]=np.dot(Wopt3.T,data[non_zero_cell[-n_dim:],:])


    return distr

    """
    for i in range(5):
        pl.subplot(5,1,i+1)
        for j in beh[ipat][0]:
            pl.plot(range(25),dyn[ipat,j,i,:],c="blue")
        for j in beh[ipat][1]:
            pl.plot(range(25),dyn[ipat,j,i,:],c="red")
        for j in beh[ipat][2]:
            pl.plot(range(25),dyn[ipat,j,i,:],c="green")

    pl.show()
    """
        


def get_FDA_dyn(list_suc,Si):

    n_smp=800
    rex=20

    fda_dyn=np.zeros((len(list_suc),7,n_smp,25))
    fda_dyn1=np.zeros((len(list_suc),7,n_smp,25))

    for inet in range(len(list_suc)):
        rate=np.zeros((7,n_smp,31,3000))
        listL=[]
        listR=[]

        for j in range(7):
            rate[j,:,:,:]=get_rate_trial(list_suc[inet],0.1*j,Si,n_smp,rex,1)
            _,tmp,tmp1=get_behav(list_suc[inet],0.1*j,Si,rex,n_smp)
            listL.append(tmp)
            listR.append(tmp1)

        data1=np.mean(rate[0,listL[0],10:25,:],axis=1).T
        data1=np.hstack((data1,np.mean(rate[6,listL[6],10:25,:],axis=1).T))

        data2=np.mean(rate[0,listR[0],10:25,:],axis=1).T
        data2=np.hstack((data2,np.mean(rate[6,listR[6],10:25,:],axis=1).T))

        rank=np.argsort(np.mean(np.mean((rate[0,:,10:25,:]+rate[6,:,10:25,:]),axis=0),axis=0)) 

        for i in range(7):
            for k in  range(25):
                fda_dyn[inet,i,:,k]=np.dot(Wopt.T,rate[i,:,k,rank[-300:]])


        data1=np.mean(rate[0,listL[0],10:25,:],axis=1).T
        for j in range(1,6):
            data1=np.hstack((data1,np.mean(rate[j,listL[j],10:25,:],axis=1).T))

        data2=np.mean(rate[0,listR[0],10:25,:],axis=1).T
        for j in  range(1,6):
            data2=np.hstack((data2,np.mean(rate[j,listR[j],10:25,:],axis=1).T))

        rank=np.argsort(np.mean(np.mean(np.mean(rate[:,:,10:25,:],axis=0),axis=0),axis=0)) 


        for i in range(7):
            for k in  range(25):
                fda_dyn1[inet,i,:,k]=np.dot(Wopt.T,rate[i,:,k,rank[-300:]])

    return fda_dyn,fda_dyn1










def get_behav1(inet,ipat,Si,rex,nsmp,ver,diff):
    cnt=0
    behav_ind=np.zeros(nsmp)
    behav_list=[]
    colist=[]
    t_end=np.zeros(nsmp)
    scl=get_scl(Si)
    scl=1.5

    if ver==0:
        str="rbt54_fb_rnd_norm%d_l%g%g%g-0.20.05-%d50-10.01.rnd.txt2" %(inet,ipat,Si,scl,rex)
    elif ver==1:
        str="rbt54_fb_rnd_norm%d_l%g%g%g-0.20.05-%d50-1.rnd.txt21" %(inet,ipat,Si,scl,rex)
    elif ver==2:
        str="rbt54_fb_rnd_norm%d_l%g%g%g-0.20.05-%d50-1.rnd.txt22" %(inet,ipat,Si,scl,rex)
    elif ver==3:
        str="rbt54_fb_rnd_norm%d_l%g%g%g-0.20.05-%d50-1.rnd.txt23" %(inet,ipat,Si,scl,rex)
        str1="rbt54_fb_rnd_norm%d_l%g%g%g-0.20.05-%d50-1.rnd.txt24" %(inet,ipat,Si,scl,rex)
        str2="rbt54_fb_rnd_norm%d_l%g%g%g-0.20.05-%d50-1.rnd.txt25" %(inet,ipat,Si,scl,rex)


    tmp=np.loadtxt(str)
    if ver==3:
        tmp=np.vstack((tmp,np.loadtxt(str1)))
        tmp=np.vstack((tmp,np.loadtxt(str2)))


    tmptmp=tmp[0,1:3]
    flg=3

    #check point
    traj=np.zeros((nsmp,501,2))


    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:
            # criterion for correct trials
            flg=3
            """
            for j in range(50):
                if (flg==3 or flg==1) and tmptmp[j+200,0]>tmptmp[j+200,1]+diff:
                    flg=1
                elif (flg==3 or flg==2) and tmptmp[j+200,0]+diff<tmptmp[j+200,1]:
                    flg=2
                else:
                    flg=0
            """
    #check point
#            for j in range(250,len(tmptmp)):
            for j in range(250,301):
                if tmptmp[j,0] - tmptmp[j,1]>diff:
                    flg=1
                    t_end[cnt]=j
                    break
                elif tmptmp[j,1] - tmptmp[j,0]>diff:
                    flg=2
                    t_end[cnt]=j
                    break

            if flg==1:
                behav_list.append(cnt)
            elif flg==2:
                colist.append(cnt)

            traj[cnt]=tmptmp
            tmptmp=tmp[i,1:3]

            cnt+=1
            if cnt>=nsmp:
                break

        elif i>0:
            tmptmp=np.vstack((tmptmp,tmp[i,1:3]))



    if cnt<=nsmp-1:
        flg=3

    #check point
        for j in range(250,len(tmptmp)):
            if tmptmp[j,0] - tmptmp[j,1]>diff:
                flg=1
                t_end[cnt]=j
                break
            elif tmptmp[j,1] - tmptmp[j,0]>diff:
                flg=2
                t_end[cnt]=j
                break

        """
        for j in range(5):
            if (flg==3 or flg==1) and tmptmp[j+200,0]>tmptmp[j+200,1]+diff:
                flg=1
            elif (flg==3 or flg==2) and tmptmp[j+200,0]+diff<tmptmp[j+200,1]:
                flg=2
            else:
                flg=0
        """
        if flg==1:
            behav_list.append(cnt)
        elif flg==2:
            colist.append(cnt)

        traj[cnt]=tmptmp

    del tmp

    return behav_ind,behav_list,colist,t_end
#    return traj











def gen_distr_fda(fda_dyn,t_end,nsmp):

    distr=np.zeros((7,nsmp))
    for i in range(7):
        tmp=np.zeros(nsmp)
        for j in range(nsmp):
            if t_end[i,j]<10:
                tmp[j]=0
            else:
                tmp[j]=(np.mean(fda_dyn[i,j,int(t_end[i,j]/10.)-5:int(t_end[i,j]/10.0)]))
        distr[i]=tmp[:]

    return distr


def gen_ens_rank(rate,listL,listR,t_end):
    n_cell=len(rate[0,0,0,:])
    
    data1=gen_ens(rate,listL,t_end,n_cell)
    data2=gen_ens(rate,listR,t_end,n_cell)

    tmp=np.zeros(n_cell)
    ipat=0
 #   for i in range(len(t_end[ipat,:])):
    for i in listL[ipat]:
        tmp[:]=tmp[:]+np.mean(rate[ipat,i,int(t_end[ipat,i]/10.)-5:int(t_end[ipat,i]/10.),:],axis=0)
    for i in listR[ipat]:
        tmp[:]=tmp[:]+np.mean(rate[ipat,i,int(t_end[ipat,i]/10.)-5:int(t_end[ipat,i]/10.),:],axis=0)



    ipat=6
#    for i in range(len(t_end[ipat,:])):
    for i in listL[ipat]:
        tmp[:]=tmp[:]+np.mean(rate[ipat,i,int(t_end[ipat,i]/10.)-5:int(t_end[ipat,i]/10.),:],axis=0)
    for i in listR[ipat]:
        tmp[:]=tmp[:]+np.mean(rate[ipat,i,int(t_end[ipat,i]/10.)-5:int(t_end[ipat,i]/10.),:],axis=0)


    tmp[:]/=(len(listL[0])+len(listR[0])+len(listL[6])+len(listR[6]))

    rank=np.argsort(tmp)

    return data1,data2,rank


def gen_ens(rate,list_tmp,t_end,n_cell):

    data1=np.zeros((n_cell,1))
    ipat=0
    for i in list_tmp[ipat]:
        data1=np.hstack((data1,np.mean(rate[ipat,i,int(t_end[ipat,i]/10.)-5:int(t_end[ipat,i]/10.),:],axis=0).reshape(n_cell,1)))

    ipat=6
    for i in list_tmp[ipat]:
        data1=np.hstack((data1,np.mean(rate[ipat,i,int(t_end[ipat,i]/10.)-5:int(t_end[ipat,i]/10.),:],axis=0).reshape(n_cell,1)))

    data1=np.delete(data1,0,1)

    return data1




    



def get_FDA_dyn1(list_suc,Si,n_smp,ndim,diff,flg):
    rex=20

    fda_dyn=np.zeros((len(list_suc),7,n_smp,31))
    fda_dyn1=np.zeros((len(list_suc),7,n_smp,31))
    t_end=np.zeros((len(list_suc),7,n_smp))
    listL=[]
    listR=[]
    distr=[]


    for inet in range(len(list_suc)):
        if(flg==0):
            rate=np.zeros((7,n_smp,31,3000))
        elif flg==1:
            rate=np.zeros((7,n_smp,31,2000))

        listL.append([])
        listR.append([])


        for i in range(7):
            if flg==0:
                rate[i]=get_rate_trial(list_suc[inet],0.1*i,Si,n_smp,rex,1,0)
            elif flg==1:
                rate[i]=get_rate_inp(list_suc[inet],0.1*i,Si,n_smp,rex,1,0)


            _,tmp,tmp1,t_end[inet,i,:]=get_behav1(list_suc[inet],0.1*i,Si,rex,n_smp,0,diff)
            listL[inet].append(tmp)
            listR[inet].append(tmp1)



        data1,data2,rank=gen_ens_rank(rate,listL[inet],listR[inet],t_end[inet])


        for i in range(7):
            for k in range(31):
                fda_dyn[inet,i,:,k]=np.dot(Wopt.T,rate[i,:,k,rank[-ndim:]])

        distr.append(gen_distr_fda(fda_dyn[inet],t_end[inet],n_smp))


    return fda_dyn,distr,t_end,listL,listR



def get_ave_fda(inet,Si,listL,listR):

    str="distr_inp%g-%d.npy" % (Si,inet)
    distr=np.load(str)

    tmp=np.zeros((7,3))

    for i in range(7):
        tmp[i,0]=np.mean(distr[i,listL[i]],axis=0)
        tmp[i,1]=np.mean(distr[i,listR[i]],axis=0)
        tmp[i,2]=(np.sum(distr[i,listL[i]],axis=0)+np.sum(distr[i,listR[i]],axis=0))/(len(listL[i])+len(listR[i]))

    return tmp



def get_list(Si,n_net):

    listL=[]
    listR=[]
    for i in range(n_net):
        listL.append([])
        listR.append([])


    str="listL%g.dat" % Si
    tmplist=[]
    for line in open(str,"r"):
        tmplist.append(line[:-2].split(" "))

    for i in range(len(tmplist)):
        for j in range(len(tmplist[i])):
            tmplist[i][j]=int(tmplist[i][j])
 
    for i in range(n_net):
        for j in range(7):
            listL[i].append([])
            listL[i][j]=tmplist[i*7+j]    


    str="listR%g.dat" % Si
    tmplist=[]
    for line in open(str,"r"):
        tmplist.append(line[:-2].split(" "))

    for i in range(len(tmplist)):
        for j in range(len(tmplist[i])):
            tmplist[i][j]=int(tmplist[i][j])
 
    for i in range(n_net):
        for j in range(7):
            listR[i].append([])
            listR[i][j]=tmplist[i*7+j]    

    return listL,listR



def get_beh_allnets(suc_list,Si):

    listL,listR=get_list(Si,len(suc_list))

    beh=np.zeros((len(suc_list),7,2))

    for i in range(len(suc_list)):
        for j in range(7):
            _,tmp,tmp1,_=get_behav1(suc_list[i],0.1*j,Si,20,1000,0,0.02)
            beh[i,j,0]=len(tmp)
            beh[i,j,1]=len(tmp1)

    ave_fda=np.zeros((len(suc_list),7,3))

    for i in range(len(suc_list)):
        ave_fda[i]=get_ave_fda(suc_list[i],Si,listL[i],listR[i])

    return beh,ave_fda




def get_pca_fda(rate,listL,listR,t_end,nsmp,npca):

    listS=[]
    for i in range(7):
        listS.append([])
        listS[i]=list(np.sort(listL[i]+listR[i]))
        del listS[i][nsmp:]


    idx_L=[]
    idx_R=[]
    for i in range(7):
        idx_L.append([])
        idx_R.append([])
        for j in listL[i]:
            if j in listS[i]:
                idx_L[i].append(listS[i].index(j))
        for j in listR[i]:
            if j in listS[i]:
                idx_R[i].append(listS[i].index(j))


    # prepare data ensemble for PCA
    smp_PCA=np.zeros((1,3000))
    for i in range(7):
        for j in listS[i]:
            smp_PCA=np.vstack((smp_PCA,rate[i,j,:,:]))
 
    smp_PCA=np.delete(smp_PCA,0,0)


    # get dynamics in the pca space and its temporal average dynamics
    PCs=PCA(smp_PCA)

    PCA_dyn=np.zeros((7,nsmp,31,npca))
    for i in range(7):
        for j in range(len(idx_L[i])):
            for k in range(npca):
                PCA_dyn[i,idx_L[i][j],:,k]      =np.mean((PCs[1][k,:].reshape(3000,1))*(rate[i,listL[i][j],:,:].T),axis=0)
        for j in range(len(idx_R[i])):
            for k in range(npca):
                PCA_dyn[i,idx_R[i][j],:,k]      =np.mean((PCs[1][k,:].reshape(3000,1))*(rate[i,listR[i][j],:,:].T),axis=0)


    PCA_dyn_ave=np.zeros((7,nsmp,31-5,npca))
    for i in range(7):
        for j in range(nsmp):
            for k in range(26):
                PCA_dyn_ave[i,j,k,:]=np.mean(PCA_dyn[i,j,k:k+5,:],axis=0)


    # get discriminant plane
                # in terms of response
    ipat=0
    data1=(PCA_dyn_ave[ipat,idx_L[ipat],(t_end[ipat][listL[ipat][:len(idx_L[ipat])]]/10.-5).astype(np.int64),:]).T
    data2=(PCA_dyn_ave[ipat,idx_R[ipat],(t_end[ipat][listR[ipat][:len(idx_R[ipat])]]/10.-5).astype(np.int64),:]).T

    ipat=6
    data1=np.hstack((data1,(PCA_dyn_ave[ipat,idx_L[ipat],(t_end[ipat][listL[ipat][:len(idx_L[ipat])]]/10.-5).astype(np.int64),:]).T))
    data2=np.hstack((data2,(PCA_dyn_ave[ipat,idx_R[ipat],(t_end[ipat][listR[ipat][:len(idx_R[ipat])]]/10.-5).astype(np.int64),:]).T))



    # get fda dynamics
    fda_pca=np.zeros((7,nsmp,31-5,2))

    for i in range(7):
        for j in range(nsmp):
             fda_pca[i,j,:,0]=np.dot(Wopt.T,PCA_dyn_ave[i,j,:26,:].T)
             fda_pca[i,j,:,1]=np.dot(Wopt1.T,PCA_dyn_ave[i,j,:26,:].T)

    fda_pca_ave=np.zeros((7,2))
    for ipat in range(7):
        fda_pca_ave[ipat,0]=np.mean(fda_pca[ipat,idx_L[ipat],(t_end[ipat][listL[ipat][:len(idx_L[ipat])]]/10.-5).astype(np.int64),0])
        fda_pca_ave[ipat,1]=np.mean(fda_pca[ipat,idx_R[ipat],(t_end[ipat][listR[ipat][:len(idx_R[ipat])]]/10.-5).astype(np.int64),0])


    return fda_pca_ave,fda_pca,Wopt,Wopt1,PCA_dyn_ave



def get_pca_fda1(listL,listR,nsmp):

    listS=[]
    for i in range(7):
        listS.append([])
        listS[i]=list(np.sort(listL[i]+listR[i]))
        del listS[i][nsmp:]


    idx_L=[]
    idx_R=[]
    for i in range(7):
        idx_L.append([])
        idx_R.append([])
        for j in listL[i]:
            if j in listS[i]:
                idx_L[i].append(listS[i].index(j))
        for j in listR[i]:
            if j in listS[i]:
                idx_R[i].append(listS[i].index(j))

    return idx_L,idx_R




"""
for j in range(1,5):
...     for i in range(7):
...             rate=gr.get_rate_trial(list_net[j],0.1*i,0.4,50,20,1,0)
...             str="rate_long_inp%d_%d-0.4.npy" % (list_net[j],i)
...             np.save(str,rate)
...     rate=gr.get_rate_trial(list_net[j],-1,0.4,50,20,1,0)
...     str="rate_long_inp%d_-1-0.4.npy" % list_net[j]
...     np.save(str,rate)
"""



def get_wopt(inet):
    nsmp=100
    npca=75


    PCA_dyn,PCA_dyn_ave=get_pca_dyn(inet,nsmp,npca)

    data1=PCA_dyn_ave[0,:,34,:].T
    data2=PCA_dyn_ave[6,:,34,:].T

    prj_dyn=np.zeros((8,nsmp,35,2))

    for i in range(8):
        for j in range(nsmp):
            for k in range(35):
                prj_dyn[i,j,k,0]=np.mean(Wopt.T*PCA_dyn_ave[i,j,k,:])


    rate0=np.load("rate_long_inp%d_-1-0.4.npy2.npy" % inet)

    PCA_dyn_tmp=np.zeros((nsmp*2,40,npca))
    PCA_dyn_tmp[:nsmp,:,:]=PCA_dyn[7]
    for j in range(nsmp):
        for k in range(npca):
            PCA_dyn_tmp[j+nsmp,:,k]=np.mean((PCs[1][k,:].reshape(3000,1))*(rate0[j,11:51,:].T),axis=0)

    PCA_dyn_ave_tmp=np.zeros((nsmp*2,35,npca))
    for j in range(nsmp*2):
        for k in range(35):
            PCA_dyn_ave_tmp[j,k,:]=np.mean(PCA_dyn_tmp[j,k:k+5,:],axis=0)

    beh=get_behav1(inet,-1,0.4,20,nsmp*2,3,0.03)

    data1=(PCA_dyn_ave_tmp[beh[1],(beh[3][beh[1]]/10.-16).astype(np.int64),:]).T
    data2=(PCA_dyn_ave_tmp[beh[2],(beh[3][beh[2]]/10.-16).astype(np.int64),:]).T
   

    for i in range(8):
        for j in range(nsmp):
            for k in range(35):
                prj_dyn[i,j,k,1]=np.mean(Wopt1.T*PCA_dyn_ave[i,j,k,:])

    

    return PCA_dyn,PCA_dyn_ave,prj_dyn,Wopt,Wopt1,beh




def get_wopt1(inet,ipat,PCA_dyn,PCA_dyn_ave):  # between stat at beginning and at end
    nsmp=100
    npca=75

    data1=PCA_dyn_ave[ipat,:,0,:].T
    data2=PCA_dyn_ave[ipat,:,34,:].T

    prj_dyn=np.zeros((8,nsmp,35))

    for i in range(8):
        for j in range(nsmp):
            for k in range(35):
                prj_dyn[i,j,k]=np.mean(Wopt.T*PCA_dyn_ave[i,j,k,:])

    return prj_dyn,Wopt




def get_pca_dyn(inet,nsmp,npca):

    rate=np.zeros((7,nsmp,51,3000))
    for i in range(7):
        rate[i]=np.load("rate_long_inp%d_%d-0.4.npy1.npy" % (inet,i))[:,:,:]
    rate0=np.load("rate_long_inp%d_-1-0.4.npy1.npy" % inet)[:,:,:]

    #check point
#    smp_PCA=rate[:,:,11:51,:].reshape(7*nsmp*40,3000)
#    smp_PCA=np.vstack((smp_PCA,rate0[:,11:51,:].reshape(nsmp*40,3000)))
    
    smp_PCA=np.mean(rate[:,:,11:11+5,:],axis=2).reshape(7*nsmp,3000)
    smp_PCA=np.vstack((smp_PCA,np.mean(rate0[:,11:11+5,:],axis=1).reshape(nsmp,3000)))

    for i in range(1,35):
        smp_PCA=np.vstack((smp_PCA,np.mean(rate[:,:,11+i:11+5+i,:],axis=2).reshape(7*nsmp,3000)))
        smp_PCA=np.vstack((smp_PCA,np.mean(rate0[:,11+i:11+5+i,:],axis=1).reshape(nsmp,3000)))


    PCs=PCA(smp_PCA)


    PCA_dyn=np.zeros((8,nsmp,40,npca))

    for i in range(7):
        for j in range(nsmp):
             for k in range(npca):
                 PCA_dyn[i,j,:,k]=np.mean((PCs[1][k,:].reshape(3000,1))*(rate[i,j,11:51,:].T),axis=0)


    for j in range(nsmp):
        for k in range(npca):
            PCA_dyn[7,j,:,k]=np.mean((PCs[1][k,:].reshape(3000,1))*(rate0[j,11:51,:].T),axis=0)


    PCA_dyn_ave=np.zeros((8,nsmp,35,npca))
    for i in range(8):
        for j in range(nsmp):
            for k in range(35):
                PCA_dyn_ave[i,j,k,:]=np.mean(PCA_dyn[i,j,k:k+5,:],axis=0)

    return PCA_dyn,PCA_dyn_ave




def tmpfig(pca_fda75,y1,y2):


    y1=[-0.7,-2.5,-1.5,-2.,-1.5,-3.5]
    y2=[2,1.6,2.5,2.5,2,0.6]

    """  for Wopt1
    [-0.5, -0.8, -0.8, -1, -2, -1.1]
    [0.5, 1.0, 0.8, 0.8, 1.5, 1.2]
    """





def tmp_get_pca_dyn(inet,npca):

    rate=np.zeros((7,150,51,3000))
    for i in range(7):
        str="rate_long_inp%d_%d-0.4.npy" % (inet,i)
        tmp=np.load(str)
        rate[i,:50]=tmp[:,:,:]
        str="rate_long_inp%d_%d-0.4.npy1.npy" % (inet,i)
        tmp=np.load(str)
        rate[i,50:]=tmp[:,:,:]

    pcsmp=np.mean(rate[:,:,45:50,:],axis=2).reshape(7*150,3000)
    PCs=PCA(pcsmp)


    ave_rate=np.zeros((7,150,46,3000))

    for i in range(7):
        for j in range(150):
            for k in range(46):
                ave_rate[i,j,k,:]=np.mean(rate[i,j,k:k+5,:],axis=0)


    pca_dyn=np.zeros((7,150,46,20))

    for i in range(7):
        for j in range(150):
            for k in range(20):
                pca_dyn[i,j,:,k]=np.dot(PCs[1][k,:],ave_rate[i,j,:,:].T)

    return pca_dyn,PCs



def tmp_get_svd_dyn(inet,npca):

    rate=np.zeros((7,150,51,3000))
    for i in range(7):
        str="rate_long_inp%d_%d-0.4.npy" % (inet,i)
        tmp=np.load(str)
        rate[i,:50]=tmp[:,:,:]
        str="rate_long_inp%d_%d-0.4.npy1.npy" % (inet,i)
        tmp=np.load(str)
        rate[i,50:]=tmp[:,:,:]

    pcsmp=np.mean(rate[:,:,45:50,:],axis=2).reshape(7*150,3000)
    svd=np.linalg.svd(pcsmp)


    ave_rate=np.zeros((7,150,46,3000))

    for i in range(7):
        for j in range(150):
            for k in range(46):
                ave_rate[i,j,k,:]=np.mean(rate[i,j,k:k+5,:],axis=0)


    svd_dyn=np.zeros((7,150,46,20))

    for i in range(7):
        for j in range(150):
            for k in range(20):
                svd_dyn[i,j,:,k]=np.dot(svd[2][k,:],ave_rate[i,j,:,:].T)

    return svd_dyn,svd


def tmp_get_out_dyn(inet,Wout,flg):

    if flg==0:
        rate=np.zeros((7,150,51,3000))
        for i in range(7):
            str="rate_long_inp%d_%d-0.4.npy" % (inet,i)
            tmp=np.load(str)
            rate[i,:50]=tmp[:,:,:]
            str="rate_long_inp%d_%d-0.4.npy1.npy" % (inet,i)
            tmp=np.load(str)
            rate[i,50:]=tmp[:,:,:]


        ave_rate=np.zeros((7,150,46,3000))
        
        for i in range(7):
            for j in range(150):
                for k in range(46):
                    ave_rate[i,j,k,:]=np.mean(rate[i,j,k:k+5,:],axis=0)


        out_dyn=np.zeros((7,2,150,46))
        for i in range(7):
            for j in range(46):
                out_dyn[i,0,:,j]=np.dot(ave_rate[i,:,j,:],Wout[0])
                out_dyn[i,1,:,j]=np.dot(ave_rate[i,:,j,:],Wout[1])


    if flg==1:  # read  spontaneous activity
        rate=np.zeros((150,51,3000))
        str="rate_long_inp%d_%d-0.4.npy" % (inet,-1)
        tmp=np.load(str)
        rate[:50]=tmp[:,:,:]
        str="rate_long_inp%d_%d-0.4.npy1.npy" % (inet,-1)
        tmp=np.load(str)
        rate[50:]=tmp[:,:,:]


        ave_rate=np.zeros((150,46,3000))
        
        for j in range(150):
            for k in range(46):
                ave_rate[j,k,:]=np.mean(rate[j,k:k+5,:],axis=0)


        out_dyn=np.zeros((2,150,46))
        for j in range(46):
            out_dyn[0,:,j]=np.dot(ave_rate[:,j,:],Wout[0])
            out_dyn[1,:,j]=np.dot(ave_rate[:,j,:],Wout[1])




    return out_dyn


def calc_angl(W1,W2,Wopt):

    a=np.sum(W1*Wopt)/np.sqrt(np.sum(W1*W1)*np.sum(Wopt*Wopt))
    b=np.sum(W2*Wopt)/np.sqrt(np.sum(W2*W2)*np.sum(Wopt*Wopt))

    return a*a+b*b
    

def tmp_get_sim(Si):

    if Si==0.4:
#        suc_list=[4,6,7,8,9,10,13,14,16,18,20,22,23,24,25,30]
        suc_list=[4,6,7,8,9,10,13,14,16,18]
    elif Si==0.6:
#        suc_list=[1,2,5,6,7,8,9,11,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]
        suc_list=[1,2,5,6,7,8,9,11,13,14]
#        suc_list=[1,2]
    else:
        print "incorrect argument"
        quit()

    rate=np.zeros((7,100,31,3000))
    ovlp=np.zeros((len(suc_list),2,7))
 
    for j in range(len(suc_list)):
        for i in range(7):
            rate[i]=get_rate_trial(suc_list[j],0.1*i,Si,100,20,1,2)

        for i in range(7):
            ovlp[j,1,i]=np.mean(np.mean(np.mean(rate[6,:,10:25,:],axis=0),axis=0)*np.mean(np.mean(rate[i,:,10:25,:],axis=0),axis=0))
            ovlp[j,0,i]=np.mean(np.mean(np.mean(rate[0,:,10:25,:],axis=0),axis=0)*np.mean(np.mean(rate[i,:,10:25,:],axis=0),axis=0))

    np.save("tmp_overlap%g.npy" % Si, ovlp)

    return

def tmp_make_fig(Si):
    tmp=np.load("tmp_overlap%g.npy" % Si)
    n_net=len(tmp[:,0,0])

    tmp_ovr=np.zeros((n_net,2,7))
    for i in range(n_net):
        tmp_ovr[i,0,:]=(tmp[i,0,:]-np.min(tmp[i,0,:]))/(tmp[i,0,0]-np.min(tmp[i,0,:]))
        tmp_ovr[i,1,:]=(tmp[i,1,:]-np.min(tmp[i,1,:]))/(tmp[i,1,6]-np.min(tmp[i,1,:]))

    ave_ovr=np.zeros((2,7))
    ave_ovr[:,:]=np.mean(tmp_ovr[:,:,:],axis=0)


    err_up=np.zeros((2,7))
    err_low=np.zeros((2,7))
    for i in range(7):
        err_low[0,i]=-(np.sort(tmp_ovr[:,0,i])[1]-np.mean(tmp_ovr[:,0,i]))
        err_up[0,i] =np.sort(tmp_ovr[:,0,i])[8]-np.mean(tmp_ovr[:,0,i])

        err_low[1,i]=-(np.sort(tmp_ovr[:,1,i])[1]-np.mean(tmp_ovr[:,1,i]))
        err_up[1,i] =np.sort(tmp_ovr[:,1,i])[8]-np.mean(tmp_ovr[:,1,i])




"""
Si=float(sys.argv[1])
#tmp_get_sim(Si)
#tmp_make_fig(Si)
beh=np.zeros((30,7,2))
for i in range(30):
    for j in range(7):
        tmp=(get_behav1(i+1,j*0.1,Si,20,100,0,0.005))
        beh[i,j,0]=len(tmp[1])
        beh[i,j,1]=len(tmp[2])


np.save("tmp_beh%g.npy" % Si, beh)
"""

#flg,J,Wopt[3],tmp=FDA.FDA2(pca_dyn4[0,:,45,:].T,pca_dyn4[6,:,45,:].T,range(20),20)
#Wout[3]=(np.loadtxt("dbd54_fb_rnd_norm_4-Si0.41.5-0.20.05-2050-0.004.rnd.txt2")[-3
"""
or j in range(7):
...     for k in range(46):
...             tmp_dyn[0,j,:,k]=np.dot(Wopt[0].T,pca_dyn[j,:,k,:].T).reshape(150)
...             tmp_dyn[1,j,:,k]=np.dot(Wopt[1].T,pca_dyn30[j,:,k,:].T).reshape(150)
...             tmp_dyn[2,j,:,k]=np.dot(Wopt[2].T,pca_dyn3[j,:,k,:].T).reshape(150)
...             tmp_dyn[3,j,:,k]=np.dot(Wopt[3].T,pca_dyn4[j,:,k,:].T).reshape(150)
000:,1:3]).T

dev_dyn_fda=np.zeros((4,7,46))
>>> for i in range(4):
...     for j in range(7):
...             dev_dyn_fda[i,j,:]=np.std(tmp_dyn[i,j,:,:],axis=0)


for j in range(7):
...     for k in range(46):
...             tmp_dyn[0,j,:,k]=np.dot(Wopt[0].T,pca_dyn[j,:,k,:].T).reshape(150)
...             tmp_dyn[1,j,:,k]=np.dot(Wopt[1].T,pca_dyn30[j,:,k,:].T).reshape(150)
...             tmp_dyn[2,j,:,k]=np.dot(Wopt[2].T,pca_dyn22[j,:,k,:].T).reshape(150)
...             tmp_dyn[3,j,:,k]=np.dot(Wopt[3].T,pca_dyn3[j,:,k,:].T).reshape(150)
...             tmp_dyn[4,j,:,k]=np.dot(Wopt[4].T,pca_dyn4[j,:,k,:].T).reshape(150)
...             tmp_dyn[5,j,:,k]=np.dot(Wopt[5].T,pca_dyn24[j,:,k,:].T).reshape(150)




inet=5
>>> ipat=0
>>> pl.scatter(out_dyn[inet,ipat,0,:,45],out_dyn[inet,ipat,1,:,45],c=c_set[ipat])
>>> ipat=2
>>> pl.scatter(out_dyn[inet,ipat,0,:,45],out_dyn[inet,ipat,1,:,45],c=c_set[ipat])
>>> ipat=4
>>> pl.scatter(out_dyn[inet,ipat,0,:,45],out_dyn[inet,ipat,1,:,45],c=c_set[ipat])
>>> ipat=6
>>> pl.scatter(out_dyn[inet,ipat,0,:,45],out_dyn[inet,ipat,1,:,45],c=c_set[ipat])
>>> 




for i in range(6):
...     for j in range(7):
...             for k in range(5):
...                     for l in range(7):
...                             for m in range(5):
...                                     dist_mat[i,j*5+k,l*5+m]=np.fabs(np.mean(svd_dyn[i,j,:,k*10,:],axis=0)-np.mean(svd_dyn[i,l,:,m*10,:],axis=0))




879 -0.867 0.4
897 -0.77 0.652
940 -0.929 0.571
941 -0.969 0.538
902 -0.834 0.7
"""



def gen_pca_smp(data):
    a=len(data)
    b=len(data[0])
    c=len(data[0,0])
    d=len(data[0,0,0])

    pca_smp=np.zeros((a*b*c,d))

    for i in range(a):
        for j in range(b):
            for k in range(c):
                tmp=np.mean(data[i,j,k,:])
                pca_smp[i*b*c+j*c+k,:]=data[i,j,k,:]/tmp

    return pca_smp


def gen_pca_dyn1(PCs,npcs,data):
    a=len(data)
    b=len(data[0])
    c=len(data[0,0])

    pca_dyn=np.zeros((a*b,c,npcs))

    for i in range(a):
        for j in range(b):
            for k in range(c):
                tmp=np.mean(data[i,j,k,:])
                for l in range(npcs):
                    pca_dyn[i*b+j,k,l]=np.mean(PCs[l,:]*data[i,j,k,:])/tmp

    return pca_dyn


