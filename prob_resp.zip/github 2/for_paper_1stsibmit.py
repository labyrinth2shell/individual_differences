import numpy as np
import pylab as pl
from scipy import optimize
import sys
import random
import regression as rg

from mpl_toolkits.axes_grid.inset_locator import inset_axes
from scipy.ndimage import filters as flt
from scipy   import stats
#import gen_fig_rnd as gr
import FDA as fda
reload(fda)


npca=15
init_smp=10
endt_smp=61


def PCA(P):
    m = sum(P) / float(len(P))
    P_m = P - m
    l,v = np.linalg.eig( np.dot(P_m.T,P_m) )
    idx=l.argsort()
    l=l[idx][::-1]
    v=v[:,idx][:,::-1]
    return l,v.T


def get_file_name(flgs,paras):
    
    if flgs[0]=="normal":
        if len(paras)!=5:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl,GEfb)
        elif(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl,GEfb)
    elif(flgs[0]=="tmp_t"):
        [inet,ipat,Si,scl,GEfb]=paras
        str="tmp_dbt56_fb_rnd_norm_%d%d-Si0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % (inet,ipat)
    elif flgs[0]=="weak":
        if len(paras)!=5:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_weak751_21hb205" % (inet,ipat,Si,scl,GEfb)
        elif(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_weak751_21hb205" % (inet,ipat,Si,scl,GEfb)
    elif flgs[0]=="many":
        if len(paras)!=5:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_many1_21hb205" % (inet,ipat,Si,scl,GEfb)
        elif(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_many1_21hb205" % (inet,ipat,Si,scl,GEfb)
    elif flgs[0]=="pert":
        if len(paras)!=6:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,str_pert]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
    elif flgs[0]=="pert_tmp":
        if len(paras)!=6:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,str_pert]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t200"):
        #            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp1_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp3_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t150"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp2_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t250"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp4_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t300"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp5_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t100"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp1_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        # this file data is identical as *txttmp11_pert*
        if(flgs[1]=="t100_add"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        # this file includes only init 50-99. this is only for two networks histgram in Fig.7
        if(flgs[1]=="rt100"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g0" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_1"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g10" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_2"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g20" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_3"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g30" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_4"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g40" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_5"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g50" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_6"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g60" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_7"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g70" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_8"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g80" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_9"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g90" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="evkspnt150"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp21_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="evkspnt200"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp31_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)



    return str

def get_rate_all(flgs,paras):

    if flgs[1]=="spn":
        t_smp=1001
    else:
        t_smp=1001
    
    if flgs[0]=="normal" and len(paras)==7:
        [inet,ipat,Si,scl,GEfb,nsmp,diff]=paras[:]
        str=get_file_name([flgs[0],"r"],[inet,ipat,Si,scl,GEfb])
        if str=="error in get_file_name!":
            return str
    elif flgs[0]=="many":
        [inet,ipat,Si,scl,GEfb,nsmp,diff]=paras[:]
        str=get_file_name([flgs[0],"r"],[inet,ipat,Si,scl,GEfb])
    elif flgs[0]=="pert_tmp" and len(paras)==8:
        [inet,ipat,Si,scl,GEfb,nsmp,diff,str_pert]=paras[:]
        if len(flgs)==3:
            str=get_file_name([flgs[0],flgs[2]],[inet,ipat,Si,scl,GEfb,str_pert])
        else:
            str=get_file_name([flgs[0],"t"],[inet,ipat,Si,scl,GEfb,str_pert])
        if str=="error in get_file_name!":
            return str
    else:
        print "check the function!"
        return


    cnt=0
    
    inv_bin_smp=0.1 #[ms-1]

    n_bin      =int(t_smp*inv_bin_smp)
    rate_tmp=np.zeros((nsmp,n_bin+1,5000))
    
    tmp=np.loadtxt(str)
    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:
            cnt+=1
            if nsmp<=cnt:
                break
        if tmp[i,1]<5000:
            if tmp[i,0]>t_smp:
                continue
            rate_tmp[cnt,int(tmp[i,0]*inv_bin_smp),tmp[i,1]]+=1
    
    return rate_tmp


def get_behav1(flgs,paras):
    file_type,_,file_sub_type,if_trj=flgs
    
    
    if file_type=="normal" or file_type=="many":
        if len(paras)!=7:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,nsmp,diff]=paras[:]
        str=get_file_name([file_type,"t"],[inet,ipat,Si,scl,GEfb])
        if str=="error in get_file_name!":
            return str
    elif file_type=="weak":
        if len(paras)!=7:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,nsmp,diff]=paras[:]
        str=get_file_name([file_type,"t"],[inet,ipat,Si,scl,GEfb])
        if str=="error in get_file_name!":
            return str
    elif file_type=="pert_tmp":
        if len(paras)!=8:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,nsmp,diff,str_pert]=paras[:]
        if len(flgs)==3:
            str=get_file_name([file_type,file_sub_type],[inet,ipat,Si,scl,GEfb,str_pert])
        else:
            str=get_file_name([file_type,file_sub_type],[inet,ipat,Si,scl,GEfb,str_pert])
        if str=="error in get_file_name!":
            return str
    elif file_type=="tmp_t":
        [inet,ipat,Si,scl,GEfb,nsmp,diff]=paras[:]
        str=get_file_name([file_type,"tmp_t"],[inet,ipat,Si,scl,GEfb])
        if str=="error in get_file_name!":
            return str
    else:
        print "check the function!"
        return
    
    # set parameters
    cnt=0
    behav_ind=np.zeros(nsmp)
    behav_list=[]
    colist=[]
    t_end=np.zeros(nsmp)
    state_end=np.zeros((nsmp,2))
    
    tmp=np.loadtxt(str)
    tmptmp=tmp[0,:3]
    
    if if_trj=="get_trj":
        tmp_trj=[]
    
    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:  # detection of a new trial
            if if_trj=="get_trj":
                tmp_trj.append(tmptmp)
            for j in range(len(tmptmp)):
                if tmptmp[j,1] - tmptmp[j,2]>diff:
                    t_end[cnt]=tmptmp[j,0]
                    behav_list.append(cnt)
                    break
                elif tmptmp[j,2] - tmptmp[j,1]>diff:
                    t_end[cnt]=tmptmp[j,0]
                    colist.append(cnt)
                    break
            
            state_end[cnt][0]=tmptmp[j,1]
            state_end[cnt][1]=tmptmp[j,2]
            
            tmptmp=tmp[i,:3]
            cnt+=1
            if cnt>=nsmp:
                break
        
        elif i>0:  # store a trajectory of a al in tmptmp
            tmptmp=np.vstack((tmptmp,tmp[i,:3]))

    if cnt<=nsmp-1:
        if if_trj=="get_trj":
            tmp_trj.append(tmptmp)
        for j in range(len(tmptmp)):
            if tmptmp[j,1] - tmptmp[j,2]>diff:
                t_end[cnt]=tmptmp[j,0]
                behav_list.append(cnt)
                break
            elif tmptmp[j,2] - tmptmp[j,1]>diff:
                t_end[cnt]=tmptmp[j,0]
                colist.append(cnt)
                break
        state_end[cnt][0]=tmptmp[j,1]
        state_end[cnt][1]=tmptmp[j,2]
    del tmp

    if if_trj=="get_trj":
        return behav_ind,behav_list,colist,t_end,state_end,tmp_trj
    else:
        return behav_ind,behav_list,colist,t_end,state_end


# for generation of pca_dyn of models
def get_pca_dyn2(inet):
    npca=10
    nsmp=50
    
    # make smp for PCA
    rate=np.load("rate_spn%d-0.40.90.02.npy" % inet)[:,:,2000:]
    tmpord=np.argsort(np.mean(rate,axis=(0,1)))
    
    rate_ave=np.zeros((nsmp,101,100))
    for j in range(nsmp):
        for k in range(100):
            rate_ave[j,:,k]=flt.gaussian_filter(rate[j,:,tmpord[-100+k]],2)
    behtmp=get_behav1(["normal","spn"],[inet,-1,0.4,0.9,0.02,nsmp,0.08])
    # check trials without decision
    tmp=[i for i in range(nsmp) if behtmp[3][i]<=0.00001]
    behtmp[3][tmp]=behtmp[3][tmp]+1001
    
    tmp=rate_ave[0,:np.int(behtmp[3][0]/10),:]
    for i in range(1,nsmp):
        tmp=np.vstack((tmp,rate_ave[i,:np.int(behtmp[3][0]/10),:]))
    
    # gen pc-projected dyn
    pc=PCA(tmp)[1]
    pca_dyn=np.zeros((nsmp,101,npca))
    for i in range(npca):
        for j in range(nsmp):
            for k in range(101):
                pca_dyn[j,k,i]=np.sum(pc[i,:]*rate_ave[j,k,:])
    
    return pca_dyn,pc,tmpord

def get_behav2(flgs,paras):  # check end time by >0.01  (not decision timing)
    
    if flgs[1]=="spn":
        t_init_smp=0
        t_end_smp=1001
    else:
        t_init_smp=350
        t_end_smp=601
    
    if flgs[0]=="normal":
        if len(paras)!=7:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,nsmp,diff]=paras[:]
        str=get_file_name([flgs[0],"t"],[inet,ipat,Si,scl,GEfb])
        if str=="error in get_file_name!":
            return str
    elif flgs[0]=="pert_tmp":
        if len(paras)!=8:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,nsmp,diff,str_pert]=paras[:]
        if len(flgs)==3:
            str=get_file_name([flgs[0],flgs[2]],[inet,ipat,Si,scl,GEfb,str_pert])
        else:
            str=get_file_name([flgs[0],"t"],[inet,ipat,Si,scl,GEfb,str_pert])
        if str=="error in get_file_name!":
            return str
        else:
            print "check the function!"
            return
    
    
    cnt=0  # set parameters
    tbin=10.0
    behav_ind=np.zeros(nsmp)
    behav_list=[]
    colist=[]
    t_end=np.ones(nsmp)*t_end_smp
    state_end=np.zeros((nsmp,2))
    
    tmp=np.loadtxt(str)
    tmptmp=tmp[0,:3]
    
    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:  # detection of a new trial
            for j in range(len(tmptmp)):
                if tmptmp[j,1]>0.099:
                    t_end[cnt]=tmptmp[j,0]
                    behav_list.append(cnt)
                    break
                elif tmptmp[j,2]>0.099:
                    t_end[cnt]=tmptmp[j,0]
                    colist.append(cnt)
                    break
            
            tmptmp=tmp[i,:3]
            cnt+=1
            if cnt>=nsmp:
                break
        
        elif i>0:  # store a trajectory of a trial in tmptmp
            tmptmp=np.vstack((tmptmp,tmp[i,:3]))
    
    if cnt<=nsmp-1:
        for j in range(len(tmptmp)):
            if tmptmp[j,1]>0.099:
                t_end[cnt]=tmptmp[j,0]
                behav_list.append(cnt)
                break
            elif tmptmp[j,2]>0.099:
                t_end[cnt]=tmptmp[j,0]
                colist.append(cnt)
                break
    del tmp
    
    return behav_ind,behav_list,colist,t_end

def get_pca_dyn3(inet,str_pert):
    tmp=get_rate_all([inet,-1,0.4,0.9,0.02,31*21,0.05,4,1,str_pert])[:,:,2000:]
    
    #get PCs
    rate11=tmp[::31,:,:]
    ord11=np.argsort(np.mean(rate11,axis=(0,1)))
    
    tmpbeh=get_behav2([inet,-1,0.4,0.9,0.02,31*21,0.05,5,1,str_pert])
    smp=rate11[0,:int(tmpbeh[3][0]/10),ord11[-100:]].T
    for i in range(1,len(rate11)):
        smp=np.vstack((smp,rate11[i,:int(tmpbeh[3][i*31]/10),ord11[-100:]].T))
    pc11=PCA(smp)
    
    tmptmp=np.zeros((21*31,66,100))
    tmptmp=tmp[:,:66,ord11[-100:]]
    for i in range(21):
        for j in range(10):
            tmptmp[i*31+j+1,:10,:]=tmp[i*31,:10,ord11[-100:]].T
            tmptmp[i*31+j+11,:20,:]=tmp[i*31,:20,ord11[-100:]].T
            tmptmp[i*31+j+21,:30,:]=tmp[i*31,:30,ord11[-100:]].T
    flt_dyn=np.zeros((21*31,61,100))
    for i in range(21*31):
        for j in range(100):
            for k in range(61):
                flt_dyn[i,k,j]=np.mean(tmptmp[i,k:k+5,j])
    
    pc_dyn=np.zeros(flt_dyn.shape)
    for i in range(21*31):
        for j in range(10):
            pc_dyn[i,:,j]=np.dot(flt_dyn[i,:61,:],pc11[1][j,:])
    
    prob2D=np.zeros((3,21))
    tmp=get_behav1([inet,-1,0.4,0.9,0.02,31*21,0.05,5,1,str_pert])
    for i in range(3):
        for j in range(21):
            tmp1=[j for k in range(1+10*i+31*j,1+10*(i+1)+31*j) if k in tmp[1] ]
            tmp2=[j for k in range(1+10*i+31*j,1+10*(i+1)+31*j) if k in tmp[2] ]
            prob2D[i,j]=(len(tmp1))/float(len(tmp1)+len(tmp2))
    
    return pc_dyn,prob2D




def gen_psycho_curve(beh,diff,if_sample):
    nsmp=len(beh)

    tmp_curve3=np.zeros((nsmp,7))
    for i in range(nsmp):
        for j in range(7):
            """
            nL=len(beh[i][j][0])
            nR=len(beh[i][j][1])
            """
            nL=0
            nR=0
            if not if_sample:
                for k in range(50):
                    if ((beh[i][j][3][k,0]-beh[i][j][3][k,1])/(2*diff)+0.5)>random.random():
                        nL+=1
                    else:
                        nR+=1
            else:
                for k in random.sample(range(50),40):
                    if ((beh[i][j][3][k,0]-beh[i][j][3][k,1])/(2*diff)+0.5)>random.random():
                        nL+=1
                    else:
                        nR+=1
            tmp_curve3[i,j]=nL/float(nL+nR) # change nR -> nL  2016.12.21
    return tmp_curve3


def gen_paras(tmp_curve,flg,flg_curve):
    tmptmp_curve=np.copy(tmp_curve)
    nsmp=len(tmptmp_curve)
    paras=np.zeros((nsmp,4))
    if flg_curve=="norm":
        for i in range(nsmp):
            tmptmp_curve[i]=(tmptmp_curve[i]-min(tmptmp_curve[i]))/(max(tmptmp_curve[i])-min(tmptmp_curve[i]))
    
    for i in range(nsmp):
        tmp=calc_type_psy((tmptmp_curve[i][::-1]))
        j=0
        paras[i][j]=tmp[0][j]
        j=j+1
        paras[i][j]=tmp[0][j]
        j=j+1
        paras[i][j]=tmp[0][j]
        if flg=="norm":
            paras[i][j]=(paras[i][j]-9.61015883e-04)/(0.34718996-9.61015883e-04)
        j=j+1
        paras[i][j]=tmp[1]

    return paras


# for fitting a psycho- or neuro- metric curve
def fit_func(para,x):
    a=para[0]
    b=para[1]
    c=para[2]
    return c*np.tan((x/3.-a))+b

def fit_func01(para,x):
    a=para[0]
    b=para[1]
    return a*np.tan(b*x/6.)+(1-a*np.tan(b))
"""
def fit_func01(para,x):
    b1=para[0]
    b2=para[1]
    c1=para[2]
    c2=para[3]
    output=np.zeros(x.shape)
    for i in range(len(x)):
        if x[i]<3:
            output[i]=c1*np.tan((x[i]-3)/3.)+b1
        elif np.abs(x[i]-3.0)<0.0001:
            output[i]=(c2*np.tan((x[i]-3)/3.)+b2+c1*np.tan((x[i]-3)/3.)+b1)/2.0
        else:
            output[i]=c2*np.tan((x[i]-3)/3.)+b2
    return output

def fit_func01(para,x):
    b1=para[0]
    b2=para[1]
    c1=para[2]
    c2=para[3]
    output=np.zeros(x.shape)
    for i in range(len(x)):
        if x[i]<3:
            output[i]=c1*np.tan((x[i]-3)/3.)+b1
        elif np.abs(x[i]-3.0)<0.0001:
            output[i]=(c2*np.tan((x[i]-3)/3.)+b2+c1*np.tan((x[i]-3)/3.)+b1)/2.0
        else:
            output[i]=c2*np.tan((x[i]-3)/3.)+b2
    return output


    def fit_func01(para,x):
    a=para[0]
    b=para[1]
    c=para[2]
    d=para[3]
    return c*np.tan(d*(x-a)/3.)+b
    
    
def fit_func1(para,x):
    a=para[0]
    b=para[1]
    c=para[2]
    return c*np.tanh((x/3.-a))+b

def fit_func2(para,x):
    a=para[0]
    return np.tan(a*x/3.-a)/np.tan(a)
"""

def resid_fit(para,x,y):
    res=y-fit_func(para,x)
    return res

def calc_type_psy(beh):
    para0=[1.1,10,0.5]
    #para0=[0.5,1.1]
    res=optimize.leastsq(resid_fit,para0,args=(np.arange(7),beh[:]))
    return res[0],np.mean(np.abs(resid_fit(res[0],np.arange(7),beh[:])))



# generate the parameters of perfect gradual and biased lines
"""
    test_curve=np.array([0,1/6.,2/6.,3/6.,4/6.,5/6.,1.0])
    test_para=fp.gen_paras(-test_curve)
    test_para
    Out[1566]: array([[ 1.00000123,  4.32040383,  0.34718996,  0.04209052]])
    
    test_curve1=np.array([1,0.,0.,0.,0.,0.,0.,])
    test_para1=fp.gen_paras(test_curve1.reshape(1,7))
    test_para1
    Out[1573]:
    array([[  1.56983600e+00,   1.04123218e+03,   9.61015883e-04,7.18352864e-04]])
    """



def gen_beh(suc_list,diff,Si):
    nsmp=len(suc_list)
    beh=[]
    for l in range(nsmp):
        beh.append([])
        for i in range(7):
            beh[l].append([])
            tmp=get_behav1(["normal","evk","_","_"],[suc_list[l],i*0.1,Si,0.9,0.02,50,diff])
            beh[l][i].append(tmp[1])
            beh[l][i].append(tmp[2])
            beh[l][i].append(tmp[3])
            beh[l][i].append(tmp[4])
    
    return beh

def gen_spn_beh(suc_list,diff):
    nsmp=len(suc_list)
    spnbeh=[]
    for l in range(nsmp):
        tmp=get_behav1(["normal","spn"],[suc_list[l],-1,0.4,0.9,0.02,50,diff])
        spnbeh.append([])
        spnbeh[l].append(tmp[1])
        spnbeh[l].append(tmp[2])
        spnbeh[l].append(tmp[3])

    return spnbeh



def gen_vol(spnbeh):
    nsmp=len(spnbeh)
    vol=np.zeros((nsmp,2))
    for i in range(nsmp):
        vol[i,0]=len(spnbeh[i][0])
        vol[i,1]=len(spnbeh[i][1])

    return vol

def gen_tend_evk(beh):
    nsmp=len(beh)
    tend_evk=np.zeros(nsmp)
    for i in range(nsmp):
        tmp =beh[i][0][0]+beh[i][0][1]
        tmp1=beh[i][6][0]+beh[i][6][1]
        tend_evk[i]=np.sum(beh[i][0][2][tmp])+np.sum(beh[i][6][2][tmp1])
        tend_evk[i]=tend_evk[i]/float(len(tmp)+len(tmp1))

    return tend_evk


def gen_tend_spn(spnbeh):
    nsmp=len(spnbeh)
    tend_spn=np.zeros(nsmp)
    for i in range(nsmp):
        tmp=spnbeh[i][0]+spnbeh[i][1]
        tend_spn[i]=np.mean(spnbeh[i][2][tmp])
    return tend_spn







def comp_dyn(inet):

    rate3=np.load("rate_spn%d-0.40.90.02.npy" % inet)[:,:,2000:]
    ord3=np.argsort(np.mean(rate3,axis=(0,1)))

    rate_hi=np.zeros((50,101,100))
    for i in range(50):
        ratetmp=np.zeros((101,100))
        for k in range(100):
            ratetmp[:,k]=flt.gaussian_filter(rate3[i,:,ord3[-100+k]],1)
        rate_hi[i]=ratetmp
    for i in range(100):
        rate_hi[:,:,i]=(rate_hi[:,:,i]-np.mean(rate_hi[:,:,i]))/np.std(rate_hi[:,:,i])

    tmpbeh=get_behav2(["normal","spn"],[inet,-1,0.4,0.9,0.02,50,0.05])
    smp=rate_hi[0,:int(tmpbeh[3][0]/10),:]
    for i in range(1,len(rate3)):
        smp=np.vstack((smp,rate_hi[i,:int(tmpbeh[3][i]/10),:]))
    pc3=PCA(smp)
    
    pca_dyn3=np.zeros((50,101,10))
    for i in range(50):
        for k in range(10):
            pca_dyn3[i,:,k]=np.dot(pc3[1][k,:],rate_hi[i,:,:].T)
    

    rate=np.load("rate%d-0.40.90.02.npy" % inet)[:,:,:,2000:]
    pca_dyn_evk=np.zeros((7,50,61,10))
    for i in range(50):
        for j in range(7):
            ratetmp=np.zeros((61,100))
            for k in range(100):
                ratetmp[:,k]=flt.gaussian_filter(rate[j,i,:,ord3[-100+k]],1)
                ratetmp[:,k]=(ratetmp[:,k]-np.mean(ratetmp[:,k]))/np.std(ratetmp[:,k])
            for k in range(10):
                pca_dyn_evk[j,i,:,k]=np.dot(pc3[1][k,:],ratetmp[:,:].T)
    
    return pca_dyn3,pca_dyn_evk


def gen_pca(inet,t_terminated_evk,suc_list,flg):  # this is similar to gen_pca_prj_dyn (below). but this is focusing on getting PCs for familiar and unfamilar
    flg=1 # 0: only for familiar  1: including unfamiliar stimuli

    suc_inet=suc_list.index(inet)
    rate=np.load("rate_long%d0.40.90.02.npy" % inet)
    tinit=10
    if flg==0:
        for ipat in [0,6]:
            init=0
            if ipat==0:
                smp_pca=rate[ipat,init,:int(t_terminated_evk[suc_inet][ipat][init]/10),:]
            else:
                smp_pca=np.vstack((smp_pca,rate[ipat,init,:int(t_terminated_evk[suc_inet][ipat][init]/10),:]))
            for init in range(1,50):
                smp_pca=np.vstack((smp_pca,rate[ipat,init,:int(t_terminated_evk[suc_inet][ipat][init]/10),:]))
    else :
        for ipat in range(7):
            init=0
            if ipat==0:
                tend=int(t_terminated_evk[suc_inet][ipat][init]/10)
                if tend<1:
                    tend=100
                tsamp=range(tinit,tend)
                if tend-tinit>30:
                    tsamp=random.sample(tsamp,30)
                smp_pca=rate[ipat,init,tsamp,:]
            else:
                tend=int(t_terminated_evk[suc_inet][ipat][init]/10)
                if tend<1:
                    tend=100
                tsamp=range(tinit,tend)
                if tend-tinit>30:
                    tsamp=random.sample(tsamp,30)
                smp_pca=np.vstack((smp_pca,rate[ipat,init,tsamp,:]))
            for init in range(1,50):
                tend=int(t_terminated_evk[suc_inet][ipat][init]/10)
                if tend<1:
                    tend=100
                tsamp=range(tinit,tend)
                if tend-tinit>30:
                    tsamp=random.sample(tsamp,30)
                smp_pca=np.vstack((smp_pca,rate[ipat,init,tsamp,:]))


    tmp_ord=np.argsort(np.mean(smp_pca,axis=0))
    smp_pca=smp_pca[:,tmp_ord[-100:]]

    PCs=PCA(smp_pca)

    return PCs


def gen_pca_prj_dyn(inet,t_terminated_evk,suc_list):
    sig_flt=3
    
    suc_inet=suc_list.index(inet)
    rate=np.load("rate_long%d0.40.90.02.npy" % inet)
    for ipat in [0,6]:
        init=0
        if ipat==0:
            smp_pca=rate[ipat,init,:int(t_terminated_evk[suc_inet][ipat][init]/10),:]
        else:
            smp_pca=np.vstack((smp_pca,rate[ipat,init,:int(t_terminated_evk[suc_inet][ipat][init]/10),:]))
        for init in range(1,50):
            smp_pca=np.vstack((smp_pca,rate[ipat,init,:int(t_terminated_evk[suc_inet][ipat][init]/10),:]))
    tmp_ord=np.argsort(np.mean(smp_pca,axis=0))
    smp_pca=smp_pca[:,tmp_ord[-100:]]

    PCs=PCA(smp_pca)

    pca_dyn=np.zeros((7,50,101,20))
    for i in range(50):
        for j in range(7):
            for k in range(20):
                pca_dyn[j,i,:,k]=np.dot(PCs[1][k,:],rate[j,i,:,tmp_ord[-100:]])

    pca_pert=np.zeros((31*50,101,20))
    rate_pert=np.zeros((31*50,101,100))
    rate_pert[:10*31]=np.load("rate_pert%d_-1-5.npy" % inet)[:,:,tmp_ord[-100:]]
    rate_pert[31*10:31*20]=np.load("rate_pert%d_-1-6.npy" % inet)[:,:,tmp_ord[-100:]]
    rate_pert[31*20:31*30]=np.load("rate_pert%d_-1-7.npy" % inet)[:,:,tmp_ord[-100:]]
    rate_pert[31*30:31*40]=np.load("rate_pert%d_-1-8.npy" % inet)[:,:,tmp_ord[-100:]]
    rate_pert[31*40:]=np.load("rate_pert%d_-1-9.npy" % inet)[:,:,tmp_ord[-100:]]
    for j in range(31*50):
        for k in range(20):
            pca_pert[j,:,k]=np.dot(PCs[1][k,:],rate_pert[j,:,:].T)

#zscored

    for i in range(31*50):
        for j in range(20):
            pca_pert[i,:,j]=flt.gaussian_filter(pca_pert[i,:,j],sig_flt)
    for i in range(7):
        for j in range(50):
            for k in range(20):
                pca_dyn[i,j,:,k]=flt.gaussian_filter(pca_dyn[i,j,:,k],sig_flt)

    np.save("pca_dyn_ipat0_%d.npy" % inet, pca_dyn)
    np.save("pca_pert1_%d_add.npy" % inet,pca_pert)


    return

    """
    for ipat in range(7):
        init=0
        if ipat==0:
            smp_pca=rate[ipat,init,:int(t_terminated_evk[suc_inet][ipat][init]/10),:]
        else:
            smp_pca=np.vstack((smp_pca,rate[ipat,init,:int(t_terminated_evk[suc_inet][ipat][init]/10),:]))
        for init in range(1,50):
            smp_pca=np.vstack((smp_pca,rate[ipat,init,:int(t_terminated_evk[suc_inet][ipat][init]/10),:]))
    tmp_ord=np.argsort(np.mean(smp_pca,axis=0))
    smp_pca=smp_pca[:,tmp_ord[-100:]]
                
    PCs=PCA(smp_pca)

    pca_dyn=np.zeros((7,50,101,20))
    for i in range(50):
        for j in range(7):
            for k in range(20):
                pca_dyn[j,i,:,k]=np.dot(PCs[1][k,:],rate[j,i,:,tmp_ord[-100:]])
    
    pca_pert=np.zeros((31*50,101,20))
    rate_pert=np.zeros((31*50,101,100))
    rate_pert[:10*31]=np.load("rate_pert%d_-1-0.npy" % inet)[:,:,tmp_ord[-100:]]
    rate_pert[31*10:31*20]=np.load("rate_pert%d_-1-1.npy" % inet)[:,:,tmp_ord[-100:]]
    rate_pert[31*20:31*30]=np.load("rate_pert%d_-1-2.npy" % inet)[:,:,tmp_ord[-100:]]
    rate_pert[31*30:31*40]=np.load("rate_pert%d_-1-3.npy" % inet)[:,:,tmp_ord[-100:]]
    rate_pert[31*40:]=np.load("rate_pert%d_-1-4.npy" % inet)[:,:,tmp_ord[-100:]]
    for j in range(31*50):
        for k in range(20):
            pca_pert[j,:,k]=np.dot(PCs[1][k,:],rate_pert[j,:,:].T)
    
    #zscored
    for i in range(31*50):
        for j in range(20):
            pca_pert[i,:,j]=flt.gaussian_filter(pca_pert[i,:,j],sig_flt)
    for i in range(7):
        for j in range(50):
            for k in range(20):
                pca_dyn[i,j,:,k]=flt.gaussian_filter(pca_dyn[i,j,:,k],sig_flt)
    
    np.save("pca7_dyn%d.npy" % inet, pca_dyn)
    np.save("pca7_pert1_%d.npy" % inet,pca_pert)


    return
    """

def gen_rg_prj_dyn(inet,beh04):
    
    rate_pert=np.zeros((31*50,101,5000))
    rate_pert[:10*31]=np.load("rate_pert%d_-1-0.npy" % inet)
    rate_pert[31*10:31*20]=np.load("rate_pert%d_-1-1.npy" % inet)
    rate_pert[31*20:31*30]=np.load("rate_pert%d_-1-2.npy" % inet)
    rate_pert[31*30:31*40]=np.load("rate_pert%d_-1-3.npy" % inet)
    rate_pert[31*40:]=np.load("rate_pert%d_-1-4.npy" % inet)
    tmp=rg.main([rate,np.array(beh04[inet-1])[:,:2],inet,rate_pert[:,:,:]],["_","get_PCA",False,False,True,True])
    prj_tmp,prj_pop_tmp,prj_pert_tmp,prj_unfam_tmp=tmp
    tmppca_pert=np.zeros((1550,101,5))
    tmppca=np.zeros((7,50,101,5))
    for i in range(5):
        for j in range(1550):
            tmppca_pert[j,:,i]=np.dot(prj_tmp[1][i,:].reshape(1,100),prj_pert_tmp[j,:,:].T)
        for j in range(50):
            tmppca[0,j,:,i]=np.dot(prj_tmp[1][i,:].reshape(1,100),prj_pop_tmp[j,:,:].T)
        for j in range(50,100):
            tmppca[6,j-50,:,i]=np.dot(prj_tmp[1][i,:].reshape(1,100),prj_pop_tmp[j,:,:].T)
        for k in range(5):
            for j in range(50*k,50*(k+1)):
                tmppca[k+1,j-50*k,:,i]=np.dot(prj_tmp[1][i,:].reshape(1,100),prj_unfam_tmp[j,:,:].T)
    pca_pert=np.copy(tmppca_pert)
    pca_prj=np.copy(tmppca)
    del rate_pert
    del rate
    return pca_pert,pca_prj

def gen_flip(suc_list,diff):
    nsmp=len(suc_list)
    stab=np.zeros((nsmp,50,4))
    for l in range(nsmp):
        tmp=fp.get_behav1(["pert_tmp","spn","t150"],[suc_list[l],-1,0.4,0.9,0.02,31*50,diff,0.1])
        for j in range(50):
            tmp1=[j for k in range(1+31*j,1+30+31*j) if k in tmp[1] ]
            tmp2=[j for k in range(1+31*j,1+30+31*j) if k in tmp[2] ]
            if 31*j in tmp[1]:
                stab[l,j,0]+=len(tmp1)
                stab[l,j,1]+=len(tmp2)
            elif 31*j in tmp[2]:
                stab[l,j,2]+=len(tmp1)
                stab[l,j,3]+=len(tmp2)
    return stab



def gen_stab_att(suc_list,diff):
    nsmp=len(suc_list)
    stab=np.zeros((nsmp,4))
    for l in range(nsmp):
        tmp=get_behav1(["pert_tmp","spn","t150"],[suc_list[l],-1,0.4,0.9,0.02,31*50,diff,0.1])
        for j in range(50):
            tmp1=[j for k in range(1+31*j,1+30+31*j) if k in tmp[1] ]
            tmp2=[j for k in range(1+31*j,1+30+31*j) if k in tmp[2] ]
            if 31*j in tmp[1]:
                stab[l,0]+=len(tmp1)
                stab[l,1]+=len(tmp2)
            elif 31*j in tmp[2]:
                stab[l,2]+=len(tmp1)
                stab[l,3]+=len(tmp2)
    return stab



def gen_cor_maps(suc_list):
    diff=0.05
    beh=gen_beh(suc_list,diff)
    spnbeh=gen_spn_beh(suc_list,diff)
    
    tmp_curve=fp.gen_psycho_curve(beh,diff)
    paras=fp.gen_paras(tmp_curve)

    vol=gen_vol(spnbeh)
    tend_evk=gen_tend_evk(beh)



def gen_seq_act(rate,listL,listR):
    inet=11
    tend=50
    nstim,ntrial,ntbin,ncell=rate[:,:,:tend,2000:].shape
    ncell_used=200
    tmpord=np.argsort(np.mean(rate[:,:,:tend,2000:],axis=(0,1,2)))
    tinit=0
  
    gs_dyn=np.zeros((ncell_used,nstim,ntrial,ntbin))
    for i in range(ncell_used):
        for j in range(ntrial):
            for k in range(nstim):
                gs_dyn[i,k,j,:]=flt.gaussian_filter(rate[k,j,:tend,tmpord[-ncell_used+i]+2000],2)

    tmp_dyn=np.zeros((ncell_used,2,2,ntbin))
    ipat=0
    tmplist=listL[ipat]
    for i in range(ncell_used):
        tmp_dyn[i,ipat,0,:]=np.mean(gs_dyn[i,ipat,tmplist,:],axis=0)
    tmplist=listR[ipat]
    for i in range(ncell_used):
        tmp_dyn[i,ipat,1,:]=np.mean(gs_dyn[i,ipat,tmplist,:],axis=0)

    ipat=6
    tmplist=listL[ipat]
    for i in range(ncell_used):
        tmp_dyn[i,ipat-5,0,:]=np.mean(gs_dyn[i,ipat,tmplist,:],axis=0)
    tmplist=listR[ipat]
    for i in range(ncell_used):
        tmp_dyn[i,ipat-5,1,:]=np.mean(gs_dyn[i,ipat,tmplist,:],axis=0)


    ptime=np.zeros((2,2,ncell_used))
    for i in range(ncell_used):
        for j in range(2):
            for k in range(2):
                ptime[k,j,i]=np.argsort(tmp_dyn[i,k,j,tinit:])[-1]
    
    norm_dyn=np.zeros(tmp_dyn[:,:,:,tinit:].shape)
    for k in range(2):
        for j in range(2):
            for i in range(ncell_used):
                norm_dyn[i,k,j]=tmp_dyn[i,k,j,tinit:]
                if np.max(norm_dyn[i,k,j])!=0:
                    norm_dyn[i,k,j]=norm_dyn[i,k,j]/np.max(norm_dyn[i,k,j])
    
    for i in range(2):
        for j in range(2):
            for k in range(2):
                pl.subplot(2,4,i*4+j*2+k+1)
                pl.pcolor(np.arange(ntbin+1),np.arange(ncell_used+1),norm_dyn[np.argsort(ptime[i,i,:]),j,k,:])
    pl.colorbar()
    pl.savefig("seq_act_inet%d.eps" %inet)

    return norm_dyn,ptime


def sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat):
    pcasmp=np.mean(rate[:,:,min(tsmp):max(tsmp)+1,tmpord[-ncell:]],axis=2)
    meanrate=np.zeros((ntrial,ncell))
    for icell in range(ncell):
        meanrate[:,icell]=pcasmp[ipat,:,icell]/np.mean(pcasmp[ipat,:,icell])
    PC=PCA(meanrate.reshape(ntrial,ncell))
    return PC

def calc_expansion_pop1(thrs_ave,thrs_diff):
    ntrial=100
    ntsmp =9
    if use_all:
        geta=0
    else:
        geta=2000
    nall=5000
    pccurve1=np.zeros((20,7,100,5,ntsmp))
    pccurve=np.zeros((20,7,100,5,ntsmp))
    suc_list=[2,3,5,6,7,8,11,13,14,15,16,18,19,20,22,23,24,25,26,30]
    for i in range(20):
        inet=suc_list[i]
        rate=np.load("rate_many%d-0.40.90.02.npy" % inet )
       
       
        # cell pickup
        """
        tmpc_list=set(range(3000))
        for ipat in range(7):
            for j in range(ntsmp):
                tsmp=range(5*(j+1),5*(j+2))
                tmpmr=np.mean(rate[ipat,:,tsmp,2000:],axis=(0,1))
                tmpc_list=tmpc_list & set([icell for icell in range(3000) if tmpmr[icell]>thrs_ave])
        for ipat in range(7):
            tmpmr=np.fabs(np.mean(rate[ipat,:,5:10,2000:],axis=(0,1))-np.mean(rate[ipat,:,10:30,2000:],axis=(0,1)))
            tmpc_list=tmpc_list & set([icell for icell in range(3000) if tmpmr[icell]>thrs_diff])
        print i, len(tmpc_list)
        if len(tmpc_list)>ncell:
            tsmp=range(5,(ntsmp+1)*5)
            tmpord=np.argsort(np.mean(rate[ipat,:,tsmp,2000:],axis=(0,1)))
            tmpord=[icell for icell in tmpord if icell in tmpc_list]
            tmpord=np.array(tmpord)+2000

            for j in range(ntsmp):
                tsmp=range(5*(j+1),5*(j+2))
                for ipat in range(7):
                    PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                    pccurve1[i,ipat,:,0,j]=PC[0]
        """
        # cell pickup
        ncell=30
        tmpc_list=set(range(nall-geta))
        for ipat in range(7):
            for j in range(ntsmp):
                tsmp=range(5*(j+1),5*(j+2))
                tmpmr=np.mean(rate[ipat,:,tsmp,geta:],axis=(0,1))
                tmpc_list=tmpc_list & set([icell for icell in range(nall-geta) if tmpmr[icell]>thrs_ave])
   
        tsmp=range(5,(ntsmp+1)*5)
        tmpord=np.argsort(np.mean(rate[:,:,tsmp,geta:],axis=(0,1,2)))
        tmpord=[icell for icell in tmpord if icell in tmpc_list]
        tmpord=np.array(tmpord)+geta
        print i, len(tmpord)
        if len(tmpord)>ncell:
            for j in range(ntsmp):
                tsmp=range(5*(j+1),5*(j+2))
                for ipat in range(7):
                    PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                    pccurve1[i,ipat,:ncell,0,j]=PC[0]

        diff=np.zeros((nall-geta,7))
        for ipat in range(7):
            diff[:,ipat]=np.fabs(np.mean(rate[ipat,:,5:10,geta:],axis=(0,1))-np.mean(rate[ipat,:,10:(ntsmp+1)*5,geta:],axis=(0,1)))
        """
        tmpord=np.argsort(np.mean(diff,axis=1))
        tmpord=[icell for icell in tmpord if icell in tmpc_list]
        """
        tsmp=range(5,(ntsmp+1)*5)
        tmpord=np.argsort(np.mean(rate[:,:,tsmp,geta:],axis=(0,1,2)))
        tmpord=[icell for icell in tmpord if (icell in tmpc_list) and (max(diff[icell])>thrs_diff)]
        tmpord=np.array(tmpord)+geta
        print len([itmp for itmp in tmpord if itmp<2000]),len([itmp for itmp in tmpord if itmp>=2000])
        if len(tmpord)>ncell:
            for j in range(ntsmp):
                tsmp=range(5*(j+1),5*(j+2))
                for ipat in range(7):
                    PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                    pccurve1[i,ipat,:ncell,1,j]=PC[0]
        ncell=20
        if len(tmpord)>ncell:
            for j in range(ntsmp):
                tsmp=range(5*(j+1),5*(j+2))
                for ipat in range(7):
                    PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                    pccurve1[i,ipat,:ncell,2,j]=PC[0]
        ncell=10
        if len(tmpord)>ncell:
            for j in range(ntsmp):
                tsmp=range(5*(j+1),5*(j+2))
                for ipat in range(7):
                    PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                    pccurve1[i,ipat,:ncell,3,j]=PC[0]
        ncell=len(tmpord)
        if ncell>=100:
            ncell=100
        for j in range(ntsmp):
            tsmp=range(5*(j+1),5*(j+2))
            for ipat in range(7):
                PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                pccurve1[i,ipat,:ncell,4,j]=PC[0]

        # pickup cells
        ncell=30
        tmpc_list=set(range(nall-geta))
        for ipat in range(7):
            for j in range(ntsmp):
                tsmp=range(5*(j+1),5*(j+2))
                tmpmr=np.mean(rate[ipat,:,tsmp,geta:],axis=(0,1))
                tmpc_list=tmpc_list & set([icell for icell in range(nall-geta) if tmpmr[icell]>thrs_ave-0.05])

        tsmp=range(5,(ntsmp+1)*5)
        tmpord=np.argsort(np.mean(rate[:,:,tsmp,geta:],axis=(0,1,2)))
        tmpord=[icell for icell in tmpord if icell in tmpc_list]
        tmpord=np.array(tmpord)+geta
        print i, len(tmpord)
        if len(tmpord)>ncell:
            for j in range(ntsmp):
                tsmp=range(5*(j+1),5*(j+2))
                for ipat in range(7):
                    PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                    pccurve1[i,ipat,:ncell,0,j]=PC[0]

        diff=np.zeros((nall-geta,7))
        for ipat in range(7):
            diff[:,ipat]=np.fabs(np.mean(rate[ipat,:,5:10,geta:],axis=(0,1))-np.mean(rate[ipat,:,10:(ntsmp+1)*5,geta:],axis=(0,1)))
        """
            tmpord=np.argsort(np.mean(diff,axis=1))
            tmpord=[icell for icell in tmpord if icell in tmpc_list]
            """
        tsmp=range(5,(ntsmp+1)*5)
        tmpord=np.argsort(np.mean(rate[:,:,tsmp,geta:],axis=(0,1,2)))
        tmpord=[icell for icell in tmpord if (icell in tmpc_list) and (max(diff[icell])>thrs_diff)]
        tmpord=np.array(tmpord)+geta
        print len([itmp for itmp in tmpord if itmp<2000]),len([itmp for itmp in tmpord if itmp>=2000])
        if len(tmpord)>ncell:
            for j in range(ntsmp):
                tsmp=range(5*(j+1),5*(j+2))
                for ipat in range(7):
                    PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                    pccurve[i,ipat,:ncell,1,j]=PC[0]
        ncell=20
        if len(tmpord)>ncell:
            for j in range(ntsmp):
                tsmp=range(5*(j+1),5*(j+2))
                for ipat in range(7):
                    PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                    pccurve[i,ipat,:ncell,2,j]=PC[0]
        
        ncell=10
        if len(tmpord)>ncell:
            for j in range(ntsmp):
                tsmp=range(5*(j+1),5*(j+2))
                for ipat in range(7):
                    PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                    pccurve[i,ipat,:ncell,3,j]=PC[0]

        ncell=len(tmpord)
        if ncell>100:
            ncell=100
        for j in range(ntsmp):
            tsmp=range(5*(j+1),5*(j+2))
            for ipat in range(7):
                PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                pccurve[i,ipat,:ncell,4,j]=PC[0]


    return pccurve1,pccurve


def calc_expansion_pop(rate):  # from for_paper.py in allneurons dirctori
    
    exp_rate=np.zeros((7,10))
    
    """
    tmp=np.mean(data_set_rat[irat][0][:,:,40:],axis=(1,2))
    ncellused=len([i for i in range(len(tmp)) if tmp[i]>=3.0])
    """
    
    tsmp=5
    ncellused=50
    tmpord=np.argsort(np.mean(rate[:,:,:,2000:],axis=(0,1,2)))+2000
    
    
    nstim=len(rate)
    nsmp =len(rate[0])
    ntbin=len(rate[0,0])
    norm_dyn=np.zeros((ncellused,nstim,nsmp,ntbin-5))
    for i in range(ncellused):
        tmpdyn=np.zeros((nstim,nsmp,ntbin-5))
        for l in range(nstim):
            for j in range(nsmp):
                for k in range(len(tmpdyn[0,0])):
                    tmpdyn[l,j,k]=np.mean(rate[l,j,k:k+5,tmpord[-ncellused+i]])
        for l in range(nstim):
            for j in range(nsmp):
                norm_dyn[i,l,j]=(tmpdyn[l,j]-np.mean(tmpdyn[:,:,tsmp:]))/np.std(tmpdyn[:,:,tsmp:])
    for ipat in range(7):
        tmplist=range(nsmp)

        for i in range(10):
            tmp=PCA(norm_dyn[:,ipat,tmplist,tsmp+i*5].T)
            exp_rate[ipat,i]=np.sum(np.log(tmp[0]))
    return exp_rate







# making way of figures:  updat on 2016.12.16 last update 2017.3.3

#########   basic variables (2017.3.3)  ###########
# beh data is update to long ver. (t~1000ms)
""""

beh=np.load("beh_long0.40.90.02.npy")

tmp_curve=fp.gen_psycho_curve(beh04,0.05)






#### analysis for validity of parameter fitting (Fig. 3)  #####
#  generate 50 possible psy curves
tmp_boot_curve=np.zeros((50,30,7))
for j in range(50):
tmp_boot_curve[j]=fp.gen_psycho_curve(beh,0.05,True)


pl.plot(range(7),tmp_boot_curve[:,6,:].T,alpha=0.3)
pl.plot(range(7),tmp_curve[6],lw=3,c="r")
pl.savefig("psy_curve_boot_sample.eps")

# fit parameters
nboot=50
paras=np.zeros((20,3))
res=np.zeros(20)
paras_boot=np.zeros((nboot,20,3))
res_boot=np.zeros((nboot,20))
for i in range(20):
tmp=fp.calc_type_psy(tmp_curve[suc_list[i]-1][::-1])
paras[i]=tmp[0]
res[i]  =tmp[1]
for j in range(nboot):
tmp=fp.calc_type_psy(tmp_boot_curve[j,suc_list[i]-1,::-1])
paras_boot[j,i]=tmp[0]
res_boot[j,i]=tmp[1]

# fit parameters by func01
reload(fp)
paras2=np.zeros((20,2))
res2=np.zeros(20)
res21=np.zeros(20)
for i in range(20):
tmp=fp.calc_type_psy(tmp_curve[suc_list[i]-1][::-1])
res2[i]=tmp[1]
tmp=fp.calc_type_psy(np.ones(7)-tmp_curve[suc_list[i]-1][:])
res21[i]=tmp[1]

if_bias=np.zeros(20)
for i in range(20):
if res2[i]<res21[i]:
if_bias[i]=0
else:
if_bias[i]=1

tmp_bias_curve=np.zeros((20,7))
for i in range(20):
inet=suc_list[i]-1
if if_bias[i]==0:
tmp=tmp_curve[suc_list[i]-1][::-1]
else:
tmp=np.ones(7)-tmp_curve[suc_list[i]-1][:]
tmp_bias_curve[i]=(tmp-tmp[0])/(tmp[6]-tmp[0])
for i in range(20):
tmp=fp.calc_type_psy(tmp_bias_curve[i])
paras2[i]=tmp[0]
res2[i]=tmp[1]

tmp_bias_boot_curve=np.zeros((nboot,20,7))
for i in range(20):
inet=suc_list[i]-1
if if_bias[i]==0:
tmp=tmp_boot_curve[:,suc_list[i]-1,::-1]
else:
tmp=np.ones((nboot,7))-tmp_boot_curve[:,suc_list[i]-1,:]
for j in range(nboot):
tmp_bias_boot_curve[j,i]=(tmp[j]-tmp[j,0])/(tmp[j,6]-tmp[j,0])

paras2_boot=np.zeros((nboot,20,2))
res2_boot=np.zeros((nboot,20))
for i in range(20):
for j in range(nboot):
tmp=fp.calc_type_psy(tmp_bias_boot_curve[j,i])
paras2_boot[j,i]=tmp[0]
res2_boot[j,i]=tmp[1]

tmpord=np.argsort(paras[:,2])
pl.scatter(range(20),paras[tmpord,2],c="r",s=50,lw=0,zorder=6)
for i in range(50):
pl.scatter(range(20),paras_boot[i,tmpord,2],c="gray",lw=0,alpha=0.5)
pl.savefig("paras_allnets.eps")

pl.scatter(range(20),paras2[tmpord,0]*paras2[tmpord,1],c="r",s=50,lw=0,zorder=6)
for i in range(50):
pl.scatter(range(20),(paras2_boot[i,:,0]*paras2_boot[i,:,1])[tmpord],c="gray",lw=0,alpha=0.5)
pl.savefig("paras2_allnets.eps")

iinet=4
pl.errorbar(range(7),tmp_curve[suc_list[inet]-1][::-1],yerr=np.std(tmp_boot_curve[:,suc_list[inet]-1],axis=0)[::-1],fmt="ro")
pl.plot(np.arange(0,6.05,0.1),fp.fit_func(paras[inet,:],np.arange(0,6.05,0.1)))
pl.xlim(-0.2,6.2)
pl.ylim(0,1.05)
pl.savefig("psy_curve_smp_inet7.eps")

inet=13
pl.errorbar(range(7),tmp_bias_curve[inet],yerr=np.std(tmp_bias_boot_curve[:,inet],axis=0),fmt="ro")
pl.plot(np.arange(0,6.05,0.1),fp.fit_func01(paras2[inet,:],np.arange(0,6.05,0.1)))
pl.xlim(-0.2,6.2)
pl.ylim(-0.02,1.05)
pl.savefig("psy_curve_smp2_inet20.eps")


err=np.zeros((20,2))
err2=np.zeros((20,2))
for i in range(20):
err[i,0]=np.fabs(paras[i,2]-np.sort(paras_boot[:,i,2])[12])
err[i,1]=np.fabs(paras[i,2]-np.sort(paras_boot[:,i,2])[37])
err2[i,0]=np.fabs(paras2[i,0]*paras2[i,1]-np.sort(paras2_boot[:,i,0]*paras2_boot[:,i,1])[12])
err2[i,1]=np.fabs(paras2[i,0]*paras2[i,1]-np.sort(paras2_boot[:,i,0]*paras2_boot[:,i,1])[37])



pl.errorbar(paras[:,2]/0.34718996,(paras2[:,0]*paras2[:,1]),xerr=(err[:,0]/0.34718996,err[:,1]/0.34718996),yerr=(err2[:,0],err2[:,1]),fmt="ro")
pl.savefig("comp_para_para2.eps")


np.mean(res)
Out[134]: 0.072153641119127448

np.mean(res2)
Out[135]: 0.078539477548401751

np.std(res2)
Out[136]: 0.045975965004361227

np.std(res)
Out[137]: 0.041470876575668017


np.save("paras2_err_net",err2)
In [165]: np.save("paras_err_net",err)
In [166]: np.save("paras2_net",paras2[:,0]*paras2[:,1])
In [167]: np.save("paras_err_net",err/0.34718996)
In [168]: np.save("paras_net.eps",paras[:,2]/0.34718996)
"""

# PCA analysis in Figure 3
"""
//    inet=11 is used 


    beh=np.load("beh_long0.40.90.02.npy")
    
    rate=np.load("rate11-0.40.90.02.npy")
    
    
   tmp=rg.main([rate,beh[11-1][:,:2],11,"_"],["evk","get_PCA",False,False,False])
   
   ave_dyn=np.zeros((2,2,61,100))
   ave_dyn[0,0]=np.mean(tmp[1][beh[10][0][0],:,:],axis=0)
   ave_dyn[0,1]=np.mean(tmp[1][beh[10][0][1],:,:],axis=0)
   ave_dyn[1,0]=np.mean(tmp[1][np.array(beh[10][6][0])+50,:,:],axis=0)
   ave_dyn[1,1]=np.mean(tmp[1][np.array(beh[10][6][1])+50,:,:],axis=0)
   for i in range(2):
   for j in range(2):
   for k in range(10):
   for t in range(61):
   pc_dyn[i,j,t,k]=np.mean(tmp[0][1][k,:]*ave_dyn[i,j,t,:])
   
   
    for i in range(3):
    pl.subplot(3,1,i+1)
    pl.plot(range(61),pc_dyn[0,0,:,i])
    pl.plot(range(61),pc_dyn[0,1,:,i])
    pl.plot(range(61),pc_dyn[1,0,:,i])
    pl.plot(range(61),pc_dyn[1,1,:,i])
    
    pl.plot(pc_dyn[0,0,:55,0],pc_dyn[0,0,:55,1])
    pl.plot(pc_dyn[0,1,:55,0],pc_dyn[0,1,:55,1])
    pl.plot(pc_dyn[1,0,:55,0],pc_dyn[1,0,:55,1])
    pl.plot(pc_dyn[1,1,:55,0],pc_dyn[1,1,:55,1])
    
"""

# Analysis of network structure.
"""
    # generate basic data
    for i in range(20):
    Mat=np.zeros((5000,5000))
    inet=suc_list[i]
    tmp=np.loadtxt("dbrnet56_fb_rnd_norm_%d-Si0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % inet)
    for j in range(len(tmp)):
    tmptmp=tmp[j]
    if tmptmp[0]<5000 and tmptmp[1]<5000:
    Mat[int(tmptmp[0]),int(tmptmp[1])]=tmptmp[2]
    np.save("mat%d.npy" % inet,Mat)
    
    tmpord=np.zeros((20,3000))
    for i in range(20):
    inet=suc_list[i]
    rate=np.load("rate%d-0.40.90.02.npy"%inet)
    tmpord[i]=np.argsort(np.mean(rate[0,:,:40,2000:]+rate[6,:,:40,2000:],axis=(0,1)))
    d_foc=np.zeros(20)
    
    
    # eigen spectrum analysis
    
    for inet in suc_list:
    Mat=np.zeros((6000,6000))
    tmp=np.loadtxt("dbrnet56_fb_rnd_norm_%d-Si0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % inet)
    for j in range(len(tmp)):
    tmptmp=tmp[j]
    Mat[int(tmptmp[0]),int(tmptmp[1])]=tmptmp[2]
    tmpeig=LA.eigvals(Mat)
    pl.save("eigen_%d.npy"%inet,tmpeig)
    tmpeig=LA.eigvals(Mat[:5000,:5000])
    pl.save("eigen_ext_%d.npy"%inet,tmpeig)
    
    pl.scatter(eigens[4].real,eigens[4].imag,lw=0)
      ...: pl.scatter(eigens[13].real,eigens[13].imag,c="r",marker="+",s=50)
      ...: pl.savefig("eigen_scatter.eps")
    
   paras=np.load("paras_net.npy")
   pl.scatter(eigens[:,0],paras)
      ...: pl.savefig("max_eig_sens.eps")
   
   pl.subplot(1,2,1)
   pl.scatter(np.max(eigens[:,2:].real,axis=1)-np.min(eigens[:,2:].real,axis=1),paras)
   pl.subplot(1,2,2)
   pl.scatter(np.max(eigens[:,2:].imag,axis=1)-np.min(eigens[:,2:].imag,axis=1),paras)
   pl.savefig("radius_eig_sens.eps")

    #  check regarding to Wout
       for i in range(20):
       inet=suc_list[i]
       tmp=np.loadtxt("dbd56_fb_rnd_norm_%d-Si0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % inet)
       Wout[i]=tmp[3000*300:3000*301,2:4]

            # diff
            diff=np.zeros(20)
            for inet in range(20):
            diff[inet]=np.mean(np.fabs(Wout[inet,:,0]-Wout[inet,:,1]))
            
            stats.pearsonr(diff,paras)
            Out[369]: (0.19886772661796198, 0.40060501805796667)
            
        pl.scatter(np.fabs(np.sum(Wout[:,:,0],axis=1)-np.sum(Wout[:,:,1],axis=1)),paras)
        pl.savefig("diff_wout-sens.eps")
        
        stats.pearsonr(np.fabs(np.sum(Wout[:,:,0],axis=1)-np.sum(Wout[:,:,1],axis=1)),paras)
        Out[37]: (0.24073062102759554, 0.30659364723971777)
        
        pl.plot(range(1000),np.sort(Wout[4][:,0])[-1000:])
        pl.plot(range(1000),np.sort(Wout[4][:,1])[-1000:])
        pl.savefig("Wout_curve-inet7.eps")
        
        
            # consentration of diff
        cumline_Wout=np.zeros((20,100))
        for inet in range(20):
        tmp=np.sort(np.fabs(Wout[inet,:,0]-Wout[inet,:,1]))[-100:]
        cumline_Wout[inet]=np.cumsum(tmp[::-1])/np.sum(tmp)
        
        for i in range(1,10):
        print stats.pearsonr(cumline_Wout[:,i*10],paras)
        (-0.31526088890059423, 0.17575676802608359)
        (-0.31526088890058918, 0.17575676802609044)
        (-0.31526088890059195, 0.17575676802608683)
        (-0.31529522298366458, 0.17570716278574683)
        (-0.32356240417641713, 0.16403922271813237)
        (-0.34599925335934262, 0.13509026138231517)
        (-0.35993907011177639, 0.11903670001262555)
        (-0.35146403161803275, 0.12862459167337351)
        (-0.32094789317368833, 0.16766993083692602)
    
        # consentration of diff sorted by act
        cumline_Wout1=np.zeros((20,100))
        for inet in range(20):
        tmp=np.fabs(Wout[inet,:,0]-Wout[inet,:,1])[tmpord[inet,-100:].astype(int)]
        cumline_Wout1[inet]=np.cumsum(tmp[::-1])/np.sum(tmp)
        
        for i in range(1,10):
        print stats.pearsonr(cumline_Wout1[:,i*10],paras)
        (0.47616127511010281, 0.03380987313266319)
        (0.48914183613362677, 0.028614392758634838)
        (0.023573508938310853, 0.92141702508106382)
        (0.14466013901482189, 0.54285700184454577)
        (-0.091152941514304836, 0.70231494810620521)
        (-0.15653554225295632, 0.50986087069469499)
        (-0.058451992707117414, 0.80662498288159978)
        (0.19450361624005538, 0.41123091489890728)
        (0.14160396928029934, 0.55150280717983025)
    
        pl.scatter(cumline_Wout1[:,20],paras)
        pl.savefig("Wout_by_act_sens.eps")
    
        def fit_func(x,a,b):
        return a+b*x
        tmppara,tmpcov=optimize.curve_fit(fit_func,cumline_Wout1[:,20],paras)
        
        pl.scatter(cumline_Wout1[:,20],paras)
        pl.plot(np.arange(0.16,0.35,0.01),fit_func(np.arange(0.16,0.35,0.01),tmppara[0],tmppara[1]))
        pl.xlim(0.14,0.35)
        pl.savefig("diffWout_byact_sens.eps")
        
        tmp=np.zeros((15,2))
        for i in range(15):
        tmp[i,0]=np.mean(np.fabs(Wout[4][tmpord[4,2700+i*20:2700+(i+1)*20],0]-Wout[4][tmpord[4,2700+i*20:2700+(i+1)*20],1]))
        pl.scatter(range(300),Wout[4][tmpord[4,-300:],0])
        pl.plot(range(10,310,20),3*tmp[:,0])
        pl.savefig("Wout_byact_inet7.eps")
    
    
    # check regarding to Wfb
    Wfb=np.zeros((20,3000,2))
    for i in range(20):
    inet=suc_list[i]
    tmp=np.loadtxt("dbfb56_fb_rnd_norm_%d-Si0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % inet)
    Wfb[i,:,0]=tmp[2000:5000,2]
    Wfb[i,:,1]=tmp[7000:,2]
    
    
        # diff
        diff=np.zeros(20)
        for inet in range(20):
        diff[inet]=np.mean(np.fabs(Wfb[inet,:,0]-Wfb[inet,:,1]))
        
        stats.pearsonr(diff,paras)
        Out[367]: (0.35632050408730709, 0.12306569399724802)
        
        # consentration of diff
        cumline_tmp=np.zeros((20,100))
        for inet in range(20):
        tmp=np.sort(np.fabs(Wfb[inet,:,0]-Wfb[inet,:,1]))[-100:]
        cumline_tmp[inet]=np.cumsum(tmp[::-1])/np.sum(tmp)
        cumlint_Wfb=cumline_tmp
        cumline_tmp=np.zeros((20,100))
        for inet in range(20):
        tmp=np.fabs(Wfb[inet,:,0]-Wfb[inet,:,1])[tmpord[inet,-100:].astype(int)]
        cumline_tmp[inet]=np.cumsum(tmp[::-1])/np.sum(tmp)
        cumlint_Wfb1=cumline_tmp  # sorted by act
        
        for i in range(1,10):
        print stats.pearsonr(cumline_Wfb[:,10*i],paras)
        (-0.31526088890059423, 0.17575676802608359)
        (-0.31526088890058918, 0.17575676802609044)
        (-0.31526088890059195, 0.17575676802608683)
        (-0.31529522298366458, 0.17570716278574683)
        (-0.32356240417641713, 0.16403922271813237)
        (-0.34599925335934262, 0.13509026138231517)
        (-0.35993907011177639, 0.11903670001262555)
        (-0.35146403161803275, 0.12862459167337351)
        (-0.32094789317368833, 0.16766993083692602)
        
        for i in range(1,10):
        print stats.pearsonr(cumlint_Wfb1[:,10*i],paras)
        (0.053994399479237926, 0.82113414915874405)
        (0.062368312867807953, 0.7939274590148323)
        (-0.03424081154046147, 0.88604457866226871)
        (0.057856330168017431, 0.80856041466073603)
        (0.05585527193941827, 0.81507005240424579)
        (-0.0078249030452089488, 0.97388105712594331)
        (-0.065944347457104813, 0.78237656325122817)
        (-0.23788073965102108, 0.31252949639955974)
        (-0.22356469328453293, 0.34338284397494201)
    
    
    #check loop through wout->Wfb
    
    tmpmat=np.zeros((20,2,3000))
    for inet in range(20):
    for i in range(3000):
    tmpmat[inet,0,i]=Wout[inet,i,0]*Wfb[inet,i,0]
    tmpmat[inet,1,i]=Wout[inet,i,1]*Wfb[inet,i,1]
    
        #diff
        diff=np.zeros(20)
        for inet in range(20):
        diff[inet]=np.mean(np.fabs(tmpmat[inet,0,:]-tmpmat[inet,1,:]))
        
        stats.pearsonr(diff,paras)
        Out[372]: (-0.15587096292538477, 0.51168170551733749)
        
        stats.pearsonr(np.fabs(np.sum(tmpmat[:,0],axis=1)-np.sum(tmpmat[:,1],axis=1)),paras)
        Out[48]: (0.27241624277260423, 0.24524385321115685)


        # consentration of diff
        cumline_tmp=np.zeros((20,100))
        for inet in range(20):
        tmp=np.sort(np.fabs(tmpmat[inet,0,:]-tmpmat[inet,1,:]))[-100:]
        cumline_tmp[inet]=np.cumsum(tmp[::-1])/np.sum(tmp)
        cumlint_loop=cumline_tmp
        cumline_tmp=np.zeros((20,100))
        for inet in range(20):
        tmp=np.fabs(tmpmat[inet,0,:]-tmpmat[inet,1,:])[tmpord[inet,-100:].astype(int)]
        cumline_tmp[inet]=np.cumsum(tmp[::-1])/np.sum(tmp)
        cumlint_loop1=cumline_tmp
        
        for i in range(1,10):
        print stats.pearsonr(cumline_loop[:,10*i],paras)
        (0.10231829609506414, 0.66774305936653799)
        (0.039518627091156958, 0.86861587488262926)
        (-0.005989285437015472, 0.98000686002956583)
        (-0.011664763541313383, 0.96107165753224788)
        (-0.030207321893747599, 0.89939866639487576)
        (-0.029309030313261632, 0.90237640492355586)
        (0.0086024167780047404, 0.97128675214977211)
        (0.048430350913494, 0.83932301437008316)
        (0.05993824791950654, 0.80180056877023076)
        
        for i in range(1,10):
        print stats.pearsonr(cumline_loop1[:,10*i],paras)
        (0.36179481608972769, 0.11700750921637662)
        (0.30534213211702127, 0.19048885943703611)
        (0.15640343734155002, 0.51022256885454853)
        (0.23481239710126564, 0.31899709663169185)
        (0.18164632611555442, 0.44340832207784486)
        (0.032044329133261884, 0.89331325709113052)
        (-0.15293298453303356, 0.51976824329956783)
        (-0.042025094479905309, 0.86035877697952379)
        (-0.044623767229956902, 0.85181264280724212)
        
        
        # # of high loops
    n_high=np.zeros((20,10,2))
    
    for inet in range(20):
    for j in range(10):
    n_high[inet,j,0]=len([k for k in tmpmat[inet,0] if k>j*0.0005])
    n_high[inet,j,1]=len([k for k in tmpmat[inet,1] if k>j*0.0005])
    pl.scatter(range(50),tmpmat[4,0,tmpord[-50:]],c="b",lw=0)
    pl.scatter(range(50),tmpmat[4,1,tmpord1[-50:]],c="r",lw=0)
    pl.ylim(0,0.015)
    pl.savefig("Wout_fb_loop-inet7.eps")
    
    pl.scatter(np.fabs(n_high[:,0,0]-n_high[:,0,1]),paras)
    pl.savefig("num_loop_sens_nets.eps")
    
    pval=np.zeros(10)
    
    for i in range(10):
    tmp=stats.pearsonr(np.fabs(n_high[:,1,0]-n_high[:,1,1]),paras)
    pval[i]=tmp[1]
    pl.plot(range(10),pval)
    pl.savefig("num_loop_pval_thres.eps")
    
    for i in range(10):
    tmp=stats.pearsonr(np.fabs(n_high[:,i,0]-n_high[:,i,1]),paras)
    print tmp[1]
    0.896932358865
    0.0208188082802    <---- this is only significant value, but might be quite arbitraly
    0.599228733765
    0.44588213779
    0.789000617533
    0.176746439384
    0.219759503698
    0.676547321301
    0.692385033086
    0.691419515379
    
    
    
    
    # recurrent connection and neural activity
    
    cumline_pre1=np.zeros((20,100,10))
    cumline_post1=np.zeros((20,100,10))
    cumline_pre=np.zeros((20,100))
    cumline_post=np.zeros((20,100))
    
    for i in range(20):
    tbin=100
    Mat=np.load("mat%d.npy"%suc_list[i])
    tmp=np.sort(np.mean(Mat,axis=1))[-tbin:]
    cumline_pre[i,:]=np.cumsum(tmp[::-1])/np.sum(tmp)
    tmp=np.sort(np.mean(Mat,axis=0))[-tbin:]
    cumline_post[i,:]=np.cumsum(tmp[::-1])/np.sum(tmp)
    for j in range(10):
    nsmp=10*(j+1)
    tmp=np.mean(Mat[:,tmpord[i,-nsmp:].astype(int)+2000],axis=1)[tmpord[i,-tbin:].astype(int)+2000]
    cumline_pre1[i,:,j]=np.cumsum(tmp[::-1])/np.sum(tmp)
    tmp=np.mean(Mat[tmpord[i,-nsmp:].astype(int)+2000],axis=0)[tmpord[i,-tbin:].astype(int)+2000]
    cumline_post1[i,:,j]=np.cumsum(tmp[::-1])/np.sum(tmp)
    
    
    for i in range(1,10):
    print stats.pearsonr(cumline_pre[:,10*i],paras)
    (-0.2831082844602652, 0.22646555788502729)
    (-0.22546058480216064, 0.33919814031617329)
    (-0.16117230842850525, 0.49724376875967391)
    (-0.12346502827283301, 0.60404594378254106)
    (-0.11624757932321797, 0.6255067549694544)
    (-0.10742687458488663, 0.65213253088954026)
    (-0.11041520116251871, 0.64306460581368019)
    (-0.040155720717239107, 0.86651581103509356)
    (-0.00079707527195886521, 0.99733899225922995)
    
    for i in range(1,10):
    print stats.pearsonr(cumline_post[:,10*i],paras)
    (0.091524972274650937, 0.70115344897366083)
    (0.11909032590367379, 0.61701804365586721)
    (0.094689094473569407, 0.69130091368908819)
    (0.040507475861160637, 0.86535668185335379)
    (0.039523181881033688, 0.86860085781836971)
    (0.083660308140324977, 0.72583951826514537)
    (0.11930408426978595, 0.61638161011995085)
    (0.14585834821287277, 0.53948424029103681)
    (0.1747143056878746, 0.46128579023669947)

    pval_post=np.zeros((10,9))
    for j in range(10):
    for i in range(1,10):
    pval_post[j,i-1]=stats.pearsonr(cumline_post1[:,10*i,j],paras)[1]
    
    pval_pre=np.zeros((10,9))
    for j in range(10):
    for i in range(1,10):
    pval_pre[j,i-1]=stats.pearsonr(cumline_pre1[:,10*i,j],paras)[1]
    
    
    inet=7
    Mat7=np.zeros((5000,5000))
    tmp=np.loadtxt("dbrnet56_fb_rnd_norm_%d-Si0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % inet)
    for j in range(len(tmp)):
    tmptmp=tmp[j]
    if tmptmp[0]<5000 and tmptmp[1]<5000:
    Mat7[int(tmptmp[0]),int(tmptmp[1])]=tmptmp[2]
    
    pl.scatter(range(200),5000*(np.mean(Mat7[:,2000:],axis=0))[tmpord[-200:]]-1,lw=0)
    pl.plot(range(200),np.mean(rate[:,:,:40,2000:],axis=(0,1,2))[tmpord[-200:]])
    pl.savefig("rate_Wr_in0inet7.eps")
    
    pl.scatter(range(200),5000*(np.mean(Mat7[2000:,:],axis=1))[tmpord[-200:]]-1,lw=0,c="r")
    pl.plot(range(200),np.mean(rate[:,:,:40,2000:],axis=(0,1,2))[tmpord[-200:]])
    pl.savefig("rate_Wr_out-inet7.eps")
"""


# Analysis by PCA dyn (S4)
"""
    pccurve=np.zeros((20,100,2,3))
    suc_list=[2,3,5,6,7,8,11,13,14,15,16,18,19,20,22,23,24,25,26,30]
    for i in range(20):
    inet=suc_list[i]
    rate=np.load("rate_long%d0.40.90.02.npy" % inet )
    tsmp=range(20,30)
    tmpord=np.argsort(np.mean(rate[:,:,tsmp,2000:],axis=(0,1,2)))
    pcasmp=np.mean(rate[:,:,20:30,tmpord[-100:]+2000],axis=2)
    PC=fp.PCA(pcasmp.reshape(350,100))
    pccurve[i,:,0,0]=PC[0]
    tsmp=range(30,40)
    tmpord=np.argsort(np.mean(rate[:,:,tsmp,2000:],axis=(0,1,2)))
    pcasmp=np.mean(rate[:,:,30:40,tmpord[-100:]+2000],axis=2)
    PC=fp.PCA(pcasmp.reshape(350,100))
    pccurve[i,:,0,1]=PC[0]
    tsmp=range(40,50)
    tmpord=np.argsort(np.mean(rate[:,:,tsmp,2000:],axis=(0,1,2)))
    pcasmp=np.mean(rate[:,:,40:50,tmpord[-100:]+2000],axis=2)
    PC=fp.PCA(pcasmp.reshape(350,100))
    pccurve[i,:,0,2]=PC[0]
    tsmp=range(20,30)
    tmpord=np.argsort(np.mean(rate[:,:,tsmp,:],axis=(0,1,2)))
    pcasmp=np.mean(rate[:,:,20:30,tmpord[-100:]],axis=2)
    PC=fp.PCA(pcasmp.reshape(350,100))
    pccurve[i,:,1,0]=PC[0]
    tsmp=range(30,40)
    tmpord=np.argsort(np.mean(rate[:,:,tsmp,:],axis=(0,1,2)))
    pcasmp=np.mean(rate[:,:,30:40,tmpord[-100:]],axis=2)
    PC=fp.PCA(pcasmp.reshape(350,100))
    pccurve[i,:,1,1]=PC[0]
    tsmp=range(40,50)
    tmpord=np.argsort(np.mean(rate[:,:,tsmp,:],axis=(0,1,2)))
    pcasmp=np.mean(rate[:,:,40:50,tmpord[-100:]],axis=2)
    PC=fp.PCA(pcasmp.reshape(350,100))
    pccurve[i,:,1,2]=PC[0]
    
    pl.scatter(cumcurve[:,5,1,1],paras)
    pl.savefig("pca_cont_sens_model.eps")
    
    
    
    
    
    ncell=10
    ntbin=50
    ntrial=50
    nsmp=5
    if_all=True
    pcsmp=[]
    var_dyn=[]
    log_var=[]
    for i in range(20):
    pcsmp.append([])
    inet=suc_list[i]
    rate=np.load("rate%d-0.40.90.02.npy" % inet)
    
    # pick up cells
    if if_all:
    tmplist=set(range(5000))
    else:
    tmplist=set(range(3000))
    for ipat in range(7):
    if if_all:
    for j in range(nsmp):
    tmp=np.mean(rate[ipat,:,j*10:(j+1)*10,0:],axis=(0,1))
    tmplist=set([itmp for itmp in range(5000) if tmp[itmp]>0.03])&tmplist
    else:
    for j in range(nsmp):
    tmp=np.mean(rate[ipat,:,j*10:(j+1)*10,2000:],axis=(0,1))
    tmplist=set([itmp for itmp in range(3000) if tmp[itmp]>0.03])&tmplist
    tmpord=list(tmplist)
    if if_all:
    tmpord=np.array(tmpord)
    else:
    tmpord=np.array(tmpord)+2000
    diff=np.zeros((7,len(tmpord)))
    for ipat in  range(7):
    for icell in range(len(tmpord)):
    diff[ipat,icell]=np.fabs(np.mean(np.mean(rate[ipat,:,:10,tmpord[icell]],axis=1))-np.mean(np.mean(rate[ipat,:,10:40,tmpord[icell]],axis=1)))
    tmptmp=tmpord[np.argsort(np.mean(diff,axis=0)).astype(int)]
    tmpord=list(tmptmp)
    print len(tmpord)
    if len(tmpord)<ncell:
    continue
    
    
    for ipat in range(7):
    pcsmp[i].append([])
    for j in range(nsmp):
    tmp=np.zeros((ncell,ntrial))
    for icell in range(ncell):
    tmp[icell]=np.mean(rate[ipat,:,j*10:(j+1)*10,tmpord[-ncell+icell]],axis=1)/np.mean(np.mean(rate[ipat,:,j*10:(j+1)*10,tmpord[-ncell+icell]],axis=1))
    pcsmp[i][ipat].append(tmp)
    
    var_dyn.append(np.zeros((7,nsmp,ncell)))
    log_var.append(np.zeros((7,nsmp)))
    for ipat in range(7):
    for j in range(nsmp):
    PCs=fp.PCA(pcsmp[i][ipat][j].T)
    var_dyn[i][ipat,j]=PCs[0]
    log_var[i][ipat,j]=np.mean(np.log(var_dyn[i][ipat,j]))
    
"""

# analysis by FDA (2017.3.3)
"""
inet=20
rate=np.load("rate_long%d0.40.90.02.npy" % inet)
tmp20=fp.tmp_FDA([beh[inet-1,:,0],beh[inet-1,:,1],beh[inet-1,:,2],rate,0,0,5])

pl.plot(range(19),np.mean(tmp20[2][beh[inet-1][0][0],:],axis=0))
pl.plot(range(19),np.mean(tmp20[2][beh[inet-1][0][1],:],axis=0))
ipat=6
pl.plot(range(19),np.mean(tmp20[2][np.array(beh[inet-1][ipat][0])+50*ipat,:],axis=0))
pl.plot(range(19),np.mean(tmp20[2][np.array(beh[inet-1][ipat][1])+50*ipat,:],axis=0))
pl.savefig("fda_dyn_inet20_fam.eps")

pl.plot(range(19),np.mean(tmp20[2][beh[inet-1][0][0],:],axis=0))
ipat=6
pl.plot(range(19),np.mean(tmp20[2][np.array(beh[inet-1][ipat][1])+50*ipat,:],axis=0))
ipat=2
pl.plot(range(19),np.mean(tmp20[2][np.array(beh[inet-1][ipat][0])+50*ipat,:],axis=0))
pl.plot(range(19),np.mean(tmp20[2][np.array(beh[inet-1][ipat][1])+50*ipat,:],axis=0))
pl.savefig("fda_dyn_inet20_UF2.eps")

inet=7
same as the above


## calc of pfm
#hist gram
pl.hist(tmp20[2][beh[inet-1][0][0],0],bins=20,range=(-800,800))
pl.hist(tmp20[2][np.array(beh[inet-1][6][1])+300,0],bins=20, range=(-800,800))
pl.savefig("hist_fda_inet7.eps")


pfm=[]
for inet in suc_list:
rate=np.load("rate_long%d0.40.90.02.npy" % inet)
tmpdyn=fp.tmp_FDA([beh[inet-1,:,0],beh[inet-1,:,1],beh[inet-1,:,2],rate,0,0,5])
tmppfm=fp.calc_pfm_FDA([beh[inet-1,:,0],beh[inet-1,:,1],beh[inet-1,:,2],tmpdyn[2]])
pfm.append(tmppfm)
pl.scatter(np.mean(pfm_tmp,axis=1),paras[:,2])
pl.savefig("disc_sens_nets.eps")

stats.pearsonr(np.mean(pfm_tmp,axis=1),paras[:,2])
Out[253]: (-0.052891042078255929, 0.82473434412461444)

pl.scatter(range(7),pfm_tmp[4],c="g",zorder=6,s=60,lw=0)
pl.scatter(range(7),pfm_tmp[13],c="r",zorder=6,s=60,lw=0)
pl.bar(range(7),np.mean(pfm_tmp,axis=0))
pl.savefig("discr_all_net.eps")

"""

# learning curve
"""
    tmpscore=np.zeros((30,300))
    avescore=np.zeros((30,295))
    for inet in range(30):
    tmp=np.loadtxt("dbs56_fb_rnd_norm_%d-Si0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % (inet+1))
    for i in range(300):
    if tmp[i,2]>0.:
    tmpscore[inet,i]=1
    else:
    tmpscore[inet,i]=0
    for i in range(300-5):
    ave_score[inet,i]=np.mean(tmpscore[inet,i:i+5])
    
    pl.plot(range(295),avescore[:5].T)
    pl.plot(range(295),np.mean(avescore,axis=0),c="gray",lw=5)
    pl.ylim(0,1.05)
    pl.savefig("lrn_curve.eps")
    
"""

# relation between learning curve and sensitivity
"""
    for i in range(20):
    nnet=suc_set[i]
    tmp=np.loadtxt("dbs56_fb_rnd_norm_%d-Si0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % nnet)
    for j in range(300-30):
    suc_rate[i,j]=np.mean((tmp[j:j+30,2].astype(int)+1))
    
    ths=0.8
    for i in range(20):
    for j in range(270):
    if suc_rate[i,j]>ths:
    ths_time[i]=j
    break
    
    stats.pearsonr(para,ths_time)
    Out[100]: (0.45015805624208999, 0.046409925769496409)
    
"""


# analysis of RT
"""
# RT distribution
tmpF=[]
for inet in suc_list:
tmp=list(beh[inet-1][0][2])
tmpF=tmpF+tmp
tmp=list(beh[inet-1][6][2])
tmpF=tmpF+tmp
tmpUF=[]
for inet in suc_list:
for j in range(1,6):
tmp=list(beh[inet-1][j][2])
tmpUF=tmpUF+tmp

for i in range(len(tmpF)):
tmpF[i]-=100
if tmpF[i]>=900:
tmpF[i]=905
for i in range(len(tmpUF)):
tmpUF[i]-=100
if tmpUF[i]>=900:
tmpUF[i]=905

    pl.subplot(1,2,1)
    pl.hist(tmpF,bins=91,range=(0,910),normed=1)
    pl.hist(tmpUF,bins=91,range=(0,910),normed=1,alpha=0.2)
    pl.xlim(0,910)
    pl.savefig("hist_RT_nets.eps")
    

inet=7
tmp=[]
for i in [0,6]:
tmp+=list(beh[inet-1][i][2])
tmp=[1040 if t<1 else t for t in tmp ]
pl.hist(tmp,bins=21,range=(100,1045),normed=1)
tmp=[]
for i in range(1,6):
tmp+=list(beh[inet-1][i][2])
tmp=[1040 if t<1 else t for t in tmp ]
pl.hist(tmp,bins=21,range=(100,1045),normed=1,alpha=0.1)
pl.xlim(100,1050)
pl.savefig("hist_RT_net7.eps")

"""



# pca analysis of dynamics
"""
    
    t_terminated_evk=[]
    for i in range(20):
    inet=suc_list[i]
    t_terminated_evk.append([])
    for j in range(7):
    beh=fp.get_behav1(["normal","_","_",False],[inet,0.1*j,0.4,0.9,0.02,50,0.095])
    
    
    
    PC=np.zeros((20,100))
    for i in range(20):
    tmp=fp.gen_pca(suc_list[i],t_terminated_evk,suc_list,0)
    PC[i]=tmp[0]

pl.plot(range(100),np.cumsum(PC[4])/np.sum(PC[4]))
pl.plot(range(100),np.cumsum(PC[13])/np.sum(PC[13]))
pl.savefig("PC_spectrum_inet7_20.eps")

pl.scatter(np.sum(PC[:,:3],axis=1)/np.sum(PC,axis=1),paras)
pl.savefig("pca_sens_rat.eps")
stats.pearsonr(np.sum(PC[:,:3],axis=1)/np.sum(PC,axis=1),paras)
Out[427]: (-0.11196027213345564, 0.63839505380652228)

ntest=range(1,10)+range(10,100,10)
for i in range(18):
itmp=ntest[i]
pval[i]=stats.pearsonr(np.sum(PC[:,:itmp],axis=1)/np.sum(PC,axis=1),paras)[1]

pl.plot(ntest,pval)
pl.scatter(ntest,pval)
pl.savefig("pval_pca_dyn_sens.eps")


"""


# for psychometric curve for typical gradual (inet=11) and flat curves (inet=26)
"""
# samples of output neural trajectories (in Fig1)
tmpout=np.zeros((7,50,600,2))
rtime=np.zeros((7,50))
for i in range(7):
tmp=fp.get_behav1(["normal","_","_","get_trj"],[11,0.1*i,0.4,0.9,0.02,50,0.05])
output11=tmp[5]
for iinit in range(50):
rtime[i,iinit]=tmp[3][iinit]
tmpout[i,iinit,:,0]=flt.gaussian_filter(output11[iinit][:600,1],3)
tmpout[i,iinit,:,1]=flt.gaussian_filter(output11[iinit][:600,2],3)

for i in range(10):
pl.plot(tmpout[0,i,:int(rtime[0,i])+5,0],tmpout[0,i,:int(rtime[0,i])+5,1],c="gray")
pl.scatter(tmpout[0,i,100,0],tmpout[0,i,100,1],c="gray",s=30)
pl.plot(np.mean(tmpout[0,:,:400,0],axis=0),np.mean(tmpout[0,:,:400,1],axis=0))
pl.scatter(np.mean(tmpout[0,:,100,0],axis=0),np.mean(tmpout[0,:,100,1],axis=0),s=50,c="r")
pl.savefig("outdyn_inet0_inet11_smp.eps")

for i in range(10):
pl.plot(tmpout[6,i,:int(rtime[6,i])+5,0],tmpout[6,i,:int(rtime[6,i])+5,1],c="gray")
pl.scatter(tmpout[6,i,100,0],tmpout[6,i,100,1],c="gray",s=30)
pl.plot(np.mean(tmpout[6,:,:400,0],axis=0),np.mean(tmpout[6,:,:400,1],axis=0))
pl.scatter(np.mean(tmpout[6,:,100,0],axis=0),np.mean(tmpout[6,:,100,1],axis=0),s=50,c="r")
pl.savefig("outdyn_inet6_inet11_smp.eps")

    # output neural tractories before learning
for i in range(10):
pl.plot(tmp_ave_dyn[i*2+1,:350,0],tmp_ave_dyn[i*2+1,:350,1],c="gray")
pl.scatter(tmp_ave_dyn[i*2+1,100,0],tmp_ave_dyn[i*2+1,100,1],c="gray",s=30)
pl.plot(np.mean(tmp_ave_dyn[1::2,:350,0],axis=0),np.mean(tmp_ave_dyn[1::2,:350,1],axis=0))
pl.scatter(np.mean(tmp_ave_dyn[1::2,100,0],axis=0),np.mean(tmp_ave_dyn[1::2,100,1],axis=0),s=50,c="r")
pl.savefig("outdyn_before_lrn_iapt6_inet11_smp.eps")

for i in range(10):
pl.plot(tmp_ave_dyn[i*2,:350,0],tmp_ave_dyn[i*2,:350,1],c="gray")
pl.scatter(tmp_ave_dyn[i*2,100,0],tmp_ave_dyn[i*2,100,1],c="gray",s=30)
pl.plot(np.mean(tmp_ave_dyn[::2,:350,0],axis=0),np.mean(tmp_ave_dyn[::2,:350,1],axis=0))
pl.scatter(np.mean(tmp_ave_dyn[::2,100,0],axis=0),np.mean(tmp_ave_dyn[::2,100,1],axis=0),s=50,c="r")
pl.savefig("outdyn_before_lrn_iapt0_inet11_smp.eps")


# RT distribution
tmp=list(np.array(suc_list)[[19,  1,  7, 13, 15,  3, 16, 18, 11,  5]]-1)
tmptmp=[]
for i in tmp:
tmptmp+=list(beh04[i][0][2])+list(beh04[i][6][2])
pl.hist(tmptmp,bins=30,range=(200,600),alpha=0.5)
tmp=list(np.array(suc_list)[[ 6, 10, 12,  0,  9,  8,  2,  4, 17, 14]]-1)
tmptmp=[]
for i in tmp:
tmptmp+=list(beh04[i][0][2])+list(beh04[i][6][2])
pl.hist(tmptmp,bins=30,range=(200,600),alpha=0.5)
pl.savefig("RT_fam_model.eps")




# generate beh
beh=fp.gen_beh(range(1,31),0.05,0.4)
np.save("beh04.npy",beh)
np.save("beh03.npy",beh03)
np.save("beh05.npy",beh05)
np.save("beh06.npy",beh0)


tmp_curve=fp.gen_psycho_curve(beh04,0.05)


tmp_curve_err=np.ones(7)*1/np.sqrt(50)
pl.subplot(1,2,1)
pl.scatter(range(7),tmp_curve[10])
pl.errorbar(range(7),tmp_curve[10],yerr=tmp_curve_err,fmt='ro',ecolor='g')
pl.xlim(-0.3,6.3)
pl.ylim(-0.1,1.1)
pl.subplot(1,2,2)
pl.scatter(range(7),tmp_curve[25])
pl.errorbar(range(7),tmp_curve[25],yerr=tmp_curve_err,fmt='ro',ecolor='g')
pl.xlim(-0.3,6.3)
pl.ylim(-0.1,1.1)
Out[2247]: (-0.1, 1.1)

pl.savefig("psy_model_sample.eps")

# plot all psycho_curves
norm_psy_curve=np.zeros((20,7))
for i in range(20):
inet=suc_list[i]-1
tmptmp=np.zeros(7)
tmptmp[:]=(tmp_curve[inet]-min(tmp_curve[inet]))/(max(tmp_curve[inet])-min(tmp_curve[inet]))
norm_psy_curve[i]=tmptmp[::-1]
for i in range(20):
pl.scatter(range(7),norm_psy_curve[i],c="gray",s=60,linewidth=0)
pl.plot(range(7),norm_psy_curve[i],c="gray")
pl.scatter(range(7),np.mean(norm_psy_curve,axis=0),c="black",s=80,linewidth=0)
pl.plot(range(7),norm_psy_curve[4],c="b")
pl.plot(range(7),norm_psy_curve[18],c="r")
pl.savefig("sample_psycho_curve_model.eps")

# fitting parameters
paras=[]
err_app=[]
for i in range(len(suc_list)):
tmp=fp.calc_type_psy(tmp_curve[suc_list[i]-1][::-1])
paras.append(tmp[0])
err_app.append(tmp[1])




# comparing with other parameters
tmp=np.zeros(4)
tmp_error=np.zeros(4)

tmp[0]=np.mean(err_app3)
tmp_error[0]=np.std(err_app3)
tmp[1]=np.mean(err_app)
tmp_error[1]=np.std(err_app)
tmp[2]=np.mean(err_app5)
tmp_error[2]=np.std(err_app5)
tmp[3]=np.mean(err_app6)
tmp_error[3]=np.std(err_app6)

pl.scatter(range(4),tmp)
pl.errorbar(range(4),tmp,yerr=tmp_error,fmt='ro',ecolor='g')
Out[2388]: <Container object of 3 artists>

pl.savefig("err_fit_models.eps")


#
norm_curve=np.zeros((20,100,7))
for i in range(len(suc_list)):
tmp=np.load("rate%d-0.40.90.02.npy" % suc_list[i])
tmpord=np.argsort(np.mean(tmp[:,:,10:60,:2000],axis=(0,1,2)))
tmp_curve=np.mean(tmp[:,:,10:60,tmpord[-100:]],axis=(1,2))
tmp_curve=tmp_curve.T
for j in range(100):
tmp_curve[j,:]=(tmp_curve[j,:]-np.min(tmp_curve[j]))/(np.max(tmp_curve[j])-np.min(tmp_curve[j]))
norm_curve[i]=tmp_curve



# FDA_dyn (old  version)
inet=26
tmp26=fp.tmp_FDA([beh04[inet-1,:,0],beh04[inet-1,:,1],beh04[inet-1,:,2],rate,0,0,5])

tmp_curve=tmp26[2][0,61-28:61-28+25]
tmplist=[[0],[],[],[]]
cnt=1
for i in range(1,50):
if beh04[inet-1,0,2][i]>250:
rt=int(beh04[inet-1,0,2][i]/10)
tmp_curve=np.vstack((tmp_curve,tmp26[2][i,61-rt:61-rt+25]))
if i in beh04[inet-1,0,0]:
tmplist[0].append(cnt)
elif i in beh04[inet-1,0,1]:
tmplist[1].append(cnt)
cnt=cnt+1
ipat=6
idx_geta=300
for i in range(50):
if beh04[inet-1,ipat,2][i]>250:
rt=int(beh04[inet-1,ipat,2][i]/10)
tmp_curve=np.vstack((tmp_curve,tmp26[2][idx_geta+i,61-rt:61-rt+25]))
if i in beh04[inet-1,ipat,0]:
tmplist[2].append(cnt)
elif i in beh04[inet-1,ipat,1]:
tmplist[3].append(cnt)
cnt=cnt+1



tmp_curve_n3=tmp26[2][150,61-28:61-28+25]
tmplist_n3=[[0],[]]
cnt=1
ipat=3
idx_geta=50*ipat
for i in range(1,50):
if beh04[inet-1,ipat,2][i]>250:
rt=int(beh04[inet-1,ipat,2][i]/10)
tmp_curve_n3=np.vstack((tmp_curve_n3,tmp26[2][idx_geta+i,61-rt:61-rt+25]))
if i in beh04[inet-1,ipat,0]:
tmplist_n3[0].append(cnt)
elif i in beh04[inet-1,ipat,1]:
tmplist_n3[1].append(cnt)
cnt=cnt+1


dyn_std=np.zeros((6,25))
for i in range(4):
dyn_std[i]=np.std(tmp_curve[tmplist[i]],axis=0)
dyn_std[4]=np.std(tmp_curve_n3[tmplist_n2[0]],axis=0)
dyn_std[5]=np.std(tmp_curve_n3[tmplist_n2[1]],axis=0)
pl.plot(range(25),np.mean(tmp_curve[tmplist[0]],axis=0),c="b",alpha=0.3)
pl.plot(range(25),np.mean(tmp_curve[tmplist[3]],axis=0),c="purple",alpha=0.3)
pl.plot(range(25),np.mean(tmp_curve_n3[tmplist_n3[0]],axis=0),c="b")
pl.plot(range(25),np.mean(tmp_curve_n3[tmplist_n3[1]],axis=0),c="r")
pl.errorbar(range(25),np.mean(tmp_curve_n3[tmplist_n3[0]],axis=0),yerr=dyn_std[4],c="b")
pl.errorbar(range(25),np.mean(tmp_curve_n3[tmplist_n3[1]],axis=0),yerr=dyn_std[5],c="r")
pl.savefig("FDA_dyn_nov3_net26.eps")

pl.plot(range(25),np.mean(tmp_curve[tmplist[0]],axis=0),c="b")
pl.plot(range(25),np.mean(tmp_curve[tmplist[1]],axis=0),c="cyan")
pl.plot(range(25),np.mean(tmp_curve[tmplist[2]],axis=0),c="r")
pl.plot(range(25),np.mean(tmp_curve[tmplist[3]],axis=0),c="purple")
pl.errorbar(range(25),np.mean(tmp_curve[tmplist[0]],axis=0),yerr=dyn_std[0],c="b")
pl.errorbar(range(25),np.mean(tmp_curve[tmplist[1]],axis=0),yerr=dyn_std[1],c="cyan")
pl.errorbar(range(25),np.mean(tmp_curve[tmplist[2]],axis=0),yerr=dyn_std[2],c="r")
pl.errorbar(range(25),np.mean(tmp_curve[tmplist[3]],axis=0),yerr=dyn_std[3],c="purple")
pl.savefig("FDA_dyn_fam_net26.eps")


# pfm of discrimination ability by FDA

pl.bar(range(7),np.mean(pfm_curve,axis=0))
pl.bar(range(7),np.mean(pfm_curve[:],axis=0))
pl.scatter(range(7),pfm_curve[6],c="b")
pl.scatter(range(7),pfm_curve[18],c="r")
pl.savefig("FDA_pfm.eps")

pl.scatter(np.mean(pfm_curve,axis=1),paras[np.array(suc_list)-1,2])
pl.savefig("FDA_pfm_beh.eps")


### reaction time data
##### warning!!!!!!!!!!     the following  RT is aligned at beginning of simulation, not stimulation
beh04=np.load("beh04.npy")
tmp_curve=fp.gen_psycho_curve(beh04,0.05)
paras=fp.gen_paras(tmp_curve,"norm")

FL_rtime=[]
for i in range(20):
FL_rtime.append([])
inet=suc_list[i]
tmp=[]
for j in range(50):
if beh04[inet-1][0][2][j]>10:
tmp.append(beh04[inet-1][0][2][j])
if beh04[inet-1][6][2][j]>10:
tmp.append(beh04[inet-1][6][2][j])
tmp1=[]
for l in range(1,6):
for j in range(50):
if beh04[inet-1][l][2][j]>10:
tmp1.append(beh04[inet-1][l][2][j])
FL_rtime[i].append(tmp)
FL_rtime[i].append(tmp1)

tmp=np.zeros(20)
for i in range(20):
tmp[i]=np.median(FL_rtime[i][1])
pl.scatter(tmp,paras[np.array(suc_list)-1,2])
print stats.pearsonr(tmp,paras[np.array(suc_list)-1,2])
pl.savefig("rtime_med_rats_nov.eps")


err_FS_RT_L=[]
err_FS_RT_H=[]
err_UFS_RT_L=[]
err_UFS_RT_H=[]
for i in range(20):
err_FS_RT_L.append(tmp[i]-(np.sort(FL_rtime[i][0]))[len(FL_rtime[i][0])/4])
err_UFS_RT_L.append(tmp[i]-(np.sort(FL_rtime[i][1]))[len(FL_rtime[i][1])/4])
err_FS_RT_H.append((np.sort(FL_rtime[i][0]))[(3*len(FL_rtime[i][0]))/4]-tmp[i])
err_UFS_RT_H.append((np.sort(FL_rtime[i][1]))[(3*len(FL_rtime[i][1]))/4]-tmp[i])
pl.scatter(tmp,paras[np.array(suc_list)-1,2])
pl.errorbar(tmp,paras[np.array(suc_list)-1,2],xerr=[err_UFS_RT_L,err_UFS_RT_H],fmt='ro',ecolor='g')
pl.savefig("rtime_med_models_nov_with_errbar.eps")

tmp=np.zeros(20)
for i in range(20):
tmp[i]=np.median(FL_rtime[i][0])
pl.scatter(tmp,paras[np.array(suc_list)-1,2])
print stats.pearsonr(tmp,paras[np.array(suc_list)-1,2])
pl.savefig("rtime_med_rats_fam.eps")

tmp=np.zeros(20)
for i in range(20):
tmp[i]=np.median(FL_rtime[i][0])
err_FS_RT_L=[]
err_FS_RT_H=[]
err_UFS_RT_L=[]
err_UFS_RT_H=[]
for i in range(20):
err_FS_RT_L.append(tmp[i]-(np.sort(FL_rtime[i][0]))[len(FL_rtime[i][0])/4])
err_UFS_RT_L.append(tmp[i]-(np.sort(FL_rtime[i][1]))[len(FL_rtime[i][1])/4])
err_FS_RT_H.append((np.sort(FL_rtime[i][0]))[(3*len(FL_rtime[i][0]))/4]-tmp[i])
err_UFS_RT_H.append((np.sort(FL_rtime[i][1]))[(3*len(FL_rtime[i][1]))/4]-tmp[i])
pl.scatter(tmp,paras[np.array(suc_list)-1,2])
pl.errorbar(tmp,paras[np.array(suc_list)-1,2],xerr=[err_FS_RT_L,err_FS_RT_H],fmt='ro',ecolor='g')
pl.savefig("rtime_med_models_fam_with_errbar.eps")


tmp=np.zeros(20)
for i in range(20):
tmp[i]=np.median(FL_rtime[i][1])-np.median(FL_rtime[i][0])
pl.scatter(tmp,paras[np.array(suc_list)-1,2])
print stats.pearsonr(tmp,paras[np.array(suc_list)-1,2])
pl.savefig("rtime_med_rats_nov-fam.eps")



# regression dynamics
inet=11
rate=np.load("rate11-0.40.90.02.npy")
tmp=rg.main([rate,beh04[inet-1][:,:2],inet,_,_])

    # get reaction time for different conditions
rt=[[],[],[],[]]
for i in range(50):
if beh04[10][0][2][i]>10:
if i in beh04[10][0][0]:
rt[0].append(beh04[10][0][2][i])
else:
rt[1].append(beh04[10][0][2][i])
if beh04[10][6][2][i]>10:
if i in beh04[10][6][0]:
rt[2].append(beh04[10][6][2][i])
else:
rt[3].append(beh04[10][6][2][i])




for i in range(2):
for j in range(2):
pl.plot(tmp[0][i,j,0,:50],tmp[0][i,j,1,:50])
pl.scatter(tmp[0][0,0,0,int(np.mean(rt[0])/10)],tmp[0][0,0,1,int(np.mean(rt[0])/10)])
pl.scatter(tmp[0][0,1,0,int(np.mean(rt[1])/10)],tmp[0][0,1,1,int(np.mean(rt[1])/10)])
pl.scatter(tmp[0][1,0,0,int(np.mean(rt[2])/10)],tmp[0][1,0,1,int(np.mean(rt[2])/10)])
pl.scatter(tmp[0][1,1,0,int(np.mean(rt[3])/10)],tmp[0][1,1,1,int(np.mean(rt[3])/10)])
pl.savefig("reg_dyn_2D_net11.eps")



pl.subplot(2,1,1)
pl.plot(range(50),tmp[0][:,0,0,:50].T)
pl.plot(range(50),tmp[0][:,1,0,:50].T)
pl.subplot(2,1,2)
pl.plot(range(50),tmp[0][:,0,1,:50].T)
pl.plot(range(50),tmp[0][:,1,1,:50].T)
pl.savefig("reg_dyn_net11.eps")


#regression figure after ver14
inet=11
prj,prj_pop=rg.main([rate,beh04[inet-1][:,:2],inet,"_"],["evk","evk",True,False,False])
pl.subplot(2,1,1)
pl.plot(range(50),prj[:,0,0,:50].T)
pl.plot(range(50),prj[:,1,0,:50].T)
pl.scatter([10],prj[0,0,0,10])
pl.scatter([10],prj[1,0,0,10])
pl.scatter([10],prj[0,1,0,10])
pl.scatter([10],prj[1,1,0,10])
RT=np.mean(beh04[inet-1][0][2][beh04[inet-1][0][0]])/10
pl.scatter([int(RT)],prj[0,0,0,int(RT)])
RT=np.mean(beh04[inet-1][0][2][beh04[inet-1][0][1]])/10
pl.scatter([int(RT)],prj[0,1,0,int(RT)])
RT=np.mean(beh04[inet-1][6][2][beh04[inet-1][6][0]])/10
pl.scatter([int(RT)],prj[1,0,0,int(RT)])
RT=np.mean(beh04[inet-1][6][2][beh04[inet-1][6][1]])/10
pl.scatter([int(RT)],prj[1,1,0,int(RT)])
pl.subplot(2,1,2)
pl.plot(range(50),prj[:,0,1,:50].T)
pl.plot(range(50),prj[:,1,1,:50].T)
pl.scatter([10],prj[0,0,1,10])
pl.scatter([10],prj[1,0,1,10])
pl.scatter([10],prj[0,1,1,10])
pl.scatter([10],prj[1,1,1,10])
RT=np.mean(beh04[inet-1][0][2][beh04[inet-1][0][0]])/10
pl.scatter([int(RT)],prj[0,0,1,int(RT)])
RT=np.mean(beh04[inet-1][0][2][beh04[inet-1][0][1]])/10
pl.scatter([int(RT)],prj[0,1,1,int(RT)])
RT=np.mean(beh04[inet-1][6][2][beh04[inet-1][6][0]])/10
pl.scatter([int(RT)],prj[1,0,1,int(RT)])
RT=np.mean(beh04[inet-1][6][2][beh04[inet-1][6][1]])/10
pl.scatter([int(RT)],prj[1,1,1,int(RT)])
pl.savefig("reg_dyn_time_net11_ver14.eps")




# roubustness analysis
dt=300
for i in range(20):
for j in range(50):
if len(trj[i][31*j][:,1])-100<dt:
x1=trj[i][31*j][-1,1]
y1=trj[i][31*j][-1,2]
else:
x1=trj[i][31*j][100+dt-1,1]
y1=trj[i][31*j][100+dt-1,2]
for k in range(30):
if len(trj[i][31*j+k+1][:,1])<dt:
x2=trj[i][31*j+k+1][-1,1]
y2=trj[i][31*j+k+1][-1,2]
else:
x2=trj[i][31*j+k+1][dt-1,1]
y2=trj[i][31*j+k+1][dt-1,2]
dx=x1-x2
dy=y1-y2
dst[i,j,k]=np.sqrt(dx*dx+dy*dy)
pl.scatter(np.median(np.mean(dst,axis=2),axis=1),paras[np.array(suc_list)-1,2])
pl.savefig("robust_beh_models.eps")
 (0.55717159734783772, 0.010707861427780739)

# histgram of susceptibility
trjt100_many=[]
tmp=fp.get_behav1(["pert_tmp","spn","t100","get_trj"],[11,-1,0.4,0.9,0.02,31*100,0.05,0.1])
trjt100_many.append(tmp[5])
tmp=fp.get_behav1(["pert_tmp","spn","t100","get_trj"],[26,-1,0.4,0.9,0.02,31*100,0.05,0.1])
trjt100_many.append(tmp[5])

dt=300
baset=100
trjtmp=trjt100_many
dstt100_many=np.zeros((2,100,30))
for i in range(2):
for j in range(100):
if len(trjtmp[i][31*j][:,1])-baset<dt:
x1=trjtmp[i][31*j][-1,1]
y1=trjtmp[i][31*j][-1,2]
else:
x1=trjtmp[i][31*j][baset+dt-1,1]
y1=trjtmp[i][31*j][baset+dt-1,2]
for k in range(30):
if len(trjtmp[i][31*j+k+1][:,1])<dt:
x2=trjtmp[i][31*j+k+1][-1,1]
y2=trjtmp[i][31*j+k+1][-1,2]
else:
x2=trjtmp[i][31*j+k+1][dt-1,1]
y2=trjtmp[i][31*j+k+1][dt-1,2]
dx=x1-x2
dy=y1-y2
dstt100_many[i,j,k]=np.sqrt(dx*dx+dy*dy)

pl.subplot(2,1,1)
pl.hist(np.mean(dstt100_many[0],axis=1),range=(0,0.1))
pl.subplot(2,1,2)
pl.hist(np.mean(dstt100_many[1],axis=1),range=(0,0.1))
pl.savefig("hist_comp_susc.eps")


    # familir correlation
    pl.scatter(np.mean(np.median(dstevk0t100,axis=2),axis=1)+np.mean(np.median(dstevk6t100,axis=2),axis=1),paras[np.array(suc_list)-1,2])
    
    

tmp=fp.get_behav1(["normal","_","t","get_trj"],[11,0,0.4,0.9,0.02,31*50,0.05])
trj11FH=tmp[5]
tmp=fp.get_behav1(["normal","_","t","get_trj"],[11,0.1,0.4,0.9,0.02,31*50,0.05])
trj11N1=tmp[5]
tmp=fp.get_behav1(["normal","_","t","get_trj"],[11,0.2,0.4,0.9,0.02,31*50,0.05])
trj11N2=tmp[5]
tmp=fp.get_behav1(["normal","_","t","get_trj"],[11,0.3,0.4,0.9,0.02,31*50,0.05])
trj11N3=tmp[5]
tmp=fp.get_behav1(["normal","_","t","get_trj"],[11,0.4,0.4,0.9,0.02,31*50,0.05])
trj11N4=tmp[5]
tmp=fp.get_behav1(["normal","_","t","get_trj"],[11,0.5,0.4,0.9,0.02,31*50,0.05])
trj11N5=tmp[5]
tmp=fp.get_behav1(["normal","_","t","get_trj"],[11,0.6,0.4,0.9,0.02,31*50,0.05])
trj11FL=tmp[5]
tmp=fp.get_behav1(["pert_tmp","_","t","get_trj"],[11,-1,0.4,0.9,0.02,31*50,0.05,0.1])
trj11spn=tmp[5]


np.argsort(np.mean(dst[6],axis=1))[-10:]=46, 12,  3, 39, 15, 10, 35, 36, 14, 43
0.04464182,  0.04652459,  0.04663639,  0.04911874,  0.05018554,
0.05394226,  0.05685652,  0.05757095,  0.05823024,  0.06260836

iinit=35
tmp=np.zeros((38,600,2))
tmp[0,:,0]=flt.gaussian_filter(trj11FH[iinit][:600,1],2)
tmp[0,:,1]=flt.gaussian_filter(trj11FH[iinit][:600,2],2)
tmp[1,:,0]=flt.gaussian_filter(trj11N1[iinit][:600,1],2)
tmp[1,:,1]=flt.gaussian_filter(trj11N1[iinit][:600,2],2)
tmp[2,:,0]=flt.gaussian_filter(trj11N2[iinit][:600,1],2)
tmp[2,:,1]=flt.gaussian_filter(trj11N2[iinit][:600,2],2)
tmp[3,:,0]=flt.gaussian_filter(trj11N3[iinit][:600,1],2)
tmp[3,:,1]=flt.gaussian_filter(trj11N3[iinit][:600,2],2)
tmp[4,:,0]=flt.gaussian_filter(trj11N4[iinit][:600,1],2)
tmp[4,:,1]=flt.gaussian_filter(trj11N4[iinit][:600,2],2)
tmp[5,:,0]=flt.gaussian_filter(trj11N5[iinit][:600,1],2)
tmp[5,:,1]=flt.gaussian_filter(trj11N5[iinit][:600,2],2)
tmp[6,:,0]=flt.gaussian_filter(trj11FL[iinit][:600,1],2)
tmp[6,:,1]=flt.gaussian_filter(trj11FL[iinit][:600,2],2)
for i in range(1,31):
tmp[i+7,100:300,0]=flt.gaussian_filter(trj11spn[iinit*31+i][:200,1],2)
tmp[i+7,100:300,1]=flt.gaussian_filter(trj11spn[iinit*31+i][:200,2],2)


cset=["cyan","b","green","yellow","orange","pink","r"]
for i in range(7):
pl.plot(tmp[i,:500,0],tmp[i,:500,1],c=cset[i])
for i in range(1,31):
pl.plot(tmp[7+i,100:300,0],tmp[7+i,100:300,1],c="gray",alpha=0.4)
pl.savefig("outdyn_lowstb.eps")






np.argsort(np.mean(dst[18],axis=1))[:10]=47,  5, 29, 24, 42,  2,  4, 31, 27, 49
0.00444408,  0.00784641,  0.00922292,  0.012259  ,  0.01377998,
0.01390875,  0.01448703,  0.01477864,  0.01512109,  0.01643742])

tmp=fp.get_behav1(["normal","_","t","get_trj"],[26,0,0.4,0.9,0.02,31*50,0.05])
trj26FH=tmp[5]
tmp=fp.get_behav1(["normal","_","t","get_trj"],[26,0.1,0.4,0.9,0.02,31*50,0.05])
trj26N1=tmp[5]
tmp=fp.get_behav1(["normal","_","t","get_trj"],[26,0.2,0.4,0.9,0.02,31*50,0.05])
trj26N2=tmp[5]
tmp=fp.get_behav1(["normal","_","t","get_trj"],[26,0.3,0.4,0.9,0.02,31*50,0.05])
trj26N3=tmp[5]
tmp=fp.get_behav1(["normal","_","t","get_trj"],[26,0.4,0.4,0.9,0.02,31*50,0.05])
trj26N4=tmp[5]
tmp=fp.get_behav1(["normal","_","t","get_trj"],[26,0.5,0.4,0.9,0.02,31*50,0.05])
trj26N5=tmp[5]
tmp=fp.get_behav1(["normal","_","t","get_trj"],[26,0.6,0.4,0.9,0.02,31*50,0.05])
trj26FL=tmp[5]
tmp=fp.get_behav1(["pert_tmp","_","t","get_trj"],[26,-1,0.4,0.9,0.02,31*50,0.05,0.1])
trj26spn=tmp[5]


iinit=27
tmp=np.zeros((38,600,2))
tmp[0,:,0]=flt.gaussian_filter(trj26FH[iinit][:600,1],2)
tmp[0,:,1]=flt.gaussian_filter(trj26FH[iinit][:600,2],2)
tmp[1,:,0]=flt.gaussian_filter(trj26N1[iinit][:600,1],2)
tmp[1,:,1]=flt.gaussian_filter(trj26N1[iinit][:600,2],2)
tmp[2,:,0]=flt.gaussian_filter(trj26N2[iinit][:600,1],2)
tmp[2,:,1]=flt.gaussian_filter(trj26N2[iinit][:600,2],2)
tmp[3,:,0]=flt.gaussian_filter(trj26N3[iinit][:600,1],2)
tmp[3,:,1]=flt.gaussian_filter(trj26N3[iinit][:600,2],2)
tmp[4,:,0]=flt.gaussian_filter(trj26N4[iinit][:600,1],2)
tmp[4,:,1]=flt.gaussian_filter(trj26N4[iinit][:600,2],2)
tmp[5,:,0]=flt.gaussian_filter(trj26N5[iinit][:600,1],2)
tmp[5,:,1]=flt.gaussian_filter(trj26N5[iinit][:600,2],2)
tmp[6,:,0]=flt.gaussian_filter(trj26FL[iinit][:600,1],2)
tmp[6,:,1]=flt.gaussian_filter(trj26FL[iinit][:600,2],2)
for i in range(1,31):
tmp[i+7,100:300,0]=flt.gaussian_filter(trj26spn[iinit*31+i][:200,1],2)
tmp[i+7,100:300,1]=flt.gaussian_filter(trj26spn[iinit*31+i][:200,2],2)

cset=["cyan","b","green","yellow","orange","pink","r"]
for i in range(7):
pl.plot(tmp[i,:500,0],tmp[i,:500,1],c=cset[i])
for i in range(1,31):
pl.plot(tmp[7+i,100:290,0],tmp[7+i,100:290,1],c="gray",alpha=0.4)
pl.savefig("outdyn_highstb.eps")



for i in range(31*35+1,31*36):
pl.plot(trjevk0t100[6][i][:400,1],trjevk0t100[6][i][:400,2],c="gray")
pl.plot(trjevk0t100[6][31*35][:400,1],trjevk0t100[6][31*35][:400,2])
pl.xlim(0,0.1)
pl.ylim(0,0.1)
pl.savefig("pert_dyn_inet11_ipat0.eps")


for i in range(31*27+1,31*28):
pl.plot(trjevk0t100[18][i][:400,1],trjevk0t100[18][i][:400,2],c="gray")
pl.plot(trjevk0t100[18][31*27][:400,1],trjevk0t100[18][31*27][:400,2])
pl.xlim(0,0.1)
pl.ylim(0,0.1)
pl.savefig("pert_dyn_inet26_ipat0.eps")


   ### suc and difference in nov traj.
   
   tmp=fp.get_behav1(["many","_","t","get_trj"],[11,0,0.4,0.9,0.02,31*50,0.05])
   trj11FH=tmp[5]
   tmp=fp.get_behav1(["many","_","t","get_trj"],[11,0.1,0.4,0.9,0.02,31*50,0.05])
   trj11N1=tmp[5]
   tmp=fp.get_behav1(["many","_","t","get_trj"],[11,0.2,0.4,0.9,0.02,31*50,0.05])
   trj11N2=tmp[5]
   tmp=fp.get_behav1(["many","_","t","get_trj"],[11,0.3,0.4,0.9,0.02,31*50,0.05])
   trj11N3=tmp[5]
   tmp=fp.get_behav1(["many","_","t","get_trj"],[11,0.4,0.4,0.9,0.02,31*50,0.05])
   trj11N4=tmp[5]
   tmp=fp.get_behav1(["many","_","t","get_trj"],[11,0.5,0.4,0.9,0.02,31*50,0.05])
   trj11N5=tmp[5]
   tmp=fp.get_behav1(["many","_","t","get_trj"],[11,0.6,0.4,0.9,0.02,31*50,0.05])
   

tmp=fp.get_behav1(["many","_","t","get_trj"],[26,0,0.4,0.9,0.02,31*50,0.05])
trj26FH=tmp[5]
tmp=fp.get_behav1(["many","_","t","get_trj"],[26,0.1,0.4,0.9,0.02,31*50,0.05])
trj26N1=tmp[5]
tmp=fp.get_behav1(["many","_","t","get_trj"],[26,0.2,0.4,0.9,0.02,31*50,0.05])
trj26N2=tmp[5]
tmp=fp.get_behav1(["many","_","t","get_trj"],[26,0.3,0.4,0.9,0.02,31*50,0.05])
trj26N3=tmp[5]
tmp=fp.get_behav1(["many","_","t","get_trj"],[26,0.4,0.4,0.9,0.02,31*50,0.05])
trj26N4=tmp[5]
tmp=fp.get_behav1(["many","_","t","get_trj"],[26,0.5,0.4,0.9,0.02,31*50,0.05])
trj26N5=tmp[5]
tmp=fp.get_behav1(["many","_","t","get_trj"],[26,0.6,0.4,0.9,0.02,31*50,0.05])
trj26FL=tmp[5]


dt=300
baset=100
dstt100_nov=np.zeros((2,100,7,7))
for j in range(100):
tmptrj=np.zeros((7,2))
tmptrj[0]=trj11FH[j][baset+dt-1,1:]
tmptrj[1]=trj11N1[j][baset+dt-1,1:]
tmptrj[2]=trj11N2[j][baset+dt-1,1:]
tmptrj[3]=trj11N3[j][baset+dt-1,1:]
tmptrj[4]=trj11N4[j][baset+dt-1,1:]
tmptrj[5]=trj11N5[j][baset+dt-1,1:]
tmptrj[6]=trj11FL[j][baset+dt-1,1:]
for i in range(7):
for k in range(7):
dx=tmptrj[i,0]-tmptrj[k,0]
dy=tmptrj[i,1]-tmptrj[k,1]
dstt100_nov[0,j,i,k]=np.sqrt(dx*dx+dy*dy)
for j in range(100):
tmptrj=np.zeros((7,2))
tmptrj[0]=trj26FH[j][baset+dt-1,1:]
tmptrj[1]=trj26N1[j][baset+dt-1,1:]
tmptrj[2]=trj26N2[j][baset+dt-1,1:]
tmptrj[3]=trj26N3[j][baset+dt-1,1:]
tmptrj[4]=trj26N4[j][baset+dt-1,1:]
tmptrj[5]=trj26N5[j][baset+dt-1,1:]
tmptrj[6]=trj26FL[j][baset+dt-1,1:]
for i in range(7):
for k in range(7):
dx=tmptrj[i,0]-tmptrj[k,0]
dy=tmptrj[i,1]-tmptrj[k,1]
dstt100_nov[1,j,i,k]=np.sqrt(dx*dx+dy*dy)

mean_dist=np.zeros((2,100))
for i in range(100):
for j in range(1,6):
for k in range(j+1,6):
mean_dist[0,i]+=dstt100_nov[0,i,j,k]
mean_dist[1,i]+=dstt100_nov[1,i,j,k]

stats.pearsonr(np.mean(dstt100_many[1][:],axis=1),mean_dist[1,:])
stats.pearsonr(np.mean(dstt100_many[0][:],axis=1),mean_dist[0,:])
Out[1480]: (0.30082311233084691, 0.0023565120325906579)

stats.pearsonr(np.mean(dstt100_many[1][:],axis=1),mean_dist[1,:])

Out[1481]: (0.16731243027467416, 0.096144521002172564)

pl.scatter(np.mean(dstt100_many[0][:],axis=1),mean_dist[0,:])
pl.scatter(np.mean(dstt100_many[1][:],axis=1),mean_dist[1,:],c="r")
pl.savefig("sus_nov.eps")
"""

#### analysis of dynamics
"""
# generate distance as checking sensitivity
t_terminated=[]
for i in range(20):
inet=suc_list[i]
tmp=fp.get_behav1(["pert_tmp","_","t100",False],[inet,-1,0.4,0.9,0.02,50*31,0.095,0.1])
t_terminated.append(tmp[3])

pca_pert=[]
for inet in suc_list:
tmp=np.load("pca_pert1_%d.npy" %inet)
pca_pert.append(tmp)

dist2=np.zeros((20,50,101))
for inet in range(20):
pca_adp=np.zeros((31*50,20))
for j in range(31*50):
t_max=int(t_terminated[inet][j]/10)
if t_max>100:
t_max=100
pca_adp[j]=pca_pert[inet][j,t_max]
scl_pca=np.max(pca_adp,axis=0)-np.min(pca_adp,axis=0)
for j in range(50):
for t in range(100):
pca_adp=np.zeros((31,20))
for i in range(31):
if t<int(t_terminated[inet][31*j+i]/10):
pca_adp[i]=pca_pert[inet][j*31+i,t,:]
else:
pca_adp[i]=pca_pert[inet][j*31+i,int(t_terminated[inet][31*j+i]/10),:]
center_place=np.mean(pca_adp,axis=0)
dx2=0
for i in range(31):
tmpdist=np.sum((pca_adp[i,:5]-center_place[:5])*(pca_adp[i,:5]-center_place[:5]))
dx2+=np.sqrt(tmpdist)
dist2[inet,j,t]=dx2/(31*np.sum(scl_pca[:5]*scl_pca[:5]))


# dot chart
inet=7
tmp_sum=np.zeros((50,7))
for j in range(50):
for i in range(7):
if j in beh04[inet-1][i][0]:
tmp_sum[j,i]=1
elif j in beh04[inet-1][i][1]:
tmp_sum[j,i]=0
else:  in some cases, this condition is neglected
tmp_sum[j,i]=0.5
tmpord=np.argsort(np.mean(tmp_sum,axis=1))
for j in range(50):
pl.scatter(np.ones(7)*j,range(7),c=tmp_sum[tmpord[j]],linewidth=0,s=40,vmin=0,vmax=1)
pl.plot(range(50),np.sum(tmp_sum[tmpord],axis=1))
pl.savefig("dotchart_inet%d.eps" % inet)

inet_suc=suc_list.index(inet)
sum_unfam=range(1,8)
tmp_ave=np.zeros(len(sum_unfam))
cnt=np.zeros(len(sum_unfam))
cset_tmp=["r","pink","magenta","orange","y","g","c","b"]
for i in range(50):
for j in range(7):
if np.sum(tmp_sum[tmpord[i]])==sum_unfam[j]:
pl.scatter([i],dist2[inet_suc,tmpord[i],60],c=cset_tmp[j],lw=0)
tmp_ave[j]+=dist2[inet_suc,tmpord[i],60]
cnt[j]+=1
break
tmp_xlabel=[(cnt[0]-1)/2.0]
for i in range(1,len(sum_unfam)):
tmp_xlabel.append((cnt[i]-1)/2.0+np.sum(cnt[:i]))
pl.scatter(tmp_xlabel,tmp_ave/cnt,s=50,marker="+",c=cset_tmp)
pl.xlim(-3,53)
pl.ylim(0,0.02)
pl.savefig("id_sus-inet%d.eps" % inet)


# func=a+b*x

inet_suc=suc_list.index(inet)
pl.scatter(np.fabs(3.5-np.sum(tmp_sum,axis=1)),dist2[inet_suc,:,60])
func_para,_=optimization.curve_fit(func, np.fabs(3.5-np.sum(tmp_sum,axis=1)), dist2[inet_suc,:,60], [0.0,0.0])
pl.plot(np.arange(0.1,3.9,0.1),func(np.arange(0.1,3.9,0.1),func_para[0],func_para[1]))
pl.xlim(0,4)
pl.ylim(0,0.02)
pl.savefig("div_unfam_sus-inet%d.eps" % inet)
inet=7
(-0.58455570406637269, 8.2967060927717421e-06)
inet=20
-0.63158992102256739, 8.7294445511588379e-07
inet=3
-0.53886544081795384, 5.408546574489642e-05


pca_sens_rat.eps
-rw-r--r--  1 kurikawa  staff    17K  3  7 18:43 pval_pca_dyn_sens.eps
-rw-r--r--  1 kurikawa  staff    14K  3  7 18:37 PC_spectrum_inet7_20.eps


## the following is inet=7
## when inet=20, init=46 and 6 are used.

inet_suc=suc_list.index(inet)
fig=pl.figure()
ax1=fig.add_subplot(2,3,1)

init=18
for i in range(init*31+1,init*31+10):
ax1.plot(pca_pert[inet_suc][i,:int(t_terminated[inet_suc][i]/10),0],pca_pert[inet_suc][i,:int(t_terminated[inet_suc][i]/10),1],c="gray")
ax1.scatter(pca_pert[inet_suc][i,10,0],pca_pert[inet_suc][i,10,1],c="gray",zorder=6)
ax1.scatter(pca_pert[inet_suc][i,min(100,int(t_terminated[inet_suc][i]/10)),0],pca_pert[inet_suc][i,min(100,int(t_terminated[inet_suc][i]/10)),1],s=40,lw=5,marker="+",c="gray",zorder=6)
i=init*31
ax1.plot(pca_pert[inet_suc][i,:int(t_terminated[inet_suc][i]/10),0],pca_pert[inet_suc][i,:int(t_terminated[inet_suc][i]/10),1],c="k",lw=3)
ax1.scatter(pca_pert[inet_suc][i,10,0],pca_pert[inet_suc][i,10,1],c="k",zorder=6)
ax1.scatter(pca_pert[inet_suc][i,min(100,int(t_terminated[inet_suc][i]/10)),0],pca_pert[inet_suc][i,min(100,int(t_terminated[inet_suc][i]/10)),1],s=40,lw=5,marker="+",c="k",zorder=6)
ax1.set_xlim(-4,14)
ax1.set_ylim(-2.5,1)

ax2=fig.add_subplot(2,3,2)
for ipat in range(7):
ax2.plot(pca_dyn[inet_suc][ipat,init,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),0],pca_dyn[inet_suc][ipat,init,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),1],c=cset[ipat])
ax2.scatter(pca_dyn[inet_suc][ipat,init,10,0],pca_dyn[inet_suc][ipat,init,10,1],c=cset[ipat],zorder=6)
ax2.scatter(pca_dyn[inet_suc][ipat,init,min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),0],pca_dyn[inet_suc][ipat,init,min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),1],marker="+",lw=5,s=40,c=cset[ipat],zorder=6)
ax2.set_xlim(-4,14)
ax2.set_ylim(-8,6)

ax5=fig.add_subplot(2,3,3)
for ipat in range(7):
ax5.plot(pca_dyn[inet_suc][ipat,init,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),0],pca_dyn[inet_suc][ipat,init,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),1],c=cset[ipat])
ax5.scatter(pca_dyn[inet_suc][ipat,init,10,0],pca_dyn[inet_suc][ipat,init,10,1],c=cset[ipat],zorder=6)
ax5.scatter(pca_dyn[inet_suc][ipat,init,min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),0],pca_dyn[inet_suc][ipat,init,min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),1],marker="+",lw=5,s=40,c=cset[ipat],zorder=6)
ax5.set_xlim([-2.2,2])
ax5.set_ylim([-6,6])


ax3=fig.add_subplot(2,3,4)
init=42
for i in range(init*31+1,init*31+15):
ax3.plot(pca_pert[inet_suc][i,:int(t_terminated[inet_suc][i]/10),0],pca_pert[inet_suc][i,:int(t_terminated[inet_suc][i]/10),1],c="gray")
ax3.scatter(pca_pert[inet_suc][i,10,0],pca_pert[inet_suc][i,10,1],c="gray",zorder=6)
ax3.scatter(pca_pert[inet_suc][i,min(100,int(t_terminated[inet_suc][i]/10)),0],pca_pert[inet_suc][i,min(100,int(t_terminated[inet_suc][i]/10)),1],s=40,lw=5,marker="+",c="gray",zorder=6)
i=init*31
ax3.plot(pca_pert[inet_suc][i,:int(t_terminated[inet_suc][i]/10),0],pca_pert[inet_suc][i,:int(t_terminated[inet_suc][i]/10),1],c="k",lw=3)
ax3.scatter(pca_pert[inet_suc][i,10,0],pca_pert[inet_suc][i,10,1],c="k",zorder=6)
ax3.scatter(pca_pert[inet_suc][i,min(100,int(t_terminated[inet_suc][i]/10)),0],pca_pert[inet_suc][i,min(100,int(t_terminated[inet_suc][i]/10)),1],s=40,lw=5,marker="+",c="k",zorder=6)
ax3.set_xlim(-4,14)
ax3.set_ylim(-2.5,1)

ax4=fig.add_subplot(2,3,5)
for ipat in range(7):
ax4.plot(pca_dyn[inet_suc][ipat,init,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),0],pca_dyn[inet_suc][ipat,init,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),1],c=cset[ipat])
ax4.scatter(pca_dyn[inet_suc][ipat,init,10,0],pca_dyn[inet_suc][ipat,init,10,1],c=cset[ipat],zorder=6)
ax4.scatter(pca_dyn[inet_suc][ipat,init,min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),0],pca_dyn[inet_suc][ipat,init,min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),1],marker="+",lw=5,s=40,c=cset[ipat],zorder=6)
ax4.set_xlim(-4,14)
ax4.set_ylim(-8,6)

ax6=fig.add_subplot(2,3,6)
for ipat in range(7):
ax6.plot(pca_dyn[inet_suc][ipat,init,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),0],pca_dyn[inet_suc][ipat,init,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),1],c=cset[ipat])
ax6.scatter(pca_dyn[inet_suc][ipat,init,10,0],pca_dyn[inet_suc][ipat,init,10,1],c=cset[ipat],zorder=6)
ax6.scatter(pca_dyn[inet_suc][ipat,init,min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),0],pca_dyn[inet_suc][ipat,init,min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),1],marker="+",lw=5,s=40,c=cset[ipat],zorder=6)
ax6.set_xlim([-3,2.2])
ax6.set_ylim([-6,6])

fig.savefig("pca_dyn_all-inet_suc%d.eps" % inet)

"""


#New figures for Fig5 ver20
"""
    pca_pert7[:1550]=np.load("pca_pert1_%d.npy" %7)
    pca_pert7[1550:]=np.load("pca_pert1_%d_add.npy" %7)
    pca_pert20[:1550]=np.load("pca_pert1_%d.npy" %20)
    pca_pert20[1550:]=np.load("pca_pert1_%d_add.npy" %20)
    
    
    
ax1=fig.add_subplot(2,2,1)
init=18
inet_suc=0
for i in range(init*31+1,init*31+10):
ax1.plot(pca_pert7[i,:int(t_terminated[inet_suc][i]/10),0],pca_pert7[i,:int(t_terminated[inet_suc][i]/10),1],c="gray")
ax1.scatter(pca_pert7[i,10,0],pca_pert7[i,10,1],c="gray",zorder=6)
ax1.scatter(pca_pert7[i,min(100,int(t_terminated[inet_suc][i]/10)),0],pca_pert7[i,min(100,int(t_terminated[inet_suc][i]/10)),1],s=40,lw=1,marker="+",c="gray",zorder=6)
i=init*31
ax1.plot(pca_pert7[i,:int(t_terminated[inet_suc][i]/10),0],pca_pert7[i,:int(t_terminated[inet_suc][i]/10),1],c="k",lw=3)
ax1.scatter(pca_pert7[i,10,0],pca_pert7[i,10,1],c="k",zorder=6)
ax1.scatter(pca_pert7[i,min(100,int(t_terminated[inet_suc][i]/10)),0],pca_pert7[i,min(100,int(t_terminated[inet_suc][i]/10)),1],s=40,lw=1,marker="+",c="k",zorder=6)

ipat=0
ax1.plot(pca_dyn7[ipat,i,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),0],pca_dyn7[ipat,i,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),1],c=cset[ipat])
ipat=1
ax1.plot(pca_dyn7[ipat,i,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),0],pca_dyn7[ipat,i,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),1],c=cset[ipat])
ax1.set_xlim(-4,14)
ax1.set_ylim(-8,6)

 ax2=fig.add_subplot(2,2,1)
init=6
inet_suc=0
for i in range(init*31+1,init*31+10):
 ax2.plot(pca_pert20[i,:int(t_terminated[inet_suc][i]/10),0],pca_pert20[i,:int(t_terminated[inet_suc][i]/10),1],c="gray")
 ax2.scatter(pca_pert20[i,10,0],pca_pert20[i,10,1],c="gray",zorder=6)
 ax2.scatter(pca_pert20[i,min(100,int(t_terminated[inet_suc][i]/10)),0],pca_pert20[i,min(100,int(t_terminated[inet_suc][i]/10)),1],s=40,lw=1,marker="+",c="gray",zorder=6)
i=init*31
 ax2.plot(pca_pert20[i,:int(t_terminated[inet_suc][i]/10),0],pca_pert20[i,:int(t_terminated[inet_suc][i]/10),1],c="k",lw=3)
 ax2.scatter(pca_pert20[i,10,0],pca_pert20[i,10,1],c="k",zorder=6)
 ax2.scatter(pca_pert20[i,min(100,int(t_terminated[inet_suc][i]/10)),0],pca_pert20[i,min(100,int(t_terminated[inet_suc][i]/10)),1],s=40,lw=1,marker="+",c="k",zorder=6)

ipat=0
 ax2.plot(pca_dyn20[ipat,i,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),0],pca_dyn20[ipat,i,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),1],c=cset[ipat])
ipat=1
 ax2.plot(pca_dyn20[ipat,i,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),0],pca_dyn20[ipat,i,:min(100,int(t_terminated_evk[inet_suc][ipat][init]/10)),1],c=cset[ipat])
 ax2.set_xlim(-4,14)
 ax2.set_ylim(-8,6)





pl.subplot(1,2,1)
pl.hist(dist2[4,:,60],bins=10,range=(0,0.02))
pl.subplot(1,2,2)
pl.hist(dist2[13,:,60],bins=10,range=(0,0.02))
pl.savefig("hist_dist_inet7_20.eps")



pl.scatter(np.mean(dist2[:,:,60],axis=1),paras[:,2])
func_para,_=optimization.curve_fit(func,np.mean(dist2[:,:,60],axis=1),paras[:,2], [0.0,0.0])
pl.plot(np.arange(0.005,0.014,0.001),func(np.arange(0.005,0.014,0.001),func_para[0],func_para[1]))
pl.xlim(0,0.015)
pl.ylim(-0.01,0.35)
pl.savefig("scatter_dist_kai.eps")

stats.pearsonr(np.mean(dist2[:,:,60],axis=1),paras)
Out[894]: (0.62374961252339256, 0.0032941763747092244)  <- this is from normalized parameters

stats.pearsonr(np.mean(dist2[:,:,60],axis=1),paras[:,2])
Out[1568]: (0.58175009611079154, 0.0071294884093984299)  <- this is from raw parameters
func_para
Out[1569]: array([ -0.02864441,  24.33268963])




# for evoked and perturbed trajectories
dist_evk=np.zeros((2,20,50,101))
for inet in range(20):
pca_adp=np.zeros((2,31*50,20))
for j in range(31*50):
t_max=min(100,int(t_terminated_pertevk[inet][0][j]/10))
pca_adp[0,j]=pca_pert_evk[inet][0][j,t_max]
t_max=min(100,int(t_terminated_pertevk[inet][1][j]/10))
pca_adp[1,j]=pca_pert_evk[inet][1][j,t_max]
scl_pca=np.max(pca_adp,axis=(0,1))-np.min(pca_adp,axis=(0,1))

for j in range(50):
for t in range(100):
pca_adp=np.zeros((2,31,20))
for i in range(31):
for k in range(2):
if t<int(t_terminated_pertevk[inet][k][31*j+i]/10):
pca_adp[k,i]=pca_pert_evk[inet][k][j*31+i,t,:]
else:
pca_adp[k,i]=pca_pert_evk[inet][k][j*31+i,int(t_terminated_pertevk[inet][k][31*j+i]/10),:]
center_place=np.mean(pca_adp,axis=1)
dx2=np.zeros(2)
for i in range(31):
tmpdist=np.sum((pca_adp[:,i,:5]-center_place[:,:5])*(pca_adp[:,i,:5]-center_place[:,:5]),axis=1)
dx2+=np.sqrt(tmpdist)
dist_evk[:,inet,j,t]=dx2/(31*np.sum(scl_pca[:5]*scl_pca[:5]))


pl.subplot(2,1,1)
pl.scatter(np.mean(dist_evk[0,:,:,60],axis=1),paras[:,2])
pl.xlim(0,0.01)
pl.ylim(-0.01,0.35)
pl.subplot(2,1,2)
pl.scatter(np.mean(dist_evk[1,:,:,60],axis=1),paras[:,2])
pl.xlim(0,0.01)
pl.ylim(-0.01,0.35)
pl.savefig("scatter_dist_evk_kai.eps")



stats.pearsonr(np.mean(dist_evk[0,:,:,60],axis=1),paras[:,2])
Out[1577]: (0.30704118473860476, 0.18790822692465739)
stats.pearsonr(np.mean(dist_evk[1,:,:,60],axis=1),paras[:,2])
Out[1576]: (-0.21190775797445252, 0.36976868603152069)

# for histgram with 100 samples
for inet in [7,20]:
ipat=-1
del rate_pert
rate_pert=np.zeros((31*10,101,5000))
rate_pert[:,:,:]=fp.get_rate_all(["pert_tmp","spn","rt100_5"],[inet,ipat,0.4,0.9,0.02,31*10,0.05,0.1])
np.save("rate_pert%d_%g-5.npy" % (inet,ipat),rate_pert)
rate_pert[:,:,:]=fp.get_rate_all(["pert_tmp","spn","rt100_6"],[inet,ipat,0.4,0.9,0.02,31*10,0.05,0.1])
np.save("rate_pert%d_%g-6.npy" % (inet,ipat),rate_pert)
rate_pert[:,:,:]=fp.get_rate_all(["pert_tmp","spn","rt100_7"],[inet,ipat,0.4,0.9,0.02,31*10,0.05,0.1])
np.save("rate_pert%d_%g-7.npy" % (inet,ipat),rate_pert)
rate_pert[:,:,:]=fp.get_rate_all(["pert_tmp","spn","rt100_8"],[inet,ipat,0.4,0.9,0.02,31*10,0.05,0.1])
np.save("rate_pert%d_%g-8.npy" % (inet,ipat),rate_pert)
rate_pert[:,:,:]=fp.get_rate_all(["pert_tmp","spn","rt100_9"],[inet,ipat,0.4,0.9,0.02,31*10,0.05,0.1])
np.save("rate_pert%d_%g-9.npy" % (inet,ipat),rate_pert)


t_terminated_tmp=[]
for i in [4,13]:
inet=suc_list[i]
tmp=fp.get_behav1(["pert_tmp","_","t100_add",False],[inet,-1,0.4,0.9,0.02,31*50,0.095,0.1])
t_terminated_tmp.append(tmp[3])

for i in [0,1]:
for j in range(len(t_terminated_tmp[i])):
if t_terminated_tmp[i][j]<0.1:
t_terminated_tmp[i][j]=1100.0


dist2_tmp=np.zeros((2,50,101))
for inet in [0,1]: # corresponding to inet7 and 20
pca_adp=np.zeros((31*50,20))
for j in range(31*50):
t_max=min(100,int(t_terminated_tmp[inet][j]/10))
pca_adp[j]=pca_pert_add[inet][j,t_max]
scl_pca=np.max(pca_adp,axis=0)-np.min(pca_adp,axis=0)
for j in range(50):
for t in range(100):
pca_adp=np.zeros((31,20))
for i in range(31):
if t<int(t_terminated_tmp[inet][31*j+i]/10):
pca_adp[i]=pca_pert_add[inet][j*31+i,t,:]
else:
pca_adp[i]=pca_pert_add[inet][j*31+i,int(t_terminated_tmp[inet][31*j+i]/10),:]
center_place=np.mean(pca_adp,axis=0)
dx2=0
for i in range(31):
tmpdist=np.sum((pca_adp[i,:5]-center_place[:5])*(pca_adp[i,:5]-center_place[:5]))
dx2+=np.sqrt(tmpdist)
dist2_tmp[inet,j,t]=dx2/(31*np.sum(scl_pca[:5]*scl_pca[:5]))

"""
# variance analysis
"""
    pccurve0,pccurve01=fp.calc_expansion_pop1(0.04,0.1)  (only non-receiving neurons are used)
    
    cr=np.zeros(20)
    for inet in range(20):
    nozero=[itmp for itmp in range(100) if pccurve01[inet,0,itmp,4,0]>0]
    print len(nozero)
    tmp=np.mean(np.mean(np.log(pccurve01[inet,:,nozero,4,1:]),axis=1),axis=1)
    cr[inet]=np.mean(tmp/np.mean(np.log(pccurve01[inet,0,nozero,4,0])))
    
    tmppara,tmpcov=optimize.curve_fit(fit_func,cr,paras)
    pl.scatter(cr,paras)
    pl.plot(np.arange(0.85,0.99,0.01),fit_func(np.arange(0.85,0.99,0.01),tmppara[0],tmppara[1]))
    pl.xlim(0.84,1.0)
    pl.savefig("var_sens_models.eps")
    
     (0.47165235384163939, 0.035777329023970038)
     
     tmppara,tmpcov=optimize.curve_fit(fit_func,np.mean(dist2[:,:,60],axis=1),cr)
     pl.scatter(np.mean(dist2[:,:,60],axis=1),cr)
     pl.plot(np.arange(0.004,0.013,0.001),fit_func(np.arange(0.004,0.013,0.001),tmppara[0],tmppara[1]))
     pl.xlim(0.003,0.015)
     pl.savefig("kai_var_change_models.eps")
     
     stats.pearsonr(np.mean(dist2[:,:,60],axis=1),cr)
     Out[946]: (0.46206566992022463, 0.040256093576221216)
    
"""



# fano factor analysis
"""
rat_list=[0,1,2,3,4,5,6,7]
ncell=8
ntbin=80
ntrial=25
trj=[]
for i in range(len(rat_list)):
    irat=rat_list[i]
    celllist=np.argsort(np.mean(data_set_rat[irat][0][:,:,0:100],axis=(1,2)))
    trj.append([])
    for ipat in range(7):
        tmplist=random.sample(data_set_rat[irat][1][ipat],ntrial)
        tmp_traj=np.zeros((ncell,ntbin,len(tmplist)))
        for j in range(ncell):
            for k in range(len(tmplist)):
                init=tmplist[k]
                tmp_traj[j,:,k]=(flt.gaussian_filter(data_set_rat[irat][0][celllist[-(j+1)],init,:],3))[10:90]
        trj[i].append(tmp_traj)

var_dyn=np.zeros((8,7,ncell,8))
for i in range(len(rat_list)):
    for j in range(8):
        for ipat in range(7):
            pcasmp=np.zeros((ncell,ntrial))
            for k in range(ncell):
                pcasmp[k]=np.mean(trj[i][ipat][k,j*10:(j+1)*10,:],axis=0)/np.mean(np.mean(trj[i][ipat][k,j*10:(j+1)*10,:],axis=0),axis=0)
            PCs=fp.PCA(pcasmp.T)
            var_dyn[i,ipat,:,j]=PCs[0]
log_var_dyn=np.zeros((8,7,8))
for i in range(len(rat_list)):
    for j in range(8):
        for ipat in range(7):
            log_var_dyn[i,ipat,j]=np.sum(np.log(var_dyn[i,ipat,:,j]))
mean_dyn=np.zeros((8,7,8))
for i in range(len(rat_list)):
    for j in range(8):
        for ipat in range(7):
            tmp=np.mean(trj[i][ipat][:,j*10:(j+1)*10,:],axis=(1,2))
            mean_dyn[i,ipat,j]=np.log(np.sum(tmp*tmp))
dev_multi=np.zeros((8,2))
for irat in range(len(rat_list)):
    tmp=np.zeros((7,8))
    for i in range(7):
        tmp[i]=log_var_dyn[irat,i]
    dev_multi[irat,0]=np.mean(tmp[:,:4])
    dev_multi[irat,1]=np.mean(tmp[:,4:])

print stats.pearsonr(dev_multi[:,0],paras[np.array(rat_list),2]),stats.pearsonr(dev_multi[:,1],paras[np.array(rat_list),2]),stats.pearsonr(dev_multi[:,1]/dev_multi[:,0],paras[np.array(rat_list),2])
(0.077665490073621557, 0.85496173727844615) (0.20598819032143928, 0.62455846090404488) (0.26926971388039628, 0.51899308768246166)



rat_list=[0,1,2,3,4,5,6,7]
ntbin=80
ntrial=25
trj=[]
for i in range(len(rat_list)):
irat=rat_list[i]
diff=np.zeros(len(data_set_rat[irat][0]))
for ipat in range(7):
tmplist=list(set(data_set_rat[irat][1][ipat])&set(data_set_rat[irat][2][0]))
if len(tmplist)!=0:
diff+=np.fabs(np.mean(data_set_rat[irat][0][:,tmplist,0:50],axis=(1,2))-np.mean(data_set_rat[irat][0][:,tmplist,50:100],axis=(1,2)))
tmplist=list(set(data_set_rat[irat][1][ipat])&set(data_set_rat[irat][2][1]))
if len(tmplist)!=0:
diff+=np.fabs(np.mean(data_set_rat[irat][0][:,tmplist,0:50],axis=(1,2))-np.mean(data_set_rat[irat][0][:,tmplist,50:100],axis=(1,2)))
#    celllist=np.argsort(diff)
celllist=[itmp for itmp in range(len(diff)) if diff[itmp]>3*7]
trj.append([])
ncell=len(celllist)
for ipat in range(7):
tmplist=random.sample(data_set_rat[irat][1][ipat],ntrial)
tmp_traj=np.zeros((ncell,ntbin,len(tmplist)))
for j in range(ncell):
for k in range(len(tmplist)):
init=tmplist[k]
tmp_traj[j,:,k]=(flt.gaussian_filter(data_set_rat[irat][0][celllist[-(j+1)],init,:],3))[10:90]
trj[i].append(tmp_traj)



var_dyn=[]
del_cell_list=[]
for i in range(len(rat_list)):
var_dyn.append([])
del_cell_list.append([])
ncell=len(trj[i][0])
pcasmp=np.zeros((7,3,ncell,ntrial))
for ipat in range(7):
var_dyn[i].append([])
for j in range(3):
for k in range(ncell):
if j==0:
pcasmp[ipat,j,k]=np.mean(trj[i][ipat][k,20:40,:],axis=0)/np.mean(np.mean(trj[i][ipat][k,20:40,:],axis=0),axis=0)
if np.mean(np.mean(trj[i][ipat][k,20:40,:],axis=0),axis=0)<2:
del_cell_list[i].append(k)
elif j==1:
pcasmp[ipat,j,k]=np.mean(trj[i][ipat][k,40:60,:],axis=0)/np.mean(np.mean(trj[i][ipat][k,40:60,:],axis=0),axis=0)
if np.mean(np.mean(trj[i][ipat][k,40:60,:],axis=0),axis=0)<2:
del_cell_list[i].append(k)
elif j==2:
pcasmp[ipat,j,k]=np.mean(trj[i][ipat][k,60:80,:],axis=0)/np.mean(np.mean(trj[i][ipat][k,60:80,:],axis=0),axis=0)
if np.mean(np.mean(trj[i][ipat][k,60:80,:],axis=0),axis=0)<2:
del_cell_list[i].append(k)
cell_usd_list=[itmp for itmp in range(ncell) if itmp not in del_cell_list[i]]
for ipat in range(7):
for j in range(3):
PCs=fp.PCA(pcasmp[ipat,j,cell_usd_list,:].T)
var_dyn[i][ipat].append(PCs[0])
log_var_dyn=np.zeros((len(rat_list),7,3))
for i in range(len(rat_list)):
for j in range(3):
for ipat in range(7):
log_var_dyn[i,ipat,j]=np.sum(np.log(var_dyn[i][ipat][j]))



"""

#tmp
"""
ncell=30
ntbin=50
ntrial=50
trj=[]
for i in range(20):
    inet=suc_list[i]
    rate=np.load("rate_long%d0.40.90.02.npy" % inet)
    tmpord=(np.argsort(np.mean(rate[:,:,:60,2000:],axis=(0,1,2)))).astype(int)
    trj.append([])
    for ipat in range(7):
        tmp_traj=np.zeros((ncell,ntbin,ntrial))
        for j in range(ncell):
            for init in range(ntrial):
                tmp_traj[j,:,init]=(flt.gaussian_filter(rate[ipat,init,:60,tmpord[-ncell+j]+2000],3))[0:50]
        trj[i].append(tmp_traj)

var_dyn=np.zeros((20,7,ncell,5))
for i in range(20):
    for j in range(5):
        for ipat in range(7):
            pcasmp=np.zeros((ncell,50))
            for k in range(ncell):
                pcasmp[k]=np.mean(trj[i][ipat][k,j*10:(j+1)*10,:],axis=0)/np.mean(np.mean(trj[i][ipat][k,j*10:(j+1)*10,:],axis=0),axis=0)
            PCs=fp.PCA(pcasmp.T)
            var_dyn[i,ipat,:,j]=PCs[0]
log_var_dyn=np.zeros((20,7,5))
for i in range(20):
    for j in range(5):
        for ipat in range(7):
            log_var_dyn[i,ipat,j]=np.sum(np.log(var_dyn[i,ipat,:,j]))
dev_multi=np.zeros((20,2))
for j in range(20):
    tmp=np.zeros((7,5))
    for i in range(7):
        tmp[i]=log_var_dyn[j,i]
    dev_multi[j,0]=np.mean(tmp[:,0])
    dev_multi[j,1]=np.mean(tmp[:,1:])
"""



def calc_pfm_FDA(args):
    pfm=[]
    list_L  =np.copy(args[0])
    list_R  =np.copy(args[1])
    rtime_tmp=np.copy(args[2])
    tmp_FDA    =np.copy(args[3])

    # convert to the form of rat.
    list_tone=[]
    for i in range(7):
        list_tone.append(range(i*50,(i+1)*50))
    list_LR=[[],[]]
    for i in range(7):
        for j in list_L[i]:
            list_LR[0].append(j+i*50)
        for j in list_R[i]:
            list_LR[1].append(j+i*50)

    rtime=rtime_tmp[0]
    for i in range(1,7):
        rtime=np.hstack((rtime,rtime_tmp[i]))
    
    
    tmplist=list(set(list_tone[0][:]) & set(list_LR[0]))
    tmplist1=list(set(list_tone[6][:]) & set(list_LR[0]))
    tmplistL=tmplist+tmplist1
        
    tmplist=list(set(list_tone[0][:]) & set(list_LR[1]))
    tmplist1=list(set(list_tone[6][:]) & set(list_LR[1]))
    tmplistR=tmplist+tmplist1

    smpL=tmp_FDA[tmplistL,0]
    smpR=tmp_FDA[tmplistR,0]
    theta_LR=(np.mean(smpL)+np.mean(smpR))/2.0

    print theta_LR
    
    CL=[]
    CR=[]
    FL=[]
    FR=[]
    for j in range(7):
        CL.append([])
        FL.append([])
        CR.append([])
        FR.append([])
        tmplistL=list(set(list_tone[j][:]) & set(list_LR[0]))
        tmplistR=list(set(list_tone[j][:]) & set(list_LR[1]))
        for i in tmplistL+tmplistR:
            if (tmp_FDA[i,0]-theta_LR)*(np.mean(smpL)-theta_LR)>0:
                if i in list_LR[0]:
                    CL[j].append(i)
                else:
                    FL[j].append(i)
            else:
                if i in list_LR[1]:
                    CR[j].append(i)
                else:
                    FR[j].append(i)
        
        
    pfm.append(CL)
    pfm.append(CR)
    pfm.append(FL)
    pfm.append(FR)

    return pfm





"""
def main():
    suc_list=[2,3,5,6,7,8,11,13,14,15,16,18,19,20,22,23,24,25,26,30]
    suc_list03=[1, 2, 3, 4, 6, 9, 10, 12, 13, 14, 15, 18, 19, 21, 24, 25, 27, 28]
    [2, 3, 9, 10, 11, 12, 13, 14, 16, 19, 21, 23, 24, 26, 27]
[2, 3, 5, 6, 7, 11, 12, 14, 16, 17, 20, 26, 28, 29]
"""



def FDA_anly(data1,data2):
    n_dim=len(data1)
    flg,J,W,cell_rank=fda.FDA2(data1,data2,range(n_dim),n_dim)
    
    return flg,J,W,cell_rank

def tmp_FDA(argset):
    list_L  =np.copy(argset[0])
    list_R  =np.copy(argset[1])
    rtime_tmp  =np.copy(argset[2])
    rate_tmp     =np.copy(argset[3])
    flg_tone =argset[4] # 1: discriminate high and low, 0: discriminate right and left
    t_bf_dec =argset[5]
    t_tone   =argset[6]
    
    
    # convert to the form of rat.
    ttime=len(rate_tmp[0,0])
    tmp=rate_tmp.reshape(7*50,ttime,5000)
    tmp=np.swapaxes(tmp,0,1)
    rate=np.swapaxes(tmp,0,2)

    list_tone=[]
    for i in range(7):
        list_tone.append(range(i*50,(i+1)*50))
    list_LR=[[],[]]
    for i in range(7):
        for j in list_L[i]:
            list_LR[0].append(j+i*50)
        for j in list_R[i]:
            list_LR[1].append(j+i*50)

    t_over  =1000
    stimonset=100
    rtime=rtime_tmp[0]
    for i in range(1,7):
        rtime=np.hstack((rtime,rtime_tmp[i]))
    for i in range(len(rtime)):
        if rtime[i]<=0.001:
            rtime[i]=t_over-stimonset  # modified 2016.12.26 -stimonset
        rtime[i]=rtime[i]-stimonset
        if rtime[i]<0.0:
            print "error too early response!!\n"
            return

    min_rt=np.min(rtime)
    flg_sort =0   # 1: align by time 0, 0: align by decision time
    t_offset=10
    t_end   =len(rate[0][0])-t_offset
    ncell=len(rate)
    ntrial=len(rate[0])
    tbin=10
    ndim=80
    
    for i in range(len(rate)):
        for j in range(len(rate[0])):
            rate[i,j,:]=flt.gaussian_filter(rate[i,j,:],3)
    
    # normalize rate
    tmplist=list_tone[0]+list_tone[6]
    tmpord=np.argsort(np.mean(rate[:,tmplist,:],axis=(1,2)))
    zs_rate=np.zeros((ndim,len(rate[0]),len(rate[0][0])))
    for i in range(ndim):
        itmp=tmpord[-ndim+i]
        zs_rate[i]=(rate[itmp]-np.mean(rate[itmp]))/np.std(rate[itmp])
    
    smpL=[]
    smpR=[]
    

    if flg_tone==1:
        for i in list_tone[6]:
            smpL.append(np.mean(zs_rate[:,i,t_offset+t_tone:t_offset+t_tone+tbin],axis=1))
        for i in list_tone[0]:
            smpR.append(np.mean(zs_rate[:,i,t_offset+t_tone:t_offset+t_tone+tbin],axis=1))
    else:
        for i in list(set(list_LR[0])&set(list_tone[6]))+list(set(list_LR[0])&set(list_tone[0])):
            if rtime[i]>=(t_end+t_bf_dec)*10:
                smpL.append(np.mean(zs_rate[:,i,-tbin:],axis=1))
            else:
                smpL.append(np.mean(zs_rate[:,i,rtime[i]/10+t_offset-tbin-t_bf_dec:rtime[i]/10+t_offset-t_bf_dec],axis=1))
        for i in list(set(list_LR[1])&set(list_tone[0]))+list(set(list_LR[1])&set(list_tone[6])):
            if rtime[i]>=(t_end+t_bf_dec)*10:
                smpR.append(np.mean(zs_rate[:,i,-tbin:],axis=1))
            else:
                smpR.append(np.mean(zs_rate[:,i,rtime[i]/10+t_offset-tbin-t_bf_dec:rtime[i]/10+t_offset-t_bf_dec],axis=1))
    
    smpR=np.array(smpR)[:,:]
    smpL=np.array(smpL)[:,:]

    W=FDA_anly(smpL[:,:].T,smpR[:,:].T)
    
    if W[0]==1:
        print "error!! effective dimension is too small!"
        return W[3],smpL,smpR
    """
        pl.subplot(3,4,t_bf_dec+1)
        tmpL=np.dot(smpL[:nsmp,:],np.array(W[2]))
        tmpR=np.dot(smpR[:nsmp,:],np.array(W[2]))
        
        pl.hist(tmpL,bins=50)
        pl.hist(tmpR,bins=50)
        """
    
    if flg_sort==1:
        rate_prj=np.zeros((ntrial,t_end+t_offset))
        for i in range(ntrial):
            rate_prj[i,:]=np.dot(W[2].T,zs_rate[:,i,:])
    else:
        min_t=int(np.min(rtime)/10)+t_offset
        rate_prj=np.zeros((ntrial,min_t))
            #for i in range(ntrial):
            #rate_prj[i,:]=np.dot(W[2].T,zs_rate[:,i,t_end-1+t_offset::-1])
        for i in range(len(rtime)):
            if rtime[i]>=(t_end+t_bf_dec)*10:
                rate_prj[i,:]=np.dot(W[2].T,zs_rate[:,i,t_end-1+t_offset:t_end-1+t_offset-min_t:-1])
            else:
                rate_prj[i,:]=np.dot(W[2].T,zs_rate[:,i,rtime[i]/10+t_offset:rtime[i]/10+t_offset-min_t:-1])

    return W[1],W[2],rate_prj

def gen_fig(inet,plax1,plax2,t_terminated,t_terminated_evk,pca_dyn,pca_pert,loc_fig):
    suc_list=[2, 3, 5, 6, 7, 8, 11, 13, 14, 15, 16, 18, 19, 20, 22, 23, 24, 25, 26, 30]
    cset=['cyan', 'b', 'green', 'yellow', 'orange', 'magenta', 'red']
    fig=pl.figure()
    for init in range(4):
        ax1=fig.add_subplot(2,2,init+1)
        inset_ax=inset_axes(ax1,height="40%",width="40%",loc=loc_fig)
        t_tmp=int(t_terminated[inet][31*init]/10)
        if t_tmp<1:
            t_tmp=100
        ax1.plot(pca_pert[inet][31*init,:t_tmp,plax1],pca_pert[inet][31*init,:t_tmp,plax2],c="k",zorder=3)
        ax1.scatter(pca_pert[inet][31*init,30,plax1],pca_pert[inet][31*init,30,plax2],c="k",zorder=5,s=30)
        for i in range(31*init+1,31*(init+1)):
            t_tmp=int(t_terminated[inet][i]/10)
            if t_tmp<1:
                t_tmp=100
            ax1.plot(pca_pert[inet][i,:t_tmp,plax1],pca_pert[inet][i,:t_tmp,plax2],c="gray",zorder=2)
            ax1.scatter(pca_pert[inet][i,30,plax1],pca_pert[inet][i,30,plax2],c="gray",zorder=5,s=30)
        for j in range(7):
            t_tmp=int(t_terminated_evk[inet][j][init]/10)
            if t_tmp<1:
                t_tmp=100
            ax1.plot(pca_dyn[inet][j,init,10:t_tmp,plax1],pca_dyn[inet][j,init,10:t_tmp,plax2],c=cset[j],zorder=4)
            ax1.plot([pca_dyn[inet][j,init,10,plax1],pca_dyn[inet][j,init,30,plax1]],[pca_dyn[inet][j,init,10,plax2],pca_dyn[inet][j,init,30,plax2]],linewidth=3,c=cset[j],zorder=6)
            ax1.scatter([pca_dyn[inet][j,init,30,plax1]],[pca_dyn[inet][j,init,30,plax2]],linewidth=0,s=90,zorder=6,c=cset[j])
            ax1.scatter([pca_dyn[inet][j,init,t_tmp,plax1]],[pca_dyn[inet][j,init,t_tmp,plax2]],linewidth=3,s=90,zorder=6,c=cset[j],marker="+")
        for j in range(7):
            inset_ax.plot(pca_dyn[inet][j,init,5:35,plax1],pca_dyn[inet][j,init,5:35,plax2],linewidth=1,c=cset[j])
            inset_ax.scatter([pca_dyn[inet][j,init,30,plax1]],[pca_dyn[inet][j,init,30,plax2]],s=30,zorder=6,c=cset[j],marker="+")
    pl.savefig("reg_dyn2D_inet%d.eps" % suc_list[inet])
    return



def gen_stab_lyp(inet):
    dt=100
    dst=np.zeros((50,30))
    tmp=get_behav1(["pert_tmp","spn","t","get_trj"],[inet,-1,0.4,0.9,0.02,31*50,0.05,0.1])
    for i in range(50):
        for j in range(30):
            dx=tmp[5][31*i][100+dt,1]-tmp[5][31*i+j+1][dt,1]
            dy=tmp[5][31*i][100+dt,2]-tmp[5][31*i+j+1][dt,2]
            dst[i,j]=np.sqrt(dx*dx+dy*dy)

    return dst

"""
    # old version!
    def get_file_name(arg_paras):
    [inet,ipat,Si,scl,GEfb,flg]=arg_paras
    if(flg==0):
    str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl,GEfb)
    elif(flg==1):
    str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl,GEfb)
    return str
"""
"""
def get_pca_dyn(inet,Si,scl,GEfb,nsmp,npca,init_smp,endt_smp):
    tbin=5
    if init_smp>=endt_smp-tbin:
        exit()
    
    rate=np.load("rate%d-%g%g%g.npy" % (inet,Si,scl,GEfb))
    #    rate=np.load("rate%d-%g.npy" % (inet,Si))
    smp_PCA=np.mean(rate[:,:,init_smp:init_smp+tbin,2000:],axis=2).reshape(7*nsmp,3000)
    
    for i in range(init_smp+1,endt_smp-tbin):
        smp_PCA=np.vstack((smp_PCA,np.mean(rate[:,:,i:i+tbin,2000:],axis=2).reshape(7*nsmp,3000)))
    
    PCs=PCA(smp_PCA)
    PCA_dyn=np.zeros((7,nsmp,endt_smp-init_smp,npca))
    
    for i in range(7):
        for j in range(nsmp):
            for k in range(npca):
                PCA_dyn[i,j,:,k]=np.mean((PCs[1][k,:].reshape(3000,1))*(rate[i,j,init_smp:endt_smp,2000:].T),axis=0)
    
    
    PCA_dyn_ave=np.zeros((7,nsmp,endt_smp-init_smp,npca))
    for i in range(7):
        for j in range(nsmp):
            for k in range(0,endt_smp-tbin-init_smp):
                PCA_dyn_ave[i,j,k,:]=np.mean(PCA_dyn[i,j,k:k+tbin,:],axis=0)
    
    return PCA_dyn,PCA_dyn_ave
"""

"""
def get_pca_fda2(paras): # listL,R have index of trials with large difference between r0 and r1.
    [inet,Si,scl,GEfb,nsmp,thr]=paras[:]
    
    PCA_dyn,PCA_dyn_ave=get_pca_dyn(inet,Si,scl,GEfb,nsmp,npca,init_smp,endt_smp)
    
    listL=[]
    listR=[]
    t_end=[]
    for i in range(7):
        paras=[inet,0.1*i,Si,scl,GEfb,nsmp,thr]
        tmp=get_behav1(paras)
        listL.append(tmp[1])
        listR.append(tmp[2])
        t_end.append(tmp[3])

    if(len(listL[0])+len(listL[6])<=1 or len(listR[0])+len(listR[6])<=1):    # get discriminant plane from neural activity patterns for ipat=0 and 6 #        fda_pca_ave[ipat,0]=np.mean(fda_pca[ipat,idx_L[ipat],(t_end[ipat][listL[ipat][:len(idx_L[ipat])]]/10.-5).astype(np.int64),0])
        sys.stderr.write("FDA is invalid! no success trial in inet %d" % inet)
        return 1
    
    ipat=0
    data1=(PCA_dyn_ave[ipat,listL[ipat],list((np.array(t_end[ipat][listL[ipat]])/10.0-init_smp).astype(np.int64)),:]).T
    data2=(PCA_dyn_ave[ipat,listR[ipat],list((np.array(t_end[ipat][listR[ipat]])/10.0-init_smp).astype(np.int64)),:]).T
    
    ipat=6
    data1=np.hstack((data1,(PCA_dyn_ave[ipat,listL[ipat],list((np.array(t_end[ipat][listL[ipat]])/10.0-init_smp).astype(np.int64)),:]).T))
    data2=np.hstack((data2,(PCA_dyn_ave[ipat,listR[ipat],list((np.array(t_end[ipat][listR[ipat]])/10.0-init_smp).astype(np.int64)),:]).T))
    
    
    flg,J,Wopt,non_zero_cell=FDA.FDA2(data1,data2,range(npca),npca)
    
    if(flg==1):
        sys.stderr.write("FDA(Wopt) is invalid! inet %d" % inet)
        return 1
    
    # in terms of stimulus
    data1=PCA_dyn[0,:,10,:].T
    data2=PCA_dyn[6,:,10,:].T
    flg,J,Wopt1,non_zero_cell=FDA.FDA2(data1,data2,range(npca),npca)
    if(flg==1):
        sys.stderr.write("FDA(Wopt1) is invalid! inet %d" % inet)
        return 1
    
    # get fda dynamics
    fda_pca=np.zeros((7,nsmp,endt_smp-init_smp,2))
    
    for i in range(7):
        for j in range(nsmp):
            fda_pca[i,j,:,0]=np.dot(Wopt.T,PCA_dyn_ave[i,j,:,:].T)
            fda_pca[i,j,:,1]=np.dot(Wopt1.T,PCA_dyn_ave[i,j,:,:].T)
    
    fda_pca_ave=np.zeros((7,2))
    for ipat in range(7):
        if(len(listL[ipat])!=0):
            fda_pca_ave[ipat,0]=np.mean(fda_pca[ipat,listL[ipat],list((np.array(t_end[ipat][listL[ipat]])/10.0-init_smp).astype(np.int64)),0])
        else:
            fda_pca_ave[ipat,0]=0
        if(len(listR[ipat])!=0):
            fda_pca_ave[ipat,1]=np.mean(fda_pca[ipat,listR[ipat],list((np.array(t_end[ipat][listR[ipat]])/10.0-init_smp).astype(np.int64)),0])
        else:
            fda_pca_ave[ipat,1]=0
    
    
    return fda_pca_ave,fda_pca,Wopt,Wopt1,PCA_dyn_ave,listL,listR,t_end
"""

"""  old version (2016.11.08)
    def get_fda_curve(fda_pca,listL,listR,t_end):
    fda_ave=np.zeros(7)
    for ipat in range(7):
    if(len(listL[ipat])!=0 or len(listR[ipat])!=0):
    fda_ave[ipat]=np.sum(fda_pca[ipat,listL[ipat],list((np.array(t_end[ipat][listL[ipat]])/10.0-init_smp).astype(np.int64)),0])+np.sum(fda_pca[ipat,listR[ipat],list((np.array(t_end[ipat][listR[ipat]])/10.0-init_smp).astype(np.int64)),0])
    fda_ave[ipat]/=float(len(listL[ipat])+len(listR[ipat]))
    return fda_ave
    """


""" old version (2016.1108)
def main(Si):
    [scl,GEfb,nsmp,thr]=[0.9,0.02,50,0.05]
    thrs_good=2*nsmp*0.8
# get fda-related variables for all networks

    fda_dyn=[]
    for i in range(30):
        tmp=get_pca_fda2([i+1,Si,scl,GEfb,nsmp,thr])
        fda_dyn.append(tmp)

    np.save("fda_dyn%g.npy" % Si,fda_dyn)
    return
    # check perfomance and then compare beh curve and fda curve
    #for i in range(30):
#    if len(fda_dyn[i][5][0])+len(fda_dyn[i][6][6])>thrs_good:
# suc_list.append(i+1)
"""
