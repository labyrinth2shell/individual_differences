import numpy as np
import pylab as pl
from scipy import linalg as LA
from scipy import optimize
from mpl_toolkits.mplot3d import Axes3D

from scipy.ndimage import filters as flt
import sys
import FDA 
reload(FDA)

eps_dbl=0.00000001

def PCA(P):
    m = sum(P) / float(len(P))
    P_m = P - m
    l,v = np.linalg.eig( np.dot(P_m.T,P_m) )
    idx=l.argsort()
    l=l[idx][::-1]
    v=v[:,idx][:,::-1]
    return l,v.T



def get_file_name(arg_paras):
    [inet,ipat,Si,scl,GEfb,flg]=arg_paras
    if(flg==0):
        if ipat<0.:
            str="rbr56_fb_rnd_norm%d-300_l-1%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,Si,scl,GEfb)
        else:
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl,GEfb)
    elif(flg==1):
        if ipat<0.:
            str="rbt56_fb_rnd_norm%d-300_l-1%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,Si,scl,GEfb)
        else:
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl,GEfb)

    return str




def get_rate_all(arg_paras):
    [inet,ipat,Si,scl,GEfb,nsmp]=arg_paras
    cnt=0

    inv_bin_smp=0.1 #[ms-1]
    t_smp = 1000
    str=get_file_name([inet,ipat,Si,scl,GEfb,0])
        
    n_bin      =int(t_smp*inv_bin_smp)
    rate_tmp=np.zeros((nsmp,n_bin+1,5000))
    
    tmp=np.loadtxt(str)
    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:
            cnt+=1
            if nsmp<=cnt:
                break
        if tmp[i,1]<5000:
            rate_tmp[cnt,int(tmp[i,0]*inv_bin_smp),tmp[i,1]]+=1

    return rate_tmp


def get_rate_allnet(arg_paras):
    [Si,scl,GEfb,suc_list,n_smp,n_t_bin]=arg_paras
   
    for j in suc_list:
        rate=np.zeros((7,n_smp,n_t_bin+1,5000))
        for k in range(7):
            rate[k]=get_rate_all([j,0.1*k,Si,scl,GEfb,n_smp])
        np.save("rate%d-%g%g%g.npy" % (j,Si,scl,GEfb),rate)

    return


def get_behav1(paras):
    [inet,ipat,Si,scl,GEfb,nsmp,diff]=paras[:]
    cnt=0
    behav_ind=np.zeros(nsmp)
    behav_list=[]
    colist=[]
    t_end=np.zeros(nsmp)

    t_init_smp=350
    t_end_smp=601
    
    str=get_file_name([inet,ipat,Si,scl,GEfb,1])    
    tmp=np.loadtxt(str)
    tmptmp=tmp[0,1:3]
    flg=3


    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:  # detection of a new trial
            for j in range(t_init_smp,t_end_smp):
                if tmptmp[j,0] - tmptmp[j,1]>diff:
                    t_end[cnt]=j
                    behav_list.append(cnt)
                    break
                elif tmptmp[j,1] - tmptmp[j,0]>diff:
                    t_end[cnt]=j
                    colist.append(cnt)
                    break

            tmptmp=tmp[i,1:3]
            cnt+=1
            if cnt>=nsmp:
                break

        elif i>0:  # store a trajectory of a trial in tmptmp
            tmptmp=np.vstack((tmptmp,tmp[i,1:3]))


    if cnt<=nsmp-1:
        for j in range(t_init_smp,t_end_smp):
            if tmptmp[j,0] - tmptmp[j,1]>diff:
                t_end[cnt]=j
                behav_list.append(cnt)
                break
            elif tmptmp[j,1] - tmptmp[j,0]>diff:
                t_end[cnt]=j
                colist.append(cnt)
                break
    del tmp

    return behav_ind,behav_list,colist,t_end




def rate2norm(inet):
    rate=np.load("rate%d-0.40.90.02.npy" % inet)[:,:,:,2000:]
    
    if(len(rate[0,0,0,:])==5000):
        sys.stderr.write('rate is invalid in rate2norm!')        
        exit()
    
    norm_rate=np.zeros(rate.shape)
    
    for i in range(7):
        for j in range(50):
            for k in range(3000):
                if(np.fabs(np.std(rate[i,j,:,k]))>0.000001):
                    tmp=flt.gaussian_filter(rate[i,j,:,k],2)
                    norm_rate[i,j,:,k]=tmp[:]
                    #   norm_rate[i,j,:,k]=(tmp[:]-np.mean(tmp))/np.std(tmp)

    del rate
    return norm_rate

def norm2prj(norm,inet,flg):
    if(flg==4):
        QR=np.load("beta_tmp%d%d-0.40.90.02.npz" % (flg,inet))["QR"]
    else:
        QR=np.load("beta%d%d-0.40.90.02.npz" % (flg,inet))["QR"]

    if(flg==4):
        ncoef=3
    elif(flg==3):
        ncoef=2
        
    prj=np.zeros((7,50,61,ncoef))
    for i in range(7):
        for j in range(50):
            prj[i,j,:,:]=np.dot(QR[:,:ncoef].T,norm[i,j,:,:].T).T

    return prj
    


def get_pca_dyn(inet,Si,scl,GEfb,nsmp,npca,init_smp,endt_smp):
    tbin=5
    if init_smp>=endt_smp-tbin:
        exit()

    rate=np.load("rate%d-%g%g%g.npy" % (inet,Si,scl,GEfb))[:,:,:,2000:]
    #    rate=np.load("rate%d-%g.npy" % (inet,Si))

    
    rate=rate2norm(rate)
    smp_PCA=np.mean(rate[:,:,init_smp:init_smp+tbin,:],axis=2).reshape(7*nsmp,3000)

    for i in range(init_smp+1,endt_smp-tbin):
        smp_PCA=np.vstack((smp_PCA,np.mean(rate[:,:,i:i+tbin,:],axis=2).reshape(7*nsmp,3000)))

    PCs=PCA(smp_PCA)
    PCA_dyn=np.zeros((7,nsmp,endt_smp-init_smp,npca))

    for i in range(7):
        for j in range(nsmp):
             for k in range(npca):
                 PCA_dyn[i,j,:,k]=np.mean((PCs[1][k,:].reshape(3000,1))*(rate[i,j,init_smp:endt_smp,:].T),axis=0)


    PCA_dyn_ave=np.zeros((7,nsmp,endt_smp-init_smp,npca))
    for i in range(7):
        for j in range(nsmp):
            for k in range(0,endt_smp-tbin-init_smp):
                PCA_dyn_ave[i,j,k,:]=np.mean(PCA_dyn[i,j,k:k+tbin,:],axis=0)

    return PCA_dyn,PCA_dyn_ave



# modified on 16.12.2015
def get_pca_fda2(inet,Si,scl,GEfb,nsmp): # listL,R have index of trials with large difference between r0 and r1. 
    npca=15
    init_smp=10
    endt_smp=61
    thr=0.05
    
    PCA_dyn,PCA_dyn_ave=get_pca_dyn(inet,Si,scl,GEfb,nsmp,npca,init_smp,endt_smp)

    listL=[]
    listR=[]
    t_end=[]
    for i in range(7):
        paras=[inet,0.1*i,Si,scl,GEfb,nsmp,thr]
        tmp=get_behav1(paras)
        listL.append(tmp[1])
        listR.append(tmp[2])
        t_end.append(tmp[3])
    #        fda_pca_ave[ipat,0]=np.mean(fda_pca[ipat,idx_L[ipat],(t_end[ipat][listL[ipat][:len(idx_L[ipat])]]/10.-5).astype(np.int64),0])
    # get discriminant plane from neural activity patterns for ipat=0 and 6
    if(len(listL[0])+len(listL[6])<=1 or len(listR[0])+len(listR[6])<=1):
        sys.stderr.write("FDA is invalid! no success trial in inet %d" % inet)
        return 1
        
    ipat=0
    data1=(PCA_dyn_ave[ipat,listL[ipat],list((np.array(t_end[ipat][listL[ipat]])/10.0-init_smp).astype(np.int64)),:]).T
    data2=(PCA_dyn_ave[ipat,listR[ipat],list((np.array(t_end[ipat][listR[ipat]])/10.0-init_smp).astype(np.int64)),:]).T
    
    ipat=6
    data1=np.hstack((data1,(PCA_dyn_ave[ipat,listL[ipat],list((np.array(t_end[ipat][listL[ipat]])/10.0-init_smp).astype(np.int64)),:]).T))
    data2=np.hstack((data2,(PCA_dyn_ave[ipat,listR[ipat],list((np.array(t_end[ipat][listR[ipat]])/10.0-init_smp).astype(np.int64)),:]).T))
    

    flg,J,Wopt,non_zero_cell=FDA.FDA2(data1,data2,range(npca),npca)

    if(flg==1):
        sys.stderr.write("FDA(Wopt) is invalid! inet %d" % inet)
        return 1
    
    # in terms of stimulus
    data1=PCA_dyn[0,:,10,:].T
    data2=PCA_dyn[6,:,10,:].T
    flg,J,Wopt1,non_zero_cell=FDA.FDA2(data1,data2,range(npca),npca)
    if(flg==1):
        sys.stderr.write("FDA(Wopt1) is invalid! inet %d" % inet)
        return 1

    #check point
    tmp=np.hstack((Wopt,Wopt1))
    tmptmp=LA.qr(tmp)
    Wopt=(tmptmp[0][:,0]).reshape((15,1))
    Wopt1=(tmptmp[0][:,1]).reshape((15,1))
    
    # get fda dynamics
    fda_pca=np.zeros((7,nsmp,endt_smp-init_smp,2))

    for i in range(7):
        for j in range(nsmp):
             fda_pca[i,j,:,0]=np.dot(Wopt.T,PCA_dyn_ave[i,j,:,:].T)
             fda_pca[i,j,:,1]=np.dot(Wopt1.T,PCA_dyn_ave[i,j,:,:].T)
             
    fda_pca_ave=np.zeros((7,2))
    for ipat in range(7):
        if(len(listL[ipat])!=0):
            fda_pca_ave[ipat,0]=np.mean(fda_pca[ipat,listL[ipat],list((np.array(t_end[ipat][listL[ipat]])/10.0-init_smp).astype(np.int64)),0])
        else:
            fda_pca_ave[ipat,0]=0
        if(len(listR[ipat])!=0):
            fda_pca_ave[ipat,1]=np.mean(fda_pca[ipat,listR[ipat],list((np.array(t_end[ipat][listR[ipat]])/10.0-init_smp).astype(np.int64)),0])
        else:
            fda_pca_ave[ipat,1]=0


    return fda_pca_ave,fda_pca,Wopt,Wopt1,PCA_dyn_ave,listL,listR,t_end



def fit_func(para,x):
    a=para[0]
    b=para[1]
    c=para[2]
#    d=para[3]
    #    return d*(np.tanh(-(x-a)*b)+c)
    return c*(np.tan(-(x*0.33-a))+b)
#    return c*(np.tan(-(x/2.0-a))+b)


"""
def fit_func(para,x):
    a=para[0]
    b=para[1]
#    d=para[3]
    #    return d*(np.tanh(-(x-a)*b)+c)
    c=-1.0/(np.tan(a+b)-np.tan(b))
    return c*(np.tan(a*x+b)-np.tan(b))+1
"""


def resid_fit(para,x,y):
    res=y-fit_func(para,x)
    return res


def calc_type_psy(beh):
    n_net=len(beh)
    n_para=3
    para=np.zeros((n_net,n_para))
    
    for j in range(n_net):
        para0=[1.1,0.4,1.1]
        res=optimize.leastsq(resid_fit,para0,args=(np.arange(7),beh[j,:]))
        para[j,:]=res[0]
    return para



def show_pic(suc_list,para,beh):
    for i in range(len(suc_list)):
        pl.subplot(3,3,i+1)
        inet=suc_list[i]
        pl.scatter(range(7),beh[inet-1,:])
        pl.plot(np.arange(0,6,0.01),fit_func(para[inet-1],np.arange(0,6,0.01)))

    return





def get_zscored_dyn1(rate,listL,listR):
    if(len(rate[0,0,0,:])==5000):
        sys.stderr.write('rate is invalid!')        
        exit()

    n_tsmp=len(rate[0,0])
    norm_rate=np.zeros((7*50,n_tsmp,3000))    
    for i in range(7):
        for j in range(50):
            for k in range(3000):
                if(np.fabs(np.std(rate[i,j,:,k]))>eps_dbl):
                    tmp=flt.gaussian_filter(rate[i,j,:,k],2)
                    norm_rate[i*50+j,:,k]=(tmp[:]-np.mean(tmp))/np.std(tmp)
    return norm_rate


def get_zscored_dyn(rate,listL,listR,flg):
    if(flg!=0 and flg!=3 and flg!=4):
        sys.stderr.write('invalid flg in zscored_dyn')
        exit()
        
    n_tsmp=len(rate[0,0])
    n_trial=0
    for i in range(7):
        n_trial+=(len(listL[i])+len(listR[i]))
    norm_rate=np.zeros((n_trial,n_tsmp,3000))
        
    cnt=0
    for i in range(7):
        for j in range(len(listL[i])):
            for k in range(3000):
                if(np.fabs(np.std(rate[i,listL[i][j],:,k]))>eps_dbl):
                    tmp=flt.gaussian_filter(rate[i,listL[i][j],:,k],2)
                    if(flg==0):
                        norm_rate[cnt+j,:,k]=(tmp[:]-np.mean(tmp))/np.std(tmp)
                    elif(flg==3 or flg==4):
                        norm_rate[cnt+j,:,k]=tmp[:]
        cnt+=len(listL[i])
        for j in range(len(listR[i])):
            for k in range(3000):
                if(np.fabs(np.std(rate[i,listR[i][j],:,k]))>eps_dbl):
                    tmp=flt.gaussian_filter(rate[i,listR[i][j],:,k],2)
                    if(flg==0):
                        norm_rate[cnt+j,:,k]=(tmp[:]-np.mean(tmp))/np.std(tmp)
                    elif(flg==3 or flg==4):
                        norm_rate[cnt+j,:,k]=tmp[:]
        cnt+=len(listR[i])
            
    return norm_rate
            
    
def gen_zscored_ave_dyn(rate,listL,listR,flg):
    if(len(rate[0,0,0,:])==5000):
        sys.stderr.write('rate is invalid!')        
        exit()

    n_tsmp=len(rate[0,0])
    if flg == 2:
        cond_dyn=np.zeros((7,3,n_tsmp,3000))
        
        for ipat in range(7):
            rest=set(range(50))-(set(listL[ipat]) | set(listR[ipat]))
            rest=list(rest)
        
            if(len(listL[ipat])!=0):
                cond_dyn[ipat,0,:,:]=np.mean(rate[ipat,listL[ipat],:,:],axis=0)
            if(len(listR[ipat])!=0):
                cond_dyn[ipat,1,:,:]=np.mean(rate[ipat,listR[ipat],:,:],axis=0)
            if(len(rest)!=0):
                cond_dyn[ipat,2,:,:]=np.mean(rate[ipat,rest,:,:],axis=0)

    elif(flg ==0 or flg==3 or flg==4):
        cond_dyn=np.zeros((7,2,n_tsmp,3000))
        for ipat in range(7):
            if(len(listL[ipat])!=0):
                cond_dyn[ipat,0,:,:]=np.mean(rate[ipat,listL[ipat],:,:],axis=0)
            if(len(listR[ipat])!=0):
                cond_dyn[ipat,1,:,:]=np.mean(rate[ipat,listR[ipat],:,:],axis=0)

                

    flt_dyn=np.zeros(cond_dyn.shape)
    for i in range(len(flt_dyn)):
        for j in range(len(flt_dyn[0])):
            for k in range(3000):
                flt_dyn[i,j,:,k]=flt.gaussian_filter(cond_dyn[i,j,:,k],2)

    if(flg==3 or flg==4):
        return flt_dyn
                
    norm_dyn=np.zeros(flt_dyn.shape)
    ave_tmp=np.mean(flt_dyn,axis=(0,1,2))
    dev_tmp=np.std(flt_dyn,axis=(0,1,2))

    for i in range(len(norm_dyn)):
        for j in range(len(norm_dyn[0])):
            for k in range(3000):
                norm_dyn[i,j,:,k]=(flt_dyn[i,j,:,k]-ave_tmp[k])/(dev_tmp[k])

    return norm_dyn




def gen_F1(listL,listR,ncoef):
    tmp1=[]
    for i in range(7):
        for j in range(50):
            tmp=np.zeros(ncoef)
            if j in listL[i]:
                tmp[0]=1
            elif j in listR[i]:
                tmp[0]=-1
            else:
                tmp[0]=0
            tmp[1]=(i-3.0)/3.0
            tmp[2]=1
            tmp1.append(tmp)

    tmp1=np.array(tmp1)
    F=tmp1.T
    return F

            
                
    
def gen_F(listL,listR,ncoef):
    tmp1=[]
    for i in range(7):
        for j in range(len(listL[i])):
            tmp=np.zeros(ncoef)
            tmp[0]=1
            if(ncoef==4):
                if(i==0):
                    tmp[1]=-1
                    tmp[2]=0
                elif(i==6):
                    tmp[1]=1
                    tmp[2]=0
                else:
                    tmp[1]=0
                    tmp[2]=(i-2.5)/2.5
                tmp[3]=1
            elif(ncoef==3):
                tmp[1]=(i-3.0)/3.0
                tmp[2]=1
            tmp1.append(tmp)
        for j in range(len(listR[i])):
            tmp=np.zeros(ncoef)
            tmp[0]=-1
            if(ncoef==4):
                if(i==0):
                    tmp[1]=-1
                    tmp[2]=0
                elif(i==6):
                    tmp[1]=1
                    tmp[2]=0
                else:
                    tmp[1]=0
                    tmp[2]=(i-2.5)/2.5
                tmp[3]=1
            elif(ncoef==3):
                tmp[1]=(i-3.0)/3.0
                tmp[2]=1
            tmp1.append(tmp)

    tmp1=np.array(tmp1)
    F=tmp1.T
    return F



def get_beta(listL,listR,norm_r,ncoef,flg):
    
    if(flg==2):
        F=gen_F1(listL,listR,ncoef)
    else:
        F=gen_F(listL,listR,ncoef)
        
    n_tsmp=len(norm_r[0])
    beta=np.zeros((ncoef,n_tsmp,3000))
    for i in range(n_tsmp):
        for j in range(3000):
            beta[:,i,j]=np.dot(LA.inv(np.dot(F,F.T)),np.dot(F,norm_r[:,i,j]))
 
    return beta


def get_pca_beta(beta,PCs):
    ncoef=len(beta)
    n_tsmp=len(beta[0])
    pca_beta=np.zeros(beta.shape)
    for i in range(ncoef):
        for j in range(n_tsmp):
            for k in range(15):
                tmp=pca_beta[i,j,:]+np.sum(PCs[k,:]*beta[i,j,:])*PCs[k,:]
                pca_beta[i,j,:]=tmp

    return pca_beta


def get_orth_beta(beta_dyn):
    ncoef=len(beta_dyn)
    n_tsmp=len(beta_dyn[0])
    beta_max=np.zeros((ncoef,3000))
    t_max=np.zeros(ncoef)
    for i in range(ncoef):
        tmp=np.zeros(n_tsmp)
        for j in range(n_tsmp):
            tmp[j]=np.sum(beta_dyn[i,j,:]*beta_dyn[i,j,:])
        t_max[i]=np.argsort(tmp)[-1]
        beta_max[i,:]=beta_dyn[i,t_max[i],:]

    QR=LA.qr(beta_max[:(ncoef-1),:].T)

    return beta_max,QR,t_max


def get_orth_beta1(beta_dyn):
    ncoef=len(beta_dyn)
    n_tsmp=len(beta_dyn[0])
    beta_max=np.zeros((ncoef,3000))
    t_max=np.zeros(ncoef)
    for i in range(ncoef):
        tmp=np.zeros(n_tsmp)
        for j in range(n_tsmp):
            tmp[j]=np.sum(beta_dyn[i,j,:]*beta_dyn[i,j,:])
        t_max[i]=np.argsort(tmp)[-1]
        beta_max[i,:]=beta_dyn[i,t_max[i],:]

    #check point
    beta_max[1,:]=beta_dyn[1,19,:]
    QR=LA.qr(beta_max[:(ncoef-1),:].T)

    return beta_max,QR,t_max


def get_prj_dyn(QR,norm_dyn,ncoef):

    ncond=len(norm_dyn[0])
    n_tsmp=len(norm_dyn[0,0])
    prj_dyn=np.zeros((7,ncond,ncoef-1,n_tsmp))
    for i in range(7):
        for j in range(ncond):
            for k in range(ncoef-1):
                for l in range(n_tsmp):
                    prj_dyn[i,j,k,l]=np.sum(QR[0][:,k]*norm_dyn[i,j,l,:])

    return prj_dyn

def get_listLR(inet,Si,scl,GEfb,nsmp,thr):
    beh=[]
    
    for i in range(7):
        tmp=get_behav1([inet,0.1*i,Si,scl,GEfb,nsmp,thr])
        beh.append(tmp[1])
        beh.append(tmp[2])
        beh.append(tmp[3])
    listL=[]
    listR=[]
    tend=[]
 
    for i in range(7):
        listL.append(beh[i*3])
        listR.append(beh[i*3+1])
        tend.append(beh[i*3+2])


    return listL,listR,tend


    

def main(inet,Si,scl,GEfb,flg):
    # flg=0:normlized ensemble and # of choice=2 (ncond=2,Left and Right), ncoef=3 (choice,stim, other)
    # flg=2:normlized ensemble and # of choice=3 (ncond=3,Left,Right, and other), ncoef=3 (choice,stim, other)
    # flg=3:same as flg=0 except for just fileterd ensemble
    # flg=4:normlized ensemble and # of choice=2 (ncond=2,Left,Right), ncoef=4 (choice,fam stim, nov stim,other)
    nsmp=50
    t_init=0
    t_init_pca=10
    t_init_beta_max=10
    thr=0.05
    if(flg==0 or flg==3 or flg==4):
        ncond=2
    elif(flg==2):
        ncond=3
    if(flg==4):
        ncoef=4
    else:
        ncoef=3
        
        
    rate=np.load("rate%d-%g%g%g.npy" % (inet,Si,scl,GEfb))[:,:,t_init:,2000:]
    #    fda_dyn=get_pca_fda2(inet,Si,scl,GEfb,nsmp)
    listL,listR=get_listLR(inet,Si,scl,GEfb,nsmp,thr)
    norm_dyn=gen_zscored_ave_dyn(rate,listL,listR,flg)
    if(ncond!=len(norm_dyn[0])):
        sys.stderr.write('ncond is invalid!')
    pca_data=norm_dyn[:,:,t_init_pca:,:].reshape(7*ncond*len(norm_dyn[0,0,t_init_pca:]),3000)
    PCs=PCA(pca_data)

    # get beta_orth
    if(flg==0 or flg==3 or flg==4):
        norm_r15   =get_zscored_dyn(rate,listL,listR,flg)
    elif(flg==2):
        norm_r15   =get_zscored_dyn1(rate,listL,listR)
    beta       =get_beta(listL,listR,norm_r15,ncoef,flg)
    pca_beta   =get_pca_beta(beta,PCs[1])
    #check point
    beta_max,QR,t_max=get_orth_beta(pca_beta[:,t_init_beta_max:,:])
    #beta_max,QR,t_max=get_orth_beta1(pca_beta[:,t_init_beta_max:,:])

    prj_dyn    =get_prj_dyn(QR,norm_dyn,ncoef)

    np.save("prj_dyn%d%d-%g%g%g.npy" % (flg,inet,Si,scl,GEfb),prj_dyn)
    np.savez("beta%d%d-%g%g%g.npz" % (flg,inet,Si,scl,GEfb),QR=QR[0],beta=beta_max,tmax=t_max)

    return 




def pic_flow(fda_dyn,para,nsmp,flg):
    [ipat,ich,icl,lw]=para

    if(flg==2):
        for i in range(nsmp):
            if i in fda_dyn[5][ipat]:
                pl.scatter(fda_dyn[1][ipat,i,21,0],fda_dyn[1][ipat,i,21,1].T,color="b",s=lw,marker="o")
            elif i in fda_dyn[6][ipat]:
                pl.scatter(fda_dyn[1][ipat,i,21,0],fda_dyn[1][ipat,i,21,1].T,color="r",s=lw,marker="D")
            else:
                pl.scatter(fda_dyn[1][ipat,i,21,0],fda_dyn[1][ipat,i,21,1].T,color="g",s=lw,marker="x")
        return
                
    if(nsmp>len(fda_dyn[ich][ipat])):
        nsmp=len(fda_dyn[ich][ipat])
        
    for i in range(nsmp):
        if(flg==0):
            pl.plot(fda_dyn[1][ipat,fda_dyn[ich][ipat][i],:45,0],fda_dyn[1][ipat,fda_dyn[ich][ipat][i],:45,1].T,c=icl,linewidth=lw)
#            pl.scatter(fda_dyn[1][ipat,fda_dyn[ich][ipat][i],21,0],fda_dyn[1][ipat,fda_dyn[ich][ipat][i],21,1].T,color=icl,s=(lw+8))
        elif(flg==1):
            pl.scatter(fda_dyn[1][ipat,fda_dyn[ich][ipat][i],21,0],fda_dyn[1][ipat,fda_dyn[ich][ipat][i],21,1].T,color=icl,s=lw)
            #            pl.scatter(fda_dyn[1][ipat,i,21,0],fda_dyn[1][ipat,i,21,1].T,color=icl,s=lw)
            
    return



def tmp(fda_dyn,c_set):
    """
    for i in range(7):
        pic_flow(fda_dyn,[i,6,c_set[i],16],50,2)
        pic_flow(fda_dyn,[i,5,c_set[i],16],10,1)
        pl.xlim(-0.0025,0.0025)
        pl.ylim(-0.0025,0.0025)
    return
    """
    
    pic_flow(fda_dyn,[0,5,"blue",1],10,0)
    pic_flow(fda_dyn,[6,6,"r",1],10,0)
 
    pic_flow(fda_dyn,[1,5,"cyan",8],10,1)
    pic_flow(fda_dyn,[1,6,"cyan",16],10,1)
    pic_flow(fda_dyn,[3,5,"magenta",8],10,1)
    pic_flow(fda_dyn,[3,6,"magenta",16],10,1)

    return


def tmptmp(fda_dyn11_05,fda_dyn14_05,fda_dyn15_05,fda_dyn18_05,c_set):

    pl.subplot(2,2,1)
    tmp(fda_dyn11_05,c_set)
    pl.subplot(2,2,2)
    tmp(fda_dyn15_05,c_set)
    pl.subplot(2,2,3)
    tmp(fda_dyn14_05,c_set)
    pl.subplot(2,2,4)
    tmp(fda_dyn18_05,c_set)

    return


def tmptmptmp(prj):
    c_set=["b","cyan","green","orange","magenta","red","black"]
    for i in range(7):
        pl.plot(prj[i,0,0,5:56],prj[i,0,1,5:56],c=c_set[i],linewidth=1)
        pl.plot(prj[i,1,0,5:56],prj[i,1,1,5:56],c=c_set[i],linewidth=2)
    return


def tmp4(prj,tplot,listL,listR):
    for i in range(50):
        if i in listL:
            pl.scatter(prj[i,tplot,0],prj[i,tplot,1],c="b",s=30)
        elif i in listR:
            pl.scatter(prj[i,tplot,0],prj[i,tplot,1],c="r",s=30)
        else:
            pl.scatter(prj[i,tplot,0],prj[i,tplot,1],c="green",s=30)
    return


def tmp4_3D(prj,tplot,listL,listR,ax,sym):
    for i in range(50):
        if i in listL:
            ax.scatter3D(prj[i,tplot,0],prj[i,tplot,1],prj[i,tplot,2],c="b",s=30,marker=sym)
        elif i in listR:
            ax.scatter3D(prj[i,tplot,0],prj[i,tplot,1],prj[i,tplot,2],c="r",s=30,marker=sym)
        else:
            ax.scatter3D(prj[i,tplot,0],prj[i,tplot,1],prj[i,tplot,2],c="green",s=30,marker=sym)
    return


def tmp5(prj,ax):
    c_set=["b","cyan","green","orange","magenta","red","black"]
    for i in range(7):
        ax.plot3D(prj[i,0,0,5:56],prj[i,0,1,5:56],prj[i,0,2,5:56],c=c_set[i])
        ax.plot3D(prj[i,1,0,5:56],prj[i,1,1,5:56],prj[i,1,2,5:56],c=c_set[i],linewidth=2)

    return


def get_para(n_para,beh):
    if(n_para!=3):
        sys.stderr.write('invalid in get_para!') 

    para=np.zeros(n_para)
    para0=[1.1,0.4,1.1]
    res=optimize.leastsq(resid_fit,para0,args=(np.arange(7),beh[:]))
    para[:]=res[0]
    return para

    
def tmp6(inet,thr):

    listL,listR,tend=get_listLR(inet,0.4,0.9,0.02,50,thr)
    beh=np.zeros(7)
    for i in range(7):
        beh[i]=float(len(listL[i]))/(len(listL[i])+len(listR[i]))
        
    para=get.para(3,beh)
    """
    tmptmp=np.load("beta3%d-0.40.90.02.npz" % inet)
    tmp=tmptmp["beta"]

    over=np.zeros(3)
    over[0]=np.sum(tmp[0,:]*tmp[1,:])/np.sqrt(np.sum(tmp[0,:]*tmp[0,:])*np.sum(tmp[1,:]*tmp[1,:]))
    over[1]=np.sum(tmp[1,:]*tmp[2,:])/np.sqrt(np.sum(tmp[1,:]*tmp[1,:])*np.sum(tmp[2,:]*tmp[2,:]))
    over[2]=np.sum(tmp[0,:]*tmp[2,:])/np.sqrt(np.sum(tmp[0,:]*tmp[0,:])*np.sum(tmp[2,:]*tmp[2,:]))
    """
    return beh,para

def tmp7(prj_ave,prj,ipat,tplot,tplot1,listL,listR):
    flg=pl.figure()
    ax=Axes3D(flg)

    tmp5(prj_ave,ax)
    tmp4_3D(prj[ipat],tplot,listL[ipat],listR[ipat],ax,"o")
    tmp4_3D(prj[ipat],tplot1,listL[ipat],listR[ipat],ax,"x")

    return


def tmp8(inet,flg):
    listL,listR,tend=get_listLR(inet,0.4,0.9,0.02,50,0.08)
    if(flg==4):
        prj_ave=np.load("prj_dyn_tmp%d%d-0.40.90.02.npy" % (flg,inet))
    else:
        prj_ave=np.load("prj_dyn%d%d-0.40.90.02.npy" % (flg,inet))
    norm=rate2norm(inet)
    prj=norm2prj(norm,inet,flg)

    del norm
    
    return prj,prj_ave,listL,listR,tend


def tmp9(net_list):
    suc_list=[]
    for inet in net_list:
        listL,listR=get_listLR(inet,0.4,0.9,0.02,50,0.03)
        flg=0
        for j in range(7):
            tmp=len(listL[j])+len(listR[j])
            if( tmp <30):
                flg=1
                break
        if(flg==0):
            suc_list.append(inet)

    return suc_list



def tmp10(net_list):
    nsmp=50
    nnet=len(net_list)
    vol=np.zeros((nnet,2))
    dep1=[]
    dep2=[]
    for i in range(nnet):
        inet=net_list[i]
        tmp=get_behav1([inet,0,0.4,0.9,0.02,nsmp,0.05])
        vol[i,0]=len(tmp[1])
        dep1.append(tmp[3][tmp[1]])
        tmp=get_behav1([inet,0.6,0.4,0.9,0.02,nsmp,0.05])
        vol[i,1]=len(tmp[2])
        dep2.append(tmp[3][tmp[2]])

    return vol,dep1,dep2




def tmp11(beh):
    tmp=(beh[:]-beh[6])/(beh[0]-beh[6])
    beh=tmp
    
    n_para=2
    para=np.zeros(n_para)
    para0=[1,-0.5]
    res=optimize.leastsq(resid_fit,para0,args=(np.arange(0.167,1,1./6),beh[1:6]))
    para[:]=res[0]

    tmp=np.zeros(3)
    tmp[:2]=para[:]
    tmp[2]=-1.0/(np.tan(tmp[0]+tmp[1])-np.tan(tmp[1]))
    return tmp

#suc_list thr=0.05
#[3, 5, 7, 8, 11, 13, 14, 18, 19, 20, 22, 24, 25, 30
#0.022399  ,  0.31143401,  0.30570375,  0.21329985,  0.24095286, 0.0506306 ,  0.25841263,  0.17702985,  0.26435864,  0.07227352,  0.35755821,  0.12902126,  0.33222114,  0.00658338]
#suc_lsit thr=0.03
#1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 30]



def tmp12(prj,ipat,ax):
    c_set=["b","cyan","green","orange","magenta","red","black"]
    for i in range(20):
        ax.plot3D(prj[ipat,i,5:56,0],prj[ipat,i,5:56,1],prj[ipat,i,5:56,2],c=c_set[ipat])
        ax.scatter3D(prj[ipat,i,5,0],prj[ipat,i,5,1],prj[ipat,i,5,2],c=c_set[ipat],s=30,marker="o")
        ax.scatter3D(prj[ipat,i,30,0],prj[ipat,i,30,1],prj[ipat,i,30,2],c=c_set[ipat],s=50,marker="D")
        ax.scatter3D(prj[ipat,i,55,0],prj[ipat,i,55,1],prj[ipat,i,55,2],c=c_set[ipat],s=30,marker="x")

    return



def tmp13(inet,Si,scl,GEfb,nsmp,listL,listR): # listL,R have index of trials with large difference between r0 and r1. 
    npca=15
    init_smp=10
    endt_smp=61
    thr=0.05
    tbin=5
    
    rate=rate2norm(inet)    
    lam=np.zeros((7,3,11,3000))
    for i in range(7):
        for j in range(11):
            smp_PCA=rate[i,:,init_smp+tbin*j,:].reshape(nsmp,3000)
            if len(listL[i]) != 0:
                PCs=PCA(smp_PCA[listL[i]])
                lam[i,0,j]=PCs[0]
            if len(listR[i]) != 0:
                PCs=PCA(smp_PCA[listR[i]])
                lam[i,1,j]=PCs[0]
            if len(listL[i]+listR[i]) != 0:
                PCs=PCA(smp_PCA[listR[i]+listL[i]])
                lam[i,2,j]=PCs[0]

    np.save("lam%d.npy" % inet,lam)
    return lam

def tmp14(inet):

    beta=np.load("beta3%d-0.40.90.02.npz" % inet)
    QR=beta["QR"]
    rate=get_rate_all([inet,-1,0.4,0.9,0.02,50])[:,:,2000:]

    norm_rate=np.zeros((50,101,3000))
    for i in range(50):
        for j in range(3000):
            tmp=flt.gaussian_filter(rate[i,:,j],2)
            norm_rate[i,:,j]=tmp

    prj_dyn=np.zeros((50,101,2))
    for i in range(50):
        for j in range(101):
            for k in range(2):
                prj_dyn[i,j,k]=np.sum(QR[:,k]*norm_rate[i,j,:])
                
    return prj_dyn


def tmp15(prj,ipat,listL,listR,flg):
    c_set=["b","cyan","green","orange","magenta","red","black"]
    
    if flg==0:
        for i in range(20):
            pl.plot(prj[ipat,i,5:56,0],prj[ipat,i,5:56,1],c=c_set[ipat])
            pl.scatter(prj[ipat,i,5,0],prj[ipat,i,5,1],c=c_set[ipat],s=30,marker="o")
            pl.scatter(prj[ipat,i,30,0],prj[ipat,i,30,1],c=c_set[ipat],s=50,marker="D")
            pl.scatter(prj[ipat,i,55,0],prj[ipat,i,55,1],c=c_set[ipat],s=30,marker="x")
    elif flg==1:
        for i in listL:
            if(i>20):
                break
            pl.plot(prj[ipat,i,5:56,0],prj[ipat,i,5:56,1],c=c_set[ipat])
            pl.scatter(prj[ipat,i,5,0],prj[ipat,i,5,1],c=c_set[ipat],s=30,marker="o")
            pl.scatter(prj[ipat,i,30,0],prj[ipat,i,30,1],c=c_set[ipat],s=50,marker="D")
            pl.scatter(prj[ipat,i,55,0],prj[ipat,i,55,1],c=c_set[ipat],s=30,marker="x")

        for i in listR:
            if(i>20):
                break
            pl.plot(prj[ipat,i,5:56,0],prj[ipat,i,5:56,1],c=c_set[ipat],linewidth=2)
            pl.scatter(prj[ipat,i,5,0],prj[ipat,i,5,1],c=c_set[ipat],s=30,marker="o")
            pl.scatter(prj[ipat,i,30,0],prj[ipat,i,30,1],c=c_set[ipat],s=50,marker="D")
            pl.scatter(prj[ipat,i,55,0],prj[ipat,i,55,1],c=c_set[ipat],s=30,marker="x")

    return


def tmp16(prj):

    for i in range(20):
        pl.plot(prj[i,5:90,0],prj[i,5:90,1],c="gray")
        pl.scatter(prj[i,5,0],prj[i,5,1],c="black",s=30,marker="o")
        pl.scatter(prj[i,30,0],prj[i,30,1],c="black",s=50,marker="D")
        pl.scatter(prj[i,65,0],prj[i,65,1],c="black",s=30,marker="x")

    return

def tmp17(prj_no,prj,listL,listR,inet):
    tmp16(prj_no)
    pl.xlim(-15,15)
    pl.ylim(-5,15)
    pl.savefig("2Ddyn_noinp-inet%d.eps" %inet)
    pl.show()
    tmp15(prj,0,listL,listR,0)
    pl.xlim(-15,15)
    pl.ylim(-5,15)
    pl.savefig("2Ddyn_inp0-inet%d.eps" %inet)
    pl.show()
    tmp15(prj,6,listL,listR,0)
    pl.xlim(-15,15)
    pl.ylim(-5,15)
    pl.savefig("2Ddyn_inp6-inet%d.eps" %inet)
    pl.show()

    return


def tmp18(inet,ipat,prj,listL,listR):
    tmp15(prj,ipat,listL[ipat],listR[ipat],1)
    pl.xlim(-15,15)
    if(inet==25):
        pl.ylim(-5,15)
    elif(inet==20):
        pl.ylim(-15,5)
        
#    pl.savefig("2Ddyn_inp%d-inet%d.eps" %(ipat,inet))

    return




def tmp19(fda):
    beh_c=np.zeros(7)
    fda_c=np.zeros(7)

    beh_c=fda[:,2]/(fda[:,2]+fda[:,3])
    tmp=(fda[:,0]*fda[:,2]+fda[:,1]*fda[:,3])/(fda[:,2]+fda[:,3])

    for i in range(7):
        fda_c[i]=(tmp[i]-tmp[6])/((tmp[0]-tmp[6])/(beh_c[0]-beh_c[6]))+beh_c[6]

    beh_p=get_para(3,beh_c)
    fda_p=get_para(3,fda_c)
        
    return beh_c,fda_c,beh_p,fda_p




def fig1(inet1,inet2,fda):
    beh_c,fda_c,beh_p,fda_p = tmp19(fda[inet1-1])

    pl.subplot(2,2,1)
    pl.scatter(range(7),beh_c)
    pl.plot(np.arange(0,6.1,0.1),fit_func(beh_p,np.arange(0,6.1,0.1)))

    pl.subplot(2,2,2)
    pl.scatter(range(7),fda_c)
    pl.plot(np.arange(0,6.1,0.1),fit_func(fda_p,np.arange(0,6.1,0.1)))


    beh_c,fda_c,beh_p,fda_p = tmp19(fda[inet2-1])

    pl.subplot(2,2,3)
    pl.scatter(range(7),beh_c)
    pl.plot(np.arange(0,6.1,0.1),fit_func(beh_p,np.arange(0,6.1,0.1)))

    pl.subplot(2,2,4)
    pl.scatter(range(7),fda_c)
    pl.plot(np.arange(0,6.1,0.1),fit_func(fda_p,np.arange(0,6.1,0.1)))



    return



def tmp20(inet,Si,scl,GEfb,nsmp): # listL,R have index of trials with large difference between r0 and r1. 
    # without input
    npca=15
    init_smp=10
    endt_smp=61
    thr=0.05
    tbin=5
    
    tmp=get_rate_all([inet,-1,0.4,0.9,0.02,50])[:,:,2000:]
    rate=np.zeros((50,101,3000))
    for i in range(50):
        for j in range(3000):
            tmptmp=flt.gaussian_filter(tmp[i,:,j],2)
            rate[i,:,j]=tmptmp

    paras=[inet,-1,Si,scl,GEfb,nsmp,thr]
    tmp=get_behav1(paras)
    listL=tmp[1]
    listR=tmp[2]
    t_end=tmp[3]
            
    lam=np.zeros((3,11,3000))
    for j in range(11):
        smp_PCA=rate[:,init_smp+tbin*j,:].reshape(nsmp,3000)
        if len(listL) != 0:
            PCs=PCA(smp_PCA[listL])
            lam[0,j]=PCs[0]
        if len(listR) != 0:
            PCs=PCA(smp_PCA[listR])
            lam[1,j]=PCs[0]
        if len(listL+listR) != 0:
            PCs=PCA(smp_PCA[listR+listL])
            lam[2,j]=PCs[0]

    np.save("lam_noinput%d.npy" % inet,lam)
    return lam




def tmp21(suc_list,thrs):
    listL=[]
    listR=[]
    tend=[]
    vol=np.zeros((14,2))
    ttmp=np.zeros((14,3))

    for i in range(14):
        inet=suc_list[i]
        tmp=get_behav1([inet,-1,0.4,0.9,0.02,50,thrs])
        listL.append(tmp[1])
        listR.append(tmp[2])
        tend.append(tmp[3])

    for i in range(14):
        ttmp[i,0]=np.mean(np.array(tend)[i,np.array(listL[i]+listR[i])])
        vol[i,0]=len(listL[i])
        vol[i,1]=len(listR[i])
        if(vol[i,0]!=0):
            ttmp[i,1]=np.mean(np.array(tend)[i,np.array(listL[i])])
        if(vol[i,1]!=0):
            ttmp[i,2]=np.mean(np.array(tend)[i,np.array(listR[i])])


    return listL,listR,tend,vol,ttmp

