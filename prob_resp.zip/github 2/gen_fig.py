import numpy as np
import pylab as pl
from scipy import optimize


def get_file_name(inet,ipat,Si,scl,flg):
    if(flg==0):
        str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl)
    elif(flg==1):
        str="./Data/latest_ver/rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl)
    elif(flg==2):
        str="./Data/latest_ver/dbs56_fb_rnd_norm_%d-Si%g%g-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % (inet,Si,scl)
#        str="./Data/latest_ver/dbs56_fb_rnd_norm_%d-Si%g%g-0.03101000-500.0050.020.020.51.2.rnd.txt0_21hb205" % (inet,Si,scl)  // no nmda ver.

    return str


def calc_score_curve(list_net,Si,scl,ipat,Tlrn):
    ave_score=np.zeros((len(list_net),Tlrn))

    
    for itmp in range(len(list_net)):
        inet=list_net[itmp]
        str=get_file_name(inet,ipat,Si,scl,2)
        data=np.loadtxt(str)
    
        bin_size=20
        bin_prc=np.zeros(Tlrn)
        for i in range(Tlrn):
            if(data[i,2]>0):
                bin_prc[i]=1
            else:
                bin_prc[i]=0
            
    
        for i in range(Tlrn-bin_size):
            ave_score[itmp,i]=np.mean(bin_prc[i:i+bin_size])

    pl.plot(range(Tlrn-bin_size),ave_score[:5,0:(Tlrn-bin_size)].T,c="gray")
    pl.plot(range(Tlrn-bin_size),np.mean(ave_score[:,0:(Tlrn-bin_size)],axis=0),c="blue", linewidth=2)

    pl.savefig("lrn_curve_S%g.eps" % Si)
    pl.show()
    return



def gen_score(fda):
    nnet=len(fda)
    score=np.zeros(nnet)
    for i in range(nnet):
        score[i]=fda[i,0,2] + fda[i,6,3]

    return score


def get_score_hist(fda):
    nSi=len(fda)
    nnet=len(fda[0])
    score=np.zeros((nSi,nnet))
    for i in range(4):
        score[i]=gen_score(fda[i])


    for i in range(4):
        pl.subplot(2,2,i+1)
        pl.hist(score[i],bins=10,range=(50,100))
        pl.ylim(0,20)

    pl.savefig("score_hist.eps")
    pl.show()
    return

def get_suc_list(scoreL,scoreR):    

    suc_list=[]
    nnet=len(scoreL)
    for i in range(nnet):
        if(scoreL[i,0]>35 and scoreR[i,6]>35):
            suc_list.append(i+1)

    return suc_list


def get_fda_curve_pic(fda):

    nnet=len(fda)
    suc_list=get_suc_list(fda[:,:,2],fda[:,:,3])
            
    for i in range(len(suc_list)):
        if(len(suc_list)<10):
            pl.subplot(3,3,i+1)
        elif(len(suc_list)<=20):
            pl.subplot(4,5,i+1)
        elif(len(suc_list)<=30):
            pl.subplot(6,5,i+1)
            
        inet=suc_list[i]-1
        pl.plot(range(7),(fda[inet,:,2]/(fda[inet,:,2]+fda[inet,:,3]))*30-15)
        pl.plot(range(7),-1*(fda[inet,:,0]*fda[inet,:,2]+fda[inet,:,1]*fda[inet,:,3])/(fda[inet,:,2]+fda[inet,:,3]))

    pl.show()
    return




def fit_func(para,x):
    a=para[0]
    b=para[1]
    c=para[2]
#    d=para[3]
    #    return d*(np.tanh(-(x-a)*b)+c)
    return c*(np.tan(-(x*0.33-a))+b)
#    return c*(np.tan(-(x/2.0-a))+b)

def resid_fit(para,x,y):
    res=y-fit_func(para,x)
    return res


def calc_type_psy(beh):
    n_net=len(beh)
    n_para=3
    para=np.zeros((n_net,n_para))
    
    for j in range(n_net):
        para0=[1.1,0.4,1.1]
        res=optimize.leastsq(resid_fit,para0,args=(np.arange(7),beh[j,:]))
        para[j,:]=res[0]
    return para



def get_norm_beh_fda_curves(fda):
    nnet=len(fda)
    beh_c=np.zeros((nnet,7))
    fda_c=np.zeros((nnet,7))

    for i in range(nnet):
        beh_c[i,:]=fda[i,:,2]/(fda[i,:,2]+fda[i,:,3])
        tmp=-1*(fda[i,:,0]*fda[i,:,2]+fda[i,:,1]*fda[i,:,3])/(fda[i,:,2]+fda[i,:,3])
        fda_c[i]=(tmp-tmp[6])*((beh_c[i,0]-beh_c[i,6])/(tmp[0]-tmp[6]))+beh_c[i,6]

       
    return beh_c,fda_c


def plt_fitted_para(fda_tot):
    nSi=len(fda_tot)
    nnet=len(fda_tot[0])
    beh_c=np.zeros((nSi,nnet,7))
    fda_c=np.zeros((nSi,nnet,7))
    c_set=["blue","green","orange","red"]
    suc_list=[]
    
    for i in range(nSi):
        fda=fda_tot[i]
        beh_c[i],fda_c[i]=get_norm_beh_fda_curves(fda)
        para_beh=calc_type_psy(beh_c[i])
        para_fda=calc_type_psy(fda_c[i])

        
        suc_list.append(get_suc_list(fda[:,:,2],fda[:,:,3]))
        
        pl.scatter(para_beh[np.array(suc_list[i])-1,2],para_fda[np.array(suc_list[i])-1,2],c=c_set[i])

    pl.savefig("scatter_para_fda_beh.eps")
    pl.show()

    for i in range(nSi):
        for j in suc_list[i]:
            pl.scatter(beh_c[i,j-1,:],fda_c[i,j-1,:],c=c_set[i])
    pl.savefig("scatter_fda_beh.eps")
    pl.show()
    
    return
    
    
        
