import numpy as np
import pylab as pl
from scipy import linalg as LA
from scipy import optimize
from scipy import stats
from mpl_toolkits.mplot3d import Axes3D

from scipy.ndimage import filters as flt
import sys
import FDA 
reload(FDA)


def PCA(P):
    m = sum(P) / float(len(P))
    P_m = P - m
    l,v = np.linalg.eig( np.dot(P_m.T,P_m) )
    idx=l.argsort()
    l=l[idx][::-1]
    v=v[:,idx][:,::-1]
    return l,v.T



def get_file_name(flgs,paras):
    
    if flgs[0]=="normal":
        if len(paras)!=5:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl,GEfb)
        elif(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl,GEfb)
    elif flgs[0]=="many":
        if len(paras)!=5:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_many1_21hb205" % (inet,ipat,Si,scl,GEfb)
        elif(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_many1_21hb205" % (inet,ipat,Si,scl,GEfb)
    elif flgs[0]=="pert":
        if len(paras)!=6:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,str_pert]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
    elif flgs[0]=="pert_tmp":
        if len(paras)!=6:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,str_pert]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t200"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp1_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t150"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp2_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
    elif flgs[0]=="58":
        if(flgs[1]=="r"):
            [inet,ipat,GEfb]=paras
            str="rbr56_fb_rnd_norm%d-500_l%g0.40.9-0.03101000-500.0050.02%g0.51.2.rnd.txt1_11hb205" % (inet,ipat,GEfb)
#str="dbr58_fb_rnd_norm_%d100-Si0.40.9-0.03101000-500.0050.020.050.51.2.rnd.txt1_11hb205" % inet
    elif flgs[0]=="59":
        if(flgs[1]=="r"):
            [inet,igen]=paras
            str="dbr59_fb_rnd_norm_%d%d-Si0.40.9-0.03101000-500.0050.020.050.51.2.rnd.txt1_11hb205" % (inet,igen)
    elif flgs[0]=="511":
        if(flgs[1]=="r"):
            [inet,ipat]=paras
            str="rbr511_fb_rnd_norm%d-300_l%g0.40.9-0.03101000-500.0050.020.010.50.75.rnd.txt1_21hb2050.01" % (inet,ipat)

    return str


def get_rate_all(arg_paras):
    print "program check!!"
    return
    
    [inet,ipat,Si,scl,GEfb,nsmp,diff,flg,flg_spn,str_pert]=arg_paras
    cnt=0

    inv_bin_smp=0.1 #[ms-1]
    t_smp = 1000
    str=get_file_name([inet,ipat,Si,scl,GEfb,flg,str_pert]) #check point 2016/9/26
        
    n_bin      =int(t_smp*inv_bin_smp)
    rate_tmp=np.zeros((nsmp,n_bin+1,5000))
    
    tmp=np.loadtxt(str)
    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:
            cnt+=1
            if nsmp<=cnt:
                break
        if tmp[i,1]<5000:
            rate_tmp[cnt,int(tmp[i,0]*inv_bin_smp),tmp[i,1]]+=1

    return rate_tmp

def get_rate_all58(arg_paras):
    ncell=2400
    
    [model_ver,inet,nsmp,ipat,GEfb,igen,flg1]=arg_paras
    cnt=0

    inv_bin_smp=0.1 #[ms-1]
    t_smp = 1000
    if flg1=="d":
        str=get_file_name([model_ver,"r"],[inet,igen])
    elif flg1=="r": # rbr*
        str=get_file_name([model_ver,"r"],[inet,ipat])
    n_bin      =int(t_smp*inv_bin_smp)
    rate_tmp=np.zeros((nsmp,n_bin+1,ncell))

    tmp=np.loadtxt(str)
    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:
            cnt+=1
            if nsmp<=cnt:
                break
        if tmp[i,1]<ncell:
            rate_tmp[cnt,int(tmp[i,0]*inv_bin_smp),tmp[i,1]]+=1
    
    return rate_tmp




def get_rate_allnet(arg_paras):
    [Si,scl,GEfb,suc_list,n_smp,n_t_bin]=arg_paras
   
    for j in suc_list:
        rate=np.zeros((7,n_smp,n_t_bin+1,5000))
        for k in range(7):
            rate[k]=get_rate_all([j,0.1*k,Si,scl,GEfb,n_smp])
        np.save("rate%d-%g%g%g.npy" % (j,Si,scl,GEfb),rate)

    return



def get_behav1(flgs,paras):
    
    if flgs[1]=="spn":
        t_init_smp=0
        t_end_smp=1001
    else:
        t_init_smp=350
        t_end_smp=601
    
    if flgs[0]=="normal":
        if len(paras)!=7:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,nsmp,diff]=paras[:]
        str=get_file_name([flgs[0],"t"],[inet,ipat,Si,scl,GEfb])
        if str=="error in get_file_name!":
            return str
    elif flgs[0]=="pert_tmp":
        if len(paras)!=8:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,nsmp,diff,str_pert]=paras[:]
        if len(flgs)==3:
            str=get_file_name([flgs[0],flgs[2]],[inet,ipat,Si,scl,GEfb,str_pert])
        else:
            str=get_file_name([flgs[0],"t"],[inet,ipat,Si,scl,GEfb,str_pert])
        if str=="error in get_file_name!":
            return str
    else:
        print "check the function!"
        return
    
    # set parameters
    cnt=0
    behav_ind=np.zeros(nsmp)
    behav_list=[]
    colist=[]
    t_end=np.zeros(nsmp)
    state_end=np.zeros((nsmp,2))
    
    tmp=np.loadtxt(str)
    tmptmp=tmp[0,:3]
    
    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:  # detection of a new trial
            for j in range(len(tmptmp)):
                if tmptmp[j,1] - tmptmp[j,2]>diff:
                    t_end[cnt]=tmptmp[j,0]
                    behav_list.append(cnt)
                    break
                elif tmptmp[j,2] - tmptmp[j,1]>diff:
                    t_end[cnt]=tmptmp[j,0]
                    colist.append(cnt)
                    break
        
            state_end[cnt][0]=tmptmp[j,1]
            state_end[cnt][1]=tmptmp[j,2]
        
            tmptmp=tmp[i,:3]
            cnt+=1
            if cnt>=nsmp:
                break
        
        elif i>0:  # store a trajectory of a al in tmptmp
            tmptmp=np.vstack((tmptmp,tmp[i,:3]))
    
    
    if cnt<=nsmp-1:
        for j in range(len(tmptmp)):
            if tmptmp[j,1] - tmptmp[j,2]>diff:
                t_end[cnt]=tmptmp[j,0]
                behav_list.append(cnt)
                break
            elif tmptmp[j,2] - tmptmp[j,1]>diff:
                t_end[cnt]=tmptmp[j,0]
                colist.append(cnt)
                break
        state_end[cnt][0]=tmptmp[j,1]
        state_end[cnt][1]=tmptmp[j,2]
    return behav_ind,behav_list,colist,t_end,state_end



def get_pca_dyn(inet,Si,scl,GEfb,nsmp,npca,init_smp,endt_smp):
    tbin=5
    if init_smp>=endt_smp-tbin:
        exit()

    rate=np.load("rate%d-%g%g%g.npy" % (inet,Si,scl,GEfb))
#    rate=np.load("rate%d-%g.npy" % (inet,Si))
    smp_PCA=np.mean(rate[:,:,init_smp:init_smp+tbin,2000:],axis=2).reshape(7*nsmp,3000)

    for i in range(init_smp+1,endt_smp-tbin):
        smp_PCA=np.vstack((smp_PCA,np.mean(rate[:,:,i:i+tbin,2000:],axis=2).reshape(7*nsmp,3000)))

    PCs=PCA(smp_PCA)
    PCA_dyn=np.zeros((7,nsmp,endt_smp-init_smp,npca))

    for i in range(7):
        for j in range(nsmp):
             for k in range(npca):
                 PCA_dyn[i,j,:,k]=np.mean((PCs[1][k,:].reshape(3000,1))*(rate[i,j,init_smp:endt_smp,2000:].T),axis=0)


    PCA_dyn_ave=np.zeros((7,nsmp,endt_smp-init_smp,npca))
    for i in range(7):
        for j in range(nsmp):
            for k in range(0,endt_smp-tbin-init_smp):
                PCA_dyn_ave[i,j,k,:]=np.mean(PCA_dyn[i,j,k:k+tbin,:],axis=0)

    return PCA_dyn,PCA_dyn_ave



# modified on 16.12.2015
def get_pca_fda2(inet,Si,scl,GEfb,nsmp): # listL,R have index of trials with large difference between r0 and r1. 
    npca=15
    init_smp=10
    endt_smp=61
    thr=0.03
    
    PCA_dyn,PCA_dyn_ave=get_pca_dyn(inet,Si,scl,GEfb,nsmp,npca,init_smp,endt_smp)

    listL=[]
    listR=[]
    t_end=[]
    for i in range(7):
        paras=[inet,0.1*i,Si,scl,GEfb,nsmp,thr]
        tmp=get_behav1(paras)
        listL.append(tmp[1])
        listR.append(tmp[2])
        t_end.append(tmp[3])

    #        fda_pca_ave[ipat,0]=np.mean(fda_pca[ipat,idx_L[ipat],(t_end[ipat][listL[ipat][:len(idx_L[ipat])]]/10.-5).astype(np.int64),0])
    # get discriminant plane from neural activity patterns for ipat=0 and 6
    if(len(listL[0])+len(listL[6])<=1 or len(listR[0])+len(listR[6])<=1):
        sys.stderr.write("FDA is invalid! no success trial in inet %d" % inet)
        return 1
        
    ipat=0
    data1=(PCA_dyn_ave[ipat,listL[ipat],list((np.array(t_end[ipat][listL[ipat]])/10.0-init_smp).astype(np.int64)),:]).T
    data2=(PCA_dyn_ave[ipat,listR[ipat],list((np.array(t_end[ipat][listR[ipat]])/10.0-init_smp).astype(np.int64)),:]).T
    
    ipat=6
    data1=np.hstack((data1,(PCA_dyn_ave[ipat,listL[ipat],list((np.array(t_end[ipat][listL[ipat]])/10.0-init_smp).astype(np.int64)),:]).T))
    data2=np.hstack((data2,(PCA_dyn_ave[ipat,listR[ipat],list((np.array(t_end[ipat][listR[ipat]])/10.0-init_smp).astype(np.int64)),:]).T))
    

    flg,J,Wopt,non_zero_cell=FDA.FDA2(data1,data2,range(npca),npca)

    if(flg==1):
        sys.stderr.write("FDA(Wopt) is invalid! inet %d" % inet)
        return 1
    
    # in terms of stimulus
    data1=PCA_dyn[0,:,10,:].T
    data2=PCA_dyn[6,:,10,:].T
    flg,J,Wopt1,non_zero_cell=FDA.FDA2(data1,data2,range(npca),npca)
    if(flg==1):
        sys.stderr.write("FDA(Wopt1) is invalid! inet %d" % inet)
        return 1

    # get fda dynamics
    fda_pca=np.zeros((7,nsmp,endt_smp-init_smp,2))

    for i in range(7):
        for j in range(nsmp):
             fda_pca[i,j,:,0]=np.dot(Wopt.T,PCA_dyn_ave[i,j,:,:].T)
             fda_pca[i,j,:,1]=np.dot(Wopt1.T,PCA_dyn_ave[i,j,:,:].T)
             
    fda_pca_ave=np.zeros((7,2))
    for ipat in range(7):
        if(len(listL[ipat])!=0):
            fda_pca_ave[ipat,0]=np.mean(fda_pca[ipat,listL[ipat],list((np.array(t_end[ipat][listL[ipat]])/10.0-init_smp).astype(np.int64)),0])
        else:
            fda_pca_ave[ipat,0]=0
        if(len(listR[ipat])!=0):
            fda_pca_ave[ipat,1]=np.mean(fda_pca[ipat,listR[ipat],list((np.array(t_end[ipat][listR[ipat]])/10.0-init_smp).astype(np.int64)),0])
        else:
            fda_pca_ave[ipat,1]=0


    return fda_pca_ave,fda_pca,Wopt,Wopt1,PCA_dyn_ave,listL,listR,t_end



def get_fda_curve_pic(fda,suc_list):

    for i in range(len(suc_list)):
        pl.subplot(4,5,i+1)
        inet=suc_list[i]-1
        pl.plot(range(7),(fda[inet,:,2]/(fda[inet,:,2]+fda[inet,:,3]))*30-15)
        pl.plot(range(7),-1*(fda[inet,:,0]*fda[inet,:,2]+fda[inet,:,1]*fda[inet,:,3])/(fda[inet,:,2]+fda[inet,:,3]))

    pl.show()
    return

"""
def fit_func(para,x):
    a=para[0]
    b=para[1]
    c=para[2]
#    d=para[3]
    #    return d*(np.tanh(-(x-a)*b)+c)
    return c*(np.tan(-(x*0.33-a))+b)
#    return c*(np.tan(-(x/2.0-a))+b)

def resid_fit(para,x,y):
    res=y-fit_func(para,x)
    return res


def calc_type_psy(beh):
    n_Si=len(beh)
    n_net=len(beh[0])
    n_para=3
    para=np.zeros((n_Si,n_net,n_para))
    
    for i in range(n_Si):
        for j in range(n_net):
            para0=[1.1,0.4,1.1]
            res=optimize.leastsq(resid_fit,para0,args=(np.arange(7),beh[i,j,:]))
            para[i,j,:]=res[0]
    return para
"""

def show_pic(suc_list,para,beh):
    for i in range(len(suc_list)):
        pl.subplot(3,3,i+1)
        inet=suc_list[i]
        pl.scatter(range(7),beh[inet-1,:])
        pl.plot(np.arange(0,6,0.01),fit_func(para[inet-1],np.arange(0,6,0.01)))

    return




def get_zscored_dyn(dyn,listL,listR):
    ave_tmp=np.mean(dyn,axis=(0,1,2))
    dev_tmp=np.std(dyn,axis=(0,1,2))
    n_trial=0
    for i in range(7):
        n_trial+=(len(listL[i])+len(listR[i]))
        
    norm_dyn=np.zeros((n_trial,61,3000))

    cnt=0
    for i in range(7):
        for j in range(len(listL[i])):
            for k in range(3000):
                norm_dyn[cnt+j,:,k]=(dyn[i,listL[i][j],:,k]-ave_tmp[k])/dev_tmp[k]
        cnt+=len(listL[i])
        for j in range(len(listR[i])):
            for k in range(3000):
                norm_dyn[cnt+j,:,k]=(dyn[i,listR[i][j],:,k]-ave_tmp[k])/dev_tmp[k]
        cnt+=len(listR[i])
            

    return norm_dyn




def gen_zscored_ave_dyn(rate,listL,listR):

    cond_dyn=np.zeros((7,2,61,3000))
 
    for ipat in range(7):
        cond_dyn[ipat,0,:,:]=np.mean(rate[ipat,listL[ipat],:,2000:],axis=0)
        cond_dyn[ipat,1,:,:]=np.mean(rate[ipat,listR[ipat],:,2000:],axis=0)

 
    flt_dyn=np.zeros((7,2,61,3000))
    for i in range(7):
        for j in range(2):
            for k in range(3000):
                flt_dyn[i,j,:,k]=flt.gaussian_filter(cond_dyn[i,j,:,k],2)

                
    norm_dyn=np.zeros((7,2,61,3000))
    for i in range(7):
        for j in range(2):
            for k in range(3000):
                norm_dyn[i,j,:,k]=(flt_dyn[i,j,:,k]-np.mean(flt_dyn[:,:,:,k]))/(np.std(flt_dyn[:,:,:,k]))

    return norm_dyn


def main():
    fda_dyn15=get_pca_fda2(15,0.4,0.9,0.02,50) 
 
    rate15=np.load("rate15-0.40.90.02.npy")
    norm_dyn=gen_zscored_ave_dyn(rate15,fda_dyn15[5],fda_dyn15[6])


                
    n_trial=0
    for i in range(7):
        n_trial+=len(fda_dyn15[5][i])+len(fda_dyn15[6][i])

    tmp1=[]
    for i in range(7):
        for j in range(len(fda_dyn15[5][i])):
            tmp=np.zeros(3)
            tmp[0]=1
            tmp[1]=(i-3.0)/3.
            tmp[2]=1
            tmp1.append(tmp)
        for j in range(len(fda_dyn15[6][i])):
            tmp=np.zeros(3)
            tmp[0]=-1
            tmp[1]=(i-3.0)/3.
            tmp[2]=1
            tmp1.append(tmp)

    tmp1=np.array(tmp1)
    F=tmp1.T



 
 
    gaus_dyn15=np.zeros((7,50,61,3000))
    for i in range(7):
        for j in range(50):
            for k in range(3000):   
                gaus_dyn15[i,j,:,k]=flt.gaussian_filter(rate15[i,j,:,k+2000],2)
 
 
    norm_r15=gr.get_zscored_dyn(gaus_dyn15,fda_dyn15[5],fda_dyn15[6])
    beta=np.zeros((3,61,3000))
    for i in range(61):
        for j in range(3000):
            beta[:,i,j]=np.dot(np.dot(F,F.T),np.dot(F,norm_r15[:,i,j]))
 
def get_rnet(inet,cellidx):
    tmp=np.loadtxt("dbrnet56_fb_rnd_norm_%d-Si0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt0_21hb205" %inet)
    tmpmat=np.zeros((6000,6000))
    for i in range(len(tmp)):
        tmpmat[tmp[i,1]][tmp[i,0]]=tmp[i,2]

    return tmpmat[cellidx][:,cellidx]

def get_Wcore(inet,flg,t_dec):
    Si=0.4
    scl=0.9
    GEfb=0.02
    if flg==0:   # obtain from evoked activity
        rate=np.load("rate%d-%g%g%g.npy" % (inet,Si,scl,GEfb))
        cell_list=np.argsort(np.mean(rate[6,:,10:30,2000:]+rate[0,:,10:30,2000:],axis=(0,1)))
    else:
        rate=np.load("rate_spn%d-%g%g%g.npy" % (inet,Si,scl,GEfb))
        tmprate=np.zeros(3000)
        for i in range(len(t_dec)):
            tmprate[:]=tmprate[:]+np.mean(rate[i,t_dec[i]/10-10:t_dec[i]/10,2000:])
        cell_list=np.argsort(tmprate)

    Wr=get_rnet(inet,np.array(cell_list[-500:])+2000)

    return Wr


def get_pca_dim(inet):
    nsmp=500
    npca=nsmp
    rate=np.load("rate_spn_many%d-0.40.90.02.npy" % inet)
    beh=get_behav1([inet,-1,0.4,0.9,0.02,nsmp,0.05,3])
    pccurve=np.zeros((2,5,npca))
    for i in range(5):
        tmp=stats.zscore(np.mean(rate[beh[1][:200],i*10:i*10+5,2000:],axis=1),axis=1)
        pca_dim=PCA(tmp)[0]
        pccurve[0,i]=pca_dim[:npca]
        #pccurve[0,i]=(np.cumsum(pca_dim)/np.sum(pca_dim))[:50]
        #tmp=stats.zscore(np.mean(rate[,i*10:i*10+5,2000:],axis=1),axis=1)
        #pca_dim=PCA(tmp)[0]
        #pccurve[1,i]=pca_dim[:npca]
    #pccurve[1,i]=(np.cumsum(pca_dim)/np.sum(pca_dim))[:50]

    return pccurve


def get_pca_dyn2(inet):
    npca=10
    
    # make smp for PCA
    rate=np.load("rate_spn%d-0.40.90.02.npy" % inet)
    rate_ave=np.zeros((50,20,3000))
    for i in range(20):
        rate_ave[:,i,:]=np.mean(rate[:,i*5:(i+1)*5,2000:],axis=1)
    behtmp=get_behav1([11,-1,0.4,0.9,0.02,50,0.08,1,1])

    tmp=[i for i in range(50) if behtmp[3][i]<=0.00001]
    behtmp[3][tmp]=behtmp[3][tmp]+1001

    tmp=rate[0,:np.int(behtmp[3][0]/50),2000:]
    for i in range(1,50):
        tmp=np.vstack((tmp,rate_ave[i,:np.int(behtmp[3][i]/50),:]))

#pc=PCA(tmp)[1]

    # gen pc-projected dyn
    """
    pca_dyn=np.zeros((50,20,npca))
    for i in range(npca):
        for j in range(50):
            for k in range(20):
                pca_dyn[j,k,i]=np.mean(pc[i,:]*rate_ave[j,k,:])
    """
# calc velocity at diff=0.05
    behtmp=get_behav1([inet,-1,0.4,0.9,0.02,50,0.05,1,1])
    vel=np.zeros(50)
    var_rate=np.zeros(50)
    rate_ave1=np.zeros((50,101-5))
    for i in range(101-5):
        rate_ave1[:,i]=np.mean(rate[:,i:i+5,2000:],axis=(1,2))
    
    for i in range(50):
        if behtmp[3][i]>950:
            var_rate[i]=np.std(np.mean(rate[i,:95,2000:],axis=1)/rate_ave1[i,:95]-1)
        else:
            var_rate[i]=np.std(np.mean(rate[i,:np.int(behtmp[3][i]/10),2000:],axis=1)/rate_ave1[i,:np.int(behtmp[3][i]/10)]-1)

        if behtmp[3][i]>0.0001:
            if np.int(behtmp[3][i]/50)>=19:
                tmp=rate_ave[i,np.int(behtmp[3][i]/50),:]-rate_ave[i,np.int(behtmp[3][i]/50)-2,:]
            #            tmp=pca_dyn[i,np.int(behtmp[3][i]/50),:]-pca_dyn[i,np.int(behtmp[3][i]/50)-1,:]
            else:
                tmp=rate_ave[i,np.int(behtmp[3][i]/50)+1,:]-rate_ave[i,np.int(behtmp[3][i]/50)-1,:]
            #                tmp=pca_dyn[i,np.int(behtmp[3][i]/50)+1,:]-pca_dyn[i,np.int(behtmp[3][i]/50),:]
            vel[i]=np.sqrt(np.sum(tmp*tmp))

    return var_rate,vel,behtmp

def get_locality_dyn(inet):
    rate=np.load("rate_spn%d-0.40.90.02.npy" % inet)
    behtmp=get_behav1([inet,-1,0.4,0.9,0.02,50,0.05,1,1])

    rate_ave=np.zeros((50,20,3000))
    for i in range(20):
        rate_ave[:,i,:]=np.mean(rate[:,i*5:(i+1)*5,2000:],axis=1)

    tmp=rate_ave*rate_ave
    tmp2=tmp*tmp
    loc_rate=np.sum(tmp2,axis=2)/(np.sum(tmp,axis=2)*np.sum(tmp,axis=2))
    loc_sort=np.zeros((50,40))

    for i in behtmp[1]:
        tmp_t=np.argmax(loc_rate[i,:])
        loc_sort[i,20-tmp_t:40-tmp_t]=loc_rate[i,:]

    for i in behtmp[2]:
        tmp_t=np.argmax(loc_rate[i,:])
        loc_sort[i,20-tmp_t:40-tmp_t]=loc_rate[i,:]

    return loc_sort,behtmp



def get_behav2(flgs,paras):  # check end time by >0.01  (not decision timing)
    
    if flgs[1]=="spn":
        t_init_smp=0
        t_end_smp=1001
    else:
        t_init_smp=350
        t_end_smp=601
    
    if flgs[0]=="normal":
        if len(paras)!=7:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,nsmp,diff]=paras[:]
        str=get_file_name([flgs[0],"t"],[inet,ipat,Si,scl,GEfb])
        if str=="error in get_file_name!":
            return str
    elif flgs[0]=="pert_tmp":
        if len(paras)!=8:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,nsmp,diff,str_pert]=paras[:]
        if len(flgs)==3:
            str=get_file_name([flgs[0],flgs[2]],[inet,ipat,Si,scl,GEfb,str_pert])
        else:
            str=get_file_name([flgs[0],"t"],[inet,ipat,Si,scl,GEfb,str_pert])
        if str=="error in get_file_name!":
            return str
    else:
        print "check the function!"
        return
    
    # set parameters
    cnt=0
    tbin=10.0
    behav_ind=np.zeros(nsmp)
    behav_list=[]
    colist=[]
    t_end=np.ones(nsmp)*t_end_smp
    state_end=np.zeros((nsmp,2))
    
    tmp=np.loadtxt(str)
    tmptmp=tmp[0,:3]


    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:  # detection of a new trial
            for j in range(len(tmptmp)):
                if tmptmp[j,1]>0.099:
                    t_end[cnt]=tmptmp[j,0]
                    behav_list.append(cnt)
                    break
                elif tmptmp[j,2]>0.099:
                    t_end[cnt]=tmptmp[j,0]
                    colist.append(cnt)
                    break
            
            tmptmp=tmp[i,:3]
            cnt+=1
            if cnt>=nsmp:
                break
        
        elif i>0:  # store a trajectory of a trial in tmptmp
            tmptmp=np.vstack((tmptmp,tmp[i,:3]))
    
    
    if cnt<=nsmp-1:
        for j in range(len(tmptmp)):
            if tmptmp[j,1]>0.099:
                t_end[cnt]=tmptmp[j,0]
                behav_list.append(cnt)
                break
            elif tmptmp[j,2]>0.099:
                t_end[cnt]=tmptmp[j,0]
                colist.append(cnt)
                break
    del tmp
    
    return behav_ind,behav_list,colist,t_end



def get_flt_tmp(dyn):
    ismp=len(dyn)
    th_l=1
    th_h=3
    tmpdyn=np.zeros(dyn.shape)
    for i in range(ismp):
        if dyn[i]<1:
            tmpdyn[i]=0
        elif dyn[i]>3:
            tmpdyn[i]=2
        else:
            tmpdyn[i]=dyn[i]-1

    return tmpdyn



def get_pca_dyn3(inet,str_pert):
    tmp=get_rate_all([inet,-1,0.4,0.9,0.02,31*21,0.05,4,1,str_pert])[:,:,2000:]

#get PCs
    rate11=tmp[::31,:,:]
    ord11=np.argsort(np.mean(rate11,axis=(0,1)))
    
    tmpbeh=get_behav2([inet,-1,0.4,0.9,0.02,31*21,0.05,5,1,str_pert])
    smp=rate11[0,:int(tmpbeh[3][0]/10),ord11[-100:]].T
    for i in range(1,len(rate11)):
        smp=np.vstack((smp,rate11[i,:int(tmpbeh[3][i*31]/10),ord11[-100:]].T))
    pc11=PCA(smp)

    tmptmp=np.zeros((21*31,66,100))
    tmptmp=tmp[:,:66,ord11[-100:]]
    for i in range(21):
        for j in range(10):
            tmptmp[i*31+j+1,:10,:]=tmp[i*31,:10,ord11[-100:]].T
            tmptmp[i*31+j+11,:20,:]=tmp[i*31,:20,ord11[-100:]].T
            tmptmp[i*31+j+21,:30,:]=tmp[i*31,:30,ord11[-100:]].T
    flt_dyn=np.zeros((21*31,61,100))
    for i in range(21*31):
        for j in range(100):
            for k in range(61):
                flt_dyn[i,k,j]=np.mean(tmptmp[i,k:k+5,j])

    pc_dyn=np.zeros(flt_dyn.shape)
    for i in range(21*31):
        for j in range(10):
            pc_dyn[i,:,j]=np.dot(flt_dyn[i,:61,:],pc11[1][j,:])

    prob2D=np.zeros((3,21))
    tmp=get_behav1([inet,-1,0.4,0.9,0.02,31*21,0.05,5,1,str_pert])
    for i in range(3):
        for j in range(21):
            tmp1=[j for k in range(1+10*i+31*j,1+10*(i+1)+31*j) if k in tmp[1] ]
            tmp2=[j for k in range(1+10*i+31*j,1+10*(i+1)+31*j) if k in tmp[2] ]
            prob2D[i,j]=(len(tmp1))/float(len(tmp1)+len(tmp2))

    return pc_dyn,prob2D



"""
para0=[-2,1]
def fit_func(para,x):
    a=para[0]
    b=para[1]
    c=1.0/(np.tan(b)-np.tan(a+b))
    d=-np.tan(a+b)
    return c*(np.tan(a*x/6.+b)+d)
"""

"""
        para0=[5,-0.5,0.5]
def fit_func(para,x):
    a=para[2]
    b=para[0]
    c=para[1]
    return a*(-1*np.tanh(b*(x/6.+c))+1)
    
    
    def resid_fit(para,x,y):
    res=y-fit_func(para,x)+0.05*np.sign(y-fit_func(para,x))*np.abs(para[2]-0.5)
    return res
"""

def fit_func(para,x):
    a=para[0]
    b=para[1]
    c=para[2]
    return c*(np.tan((x/3.-a))+b)


def resid_fit(para,x,y):
    res=y-fit_func(para,x)
    return res

def calc_type_psy(beh):
    
    para0=[1.1,10,0.5]
    res=optimize.leastsq(resid_fit,para0,args=(np.arange(7),beh[:]))
    return res[0],np.mean(np.abs(resid_fit(res[0],np.arange(7),beh[:])))


def comp_dyn(inet):
    rate3=np.load("rate_spn%d-0.40.90.02.npy" % inet)[:,:,2000:]
    ord3=np.argsort(np.mean(rate3,axis=(0,1)))
    tmpbeh=get_behav2(["normal","spn"],[3,-1,0.4,0.9,0.02,50,0.05])
    smp=rate3[0,:int(tmpbeh[3][0]/10),ord3[-100:]].T
    for i in range(1,len(rate3)):
        smp=np.vstack((smp,rate3[i,:int(tmpbeh[3][i]/10),ord3[-100:]].T))
    pc3=PCA(smp)

    pca_dyn3=np.zeros((50,101,10))
    for i in range(50):
        ratetmp=np.zeros((101,100))
        for k in range(100):
            ratetmp[:,k]=flt.gaussian_filter(rate3[i,:,ord3[-100+k]],2)
        for k in range(10):
            pca_dyn3[i,:,k]=np.dot(pc3[1][k,:],ratetmp[:,:].T)


    rate=np.load("rate%d-0.40.90.02.npy" % inet)[:,:,:,2000:]
    pca_dyn_evk=np.zeros((7,50,61,10))
    for i in range(50):
        for j in range(7):
            ratetmp=np.zeros((61,100))
            for k in range(100):
                ratetmp[:,k]=flt.gaussian_filter(rate[j,i,:,ord3[-100+k]],2)
            for k in range(10):
                pca_dyn_evk[j,i,:,k]=np.dot(pc3[1][k,:],ratetmp[:,:].T)

    return pca_dyn3,pca_dyn_evk

def get_rate_spn(inet):
    nsmp=500
    tmp=get_rate_all([inet,-1,0.4,0.9,0.02,nsmp])
    np.save("rate_spn_many%d-%g%g%g.npy" % (inet,0.4,0.9,0.02),tmp)
    return


def tmp_gen_fig(pca_dyn3,pca_dyn_evk,beh,spnbeh):
    

    pl.subplot(3,2,1)
    for i in range(50):
        if i in spnbeh[1]:
            pl.plot(pca_dyn3[i,:61,0],pca_dyn3[i,:61,1],c="b",alpha=0.1)
        elif i in spnbeh[2]:
            pl.plot(pca_dyn3[i,:61,0],pca_dyn3[i,:61,1],c="r",alpha=0.1)
    for i in range(20):
        ipat=2
        if i in beh[ipat][0]:
            pl.plot(pca_dyn_evk[ipat,i,10:31,0],pca_dyn_evk[ipat,i,10:31,1],c="b")
        if i in beh[ipat][1]:
            pl.plot(pca_dyn_evk[ipat,i,10:31,0],pca_dyn_evk[ipat,i,10:31,1],c="r")
    pl.scatter(pca_dyn_evk[ipat,:20,10,0],pca_dyn_evk[ipat,:20,10,1],c="magenta")
    pl.scatter(pca_dyn_evk[ipat,:20,30,0],pca_dyn_evk[ipat,:20,30,1],c="cyan")
    pl.xlim(-5,5)
    pl.ylim(-3,0)
    pl.subplot(3,2,3)
    for i in range(50):
        if i in spnbeh[1]:
            pl.plot(pca_dyn3[i,:61,0],pca_dyn3[i,:61,1],c="b",alpha=0.1)
        elif i in spnbeh[2]:
            pl.plot(pca_dyn3[i,:61,0],pca_dyn3[i,:61,1],c="r",alpha=0.1)
    for i in range(20):
        ipat=4
        if i in beh[ipat][0]:
            pl.plot(pca_dyn_evk[ipat,i,10:31,0],pca_dyn_evk[ipat,i,10:31,1],c="b")
        if i in beh[ipat][1]:
            pl.plot(pca_dyn_evk[ipat,i,10:31,0],pca_dyn_evk[ipat,i,10:31,1],c="r")
    pl.scatter(pca_dyn_evk[ipat,:20,10,0],pca_dyn_evk[ipat,:20,10,1],c="magenta")
    pl.scatter(pca_dyn_evk[ipat,:20,30,0],pca_dyn_evk[ipat,:20,30,1],c="cyan")
    pl.xlim(-5,5)
    pl.ylim(-3,0)
    pl.subplot(3,2,5)
    for i in range(50):
        if i in spnbeh[1]:
            pl.plot(pca_dyn3[i,:61,0],pca_dyn3[i,:61,1],c="b",alpha=0.1)
        elif i in spnbeh[2]:
            pl.plot(pca_dyn3[i,:61,0],pca_dyn3[i,:61,1],c="r",alpha=0.1)
    for i in range(20):
        ipat=0
        if i in beh[ipat][0]:
            pl.plot(pca_dyn_evk[ipat,i,10:31,0],pca_dyn_evk[ipat,i,10:31,1],c="b")
        if i in beh[ipat][1]:
            pl.plot(pca_dyn_evk[ipat,i,10:31,0],pca_dyn_evk[ipat,i,10:31,1],c="r")
    pl.scatter(pca_dyn_evk[ipat,:20,10,0],pca_dyn_evk[ipat,:20,10,1],c="magenta")
    pl.scatter(pca_dyn_evk[ipat,:20,30,0],pca_dyn_evk[ipat,:20,30,1],c="cyan")
    pl.xlim(-5,5)
    pl.ylim(-3,0)
    pl.subplot(3,2,2)
    for i in range(50):
        if i in spnbeh[1]:
            pl.plot(pca_dyn3[i,:61,0],pca_dyn3[i,:61,1],c="b",alpha=0.1)
        elif i in spnbeh[2]:
            pl.plot(pca_dyn3[i,:61,0],pca_dyn3[i,:61,1],c="r",alpha=0.1)
    for i in range(20):
        ipat=2
        if i in beh[ipat][0]:
            pl.plot(pca_dyn_evk[ipat,i,30:,0],pca_dyn_evk[ipat,i,30:,1],c="b")
        if i in beh[ipat][1]:
            pl.plot(pca_dyn_evk[ipat,i,30:,0],pca_dyn_evk[ipat,i,30:,1],c="r")
    pl.subplot(3,2,4)
    for i in range(50):
        if i in spnbeh[1]:
            pl.plot(pca_dyn3[i,:61,0],pca_dyn3[i,:61,1],c="b",alpha=0.1)
        elif i in spnbeh[2]:
            pl.plot(pca_dyn3[i,:61,0],pca_dyn3[i,:61,1],c="r",alpha=0.1)
    for i in range(20):
        ipat=4
        if i in beh[ipat][0]:
            pl.plot(pca_dyn_evk[ipat,i,30:,0],pca_dyn_evk[ipat,i,30:,1],c="b")
        if i in beh[ipat][1]:
            pl.plot(pca_dyn_evk[ipat,i,30:,0],pca_dyn_evk[ipat,i,30:,1],c="r")
    pl.subplot(3,2,6)
    for i in range(50):
        if i in spnbeh[1]:
            pl.plot(pca_dyn3[i,:61,0],pca_dyn3[i,:61,1],c="b",alpha=0.1)
        elif i in spnbeh[2]:
            pl.plot(pca_dyn3[i,:61,0],pca_dyn3[i,:61,1],c="r",alpha=0.1)
    for i in range(20):
        ipat=0
        if i in beh[ipat][0]:
            pl.plot(pca_dyn_evk[ipat,i,30:,0],pca_dyn_evk[ipat,i,30:,1],c="b")
        if i in beh[ipat][1]:
            pl.plot(pca_dyn_evk[ipat,i,30:,0],pca_dyn_evk[ipat,i,30:,1],c="r")
    
    return



num_loop_pval_thres.eps
-rw-r--r--  1 kurikawa  staff    16K  3  6 18:47 num_loop_sens_nets.eps
-rw-r--r--  1 kurikawa  staff    25K  3  6 18:45 Wout_fb_loop-inet7.eps
-rw-r--r--  1 kurikawa  staff    16K  3  6 18:06 diff_wout-sens.eps


"""
for i in range(30):
    Wtmp[i]=(np.cumsum(np.sum(Wr[i,-50:,-20:],axis=0)[::-1],axis=0)/np.sum(Wr[i,-50:,-20:]))
"""