import numpy as np
import pylab as pl

def get_rate_trial_ext(inet,ipat,Si,nsmp,rex,spn_evk):
    cnt=0
    scl=0.9

    inv_bin_smp=0.1 #[ms-1]
    if spn_evk == 1:
        t_smp = 400
        str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.01532000-200.010.5.rnd.txt1_0hb1070" %(inet,ipat,Si,scl)  

    n_bin      =int(t_smp*inv_bin_smp)
    rate_tmp=np.zeros((nsmp,n_bin+1,5000))


    tmp=np.loadtxt(str)
    for i in range(len(tmp[:,0])):
        if i>0 and tmp[i,0]<tmp[i-1,0]:
            cnt+=1
            if nsmp<=cnt:
                break
        if tmp[i,1]<5000:
            rate_tmp[cnt,int(tmp[i,0]*inv_bin_smp),tmp[i,1]]+=1

    return rate_tmp






def get_rate_allnet(Si):
    n_smp=100
    i_Si=1

    #>75% nets only
    suc_list=[]
    if(Si==0.5):
        suc_list=[2,3,4,6,8,10,11,12,14,15,16,20]
#        suc_list=[1]

    for j in suc_list:
        rate=np.zeros((7,n_smp,41,5000))
        for k in range(7):
            rate[k]=get_rate_trial_ext(j,0.1*k,0.5,n_smp,20,1)
        np.save("rate1070%d-%g.npy" % (j,0.5),rate)

    return



#### main
get_rate_allnet(0.5)
exit()

