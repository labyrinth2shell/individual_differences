import numpy as np
import pylab as pl

import gen_fig_rnd as gr

import sys

argvs = sys.argv
Si=float(argvs[1])


n_smp=1000
s_rate=0.6
n_dim=1100
diff=0.02
n_net=30



if Si==0.4:
    suc_list=[2,3,4,6,7,8,9,10,13,16,18,22,23,24,25,30]


fda_dyn,distr,t_end,listL,listR=gr.get_FDA_dyn1(suc_list,Si,n_smp,n_dim,diff,1)


strtmp="fda_dyn_inp%g.npy" % Si
np.save(strtmp,fda_dyn)


for j in range(len(suc_list)):
    strtmp="distr_inp%g-%d.npy" % (Si,suc_list[j])
    np.save(strtmp,distr[j])
