import numpy as np
import matplotlib.pyplot as pl
import gen_fig_rnd as gr
import func as fc
import for_paper as fp
import sys

def tmp_gen_fig(max_out,Kdcy,ver):
    amp=2000
    scl=1.2
    for inet in range(1,11):
        pl.subplot(4,3,inet)
        str="dbd56_fb_rnd_norm_%d-Si0.3%g-%g%d%d-200.010.5.rnd.txt1_0hb%d70" % (inet,scl,max_out,Kdcy,amp,ver)
        wgt=np.loadtxt(str)[-3000:,:]
        rank=np.argsort(wgt[:,2])
        rank1=np.argsort(wgt[:,3])
        pl.plot(range(500),wgt[rank[-500:],2])
        pl.plot(range(500),wgt[rank1[-500:],3],c="r")
        pl.xlim(-10,510)
        pl.ylim(0,0.02)

    pl.savefig("%g_%g%d%d-%d.eps" % (scl,max_out,Kdcy,amp,ver))
    return()




"""
argv=sys.argv

gr.get_gen_wgt_fig(argv[1])
exit()

tmp_gen_fig(float(argv[1]),int(argv[2]),int(argv[3]))
exit()

    
nsmp=100
Si=0.5
i_Si=int(round(Si/0.1-3,1))


list_suc=[]
beh=np.load("beh0.051000.npy")
for i in range(30):
    if(beh[i_Si,i,0,0]>75 and beh[i_Si,i,6,1]>75):
        list_suc.append(i+1)
"""

        
"""
rex=20
ver=0
thr=0.01
amp=1000
gefb=0.05
init_smp=10    
"""


"""
fda_curve=np.zeros((len(list_suc),7))

for inet in range(len(list_suc)):
    listLR=[]
    t_end =[]
    for i in range(7):
        tmp=gr.get_behav1(list_suc[inet],i*0.1,Si,rex,nsmp,ver,thr,amp,gefb)
        listLR.append(tmp[1]+tmp[2])
        t_end.append(list((np.array(tmp[3][listLR[i]])/10.0-init_smp).astype(np.int64)))
            
    
    pl.subplot(6,5,inet+1)
    tmp=np.load("fda%d-%g.npy1.npy" % (list_suc[inet],Si))
    tmp_curve=np.zeros(7)
    for i in range(7):
        tmp_curve[i]=-1*np.mean(tmp[i,listLR[i],t_end[i],0])
        
    tmp_scl  =np.max(tmp_curve)-np.min(tmp_curve)
    tmp_curve=tmp_curve-np.min(tmp_curve)
    pl.scatter(range(7),tmp_curve/tmp_scl)

    tmp_curve=beh[i_Si,list_suc[inet]-1,:,0]
    tmp_scl  =np.max(tmp_curve)-np.min(tmp_curve)
    tmp_curve=tmp_curve-np.min(tmp_curve)
    pl.plot(range(7),tmp_curve/tmp_scl)


"""
fp.main(0.3)
fp.main(0.5)
fp.main(0.6)

exit()


argv=sys.argv

suc_list=[18, 19, 20, 22, 24, 25, 30]
#suc_list=[21,22,23,24,25,26,27,28,29,30]
#inet=int(argv[1])
for inet in suc_list:
    fc.tmp13(inet,0.4,0.9,0.02,3)
exit()


flg=int(argv[1])
Si=float(argv[2])
scl=0.9
GEfb=0.02
nsmp=50
n_t_bin=60


if flg==0:
    inet=15
    fc.main(inet,Si,scl,GEfb)
    exit()
elif(flg==1 or flg==2):

    list_suc=[1,2,3,4,5,6,7,8,9,0]
    n_net=len(list_suc)

    if(flg==1):
        fda_curve=np.zeros((n_net,7,4))
        for i in range(n_net):
            fda=gr.get_pca_fda2(list_suc[i],Si,scl,GEfb,50)
            if(fda==1):
                fda_curve[i]=np.zeros((7,4))
                continue
            fda_curve[i][:,:2]=fda[0]
            for j in range(7):
                fda_curve[i][j,2]=len(fda[5][j])
                fda_curve[i][j,3]=len(fda[6][j])
        np.save("tmp1fda_curve%g%g%g.npy" % (Si,scl,GEfb), fda_curve)
        exit()
    elif(flg==2):
        gr.get_rate_allnet([Si,scl,GEfb,list_suc,nsmp,n_t_bin])
    exit()



list_Si=[4]
n_net=10
n_Si =len(list_Si)
n_smp=100
thr=0.005
amp=1000
gfb=0.05

beh=np.zeros((n_Si,n_net,7,2))

for i in range(n_net):
    for j in range(7):
        for k in range(n_Si):
            tmp=gr.get_behav1(i+1,0.1*j,round(0.1*list_Si[k],1),20,n_smp,0,thr,amp,gfb)
            beh[k,i,j,0]=len(tmp[1])
            beh[k,i,j,1]=len(tmp[2])

str="beh%g%g.npy" % (gfb,amp)
np.save(str,beh)

for i in range(n_Si):
    pl.subplot(n_Si,2,2*i+1)
    pl.plot(range(7),beh[i,:,:,0].T)
    pl.subplot(n_Si,2,2*i+2)
    pl.plot(range(7),beh[i,:,:,1].T)
    
pl.savefig("tmp%g_1_%g.eps" % (gfb,amp))
exit()

suc_list=[[],[],[],[],[]]

for i in range(n_Si):
    for j in range(n_net):
        if(beh[i,j,0,0]>75 and beh[i,j,6,1]>75):
            suc_list[i].append(j)

for i in range(n_Si):
    pl.subplot(5,2,i*2+1)
    pl.plot(range(7),beh[i,suc_list[i],:,0].T)
    pl.subplot(5,2,i*2+2)
    pl.plot(range(7),beh[i,suc_list[i],:,1].T)


pl.savefig("Fig151211-3.eps")
pl.clf()

for i in range(n_Si):
    pl.plot(range(7),np.mean(beh[i,suc_list[i],:,0],axis=0))


pl.savefig("Fig151211-4.eps")


