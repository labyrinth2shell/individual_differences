#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 14 09:06:57 2018

@author: kurikawa

For figures in final ver in the revised manuscript
update 2018.6.14
"""

import numpy as np
import pylab as pl
import random
import sys
from scipy import optimize
from scipy.ndimage import filters as flt
from scipy   import stats
import regression_revised as rg
import FDA as fda
import imp
from itertools import product
imp.reload(fda)
imp.reload(rg)



Nnet=50  # total num of networks including false net
Nboot=50
diff=0.05
Si=0.4
GEfb=0.02
normS=0.347   # sensitivity of linearly proportional psychometric curve
ntrial=50
npert=31
nnet=50

def gen_pre_data():   # generate common data
    #beh_all_T600.npy
    #paras.npy
    # behavior data
    """"  not yet built
    def gen_beh(suc_list,diff,Si,Tend,if_nofb):  # if_nofb was added 2018.6.3
    nsmp=len(suc_list)
    beh=[]
    for l in range(nsmp):
        beh.append([])
        for i in range(7):
            beh[l].append([])
            if not if_nofb:
                fname=get_file_name(["evk","t"],[inet,ipat,Si,scl,GEfb])
        if fname=="error in get_file_name!":
            return fname
                tmp=get_behav1(["normal","evk","_","_"],[suc_list[l],i*0.1,Si,0.9,0.02,ntrial,diff,Tend])
            else:
                tmp=get_behav1(["nofb","evk","_","_"],[suc_list[l],i*0.1,Si,0.9,0.02,ntrial,diff,Tend])
            beh[l][i].append(tmp[1])
            beh[l][i].append(tmp[2])
            beh[l][i].append(tmp[3])
            beh[l][i].append(tmp[4])
    
    return beh
    """""
    
    # success network list at T=600
    suc_list=[ 2,  3,  5,  6,  7,  8, 11, 13, 14, 15, 16, 18, 19, 20, 22, 23, 24,
           25, 26, 30, 31, 32, 36, 39, 40, 41, 43, 44, 46, 47, 49]
    # list for T=1000
#    suc_list=[ 2,  3,  5,  6,  7,  8,  9, 11, 12, 13, 14, 15, 16, 18, 19, 20, 22, 23, 24, 25, 26, 28, 30, 31, 32, 33, 34, 36, 39, 40, 41, 42, 43, 44,
#  46, 47, 49]
    beh_all=np.load("beh_all_T600.npy")
    suc_list=[]
    for inet in range(nnet):
        if len(beh_all[inet][0][0])+len(beh_all[inet][6][1]) > 80:
            suc_list.append(inet+1)
   
    # sensitivity S
    tmp_curve=gen_psycho_curve(beh_all,0.05,False)  # un-decided choices are stochastically assigned to either of L or R
    paras=np.zeros((len(suc_list),3))
    res=np.zeros(len(suc_list))
    for itmp in range(len(suc_list)):
        inet=suc_list[itmp]
        tmp=calc_type_psy(tmp_curve[inet-1][::-1])
        paras[itmp]=tmp[0]
        res[itmp]  =tmp[1]
    np.save("paras.npy",paras)
    
    ## gen rate*.npy
    for inet in suc_list:
        rate=[]
        for i in range(7):
            tmp=get_rate_all(["normal","evk","_","_"],[inet,i*0.1,Si,0.9,0.02,ntrial,diff])
            rate.append(tmp)
        rate=np.array(rate)
        np.save("rate_long%d0.4.npy"%inet,rate)

    return


def main(idx_fig,figver):
    # figver==1st:  1st submitted ver
    #       ==T1000:  figs for T1000 data
    #       ==T600:   figs for T600 data
        
    suc_listT600 =[ 2,  3,  5,  6,  7,  8, 11, 13, 14, 15, 16, 18, 19, 20, 22, 23, 24,
              25, 26, 30, 31, 32, 36, 39, 40, 41, 43, 44, 46, 47, 49]
    suc_listT1000=[ 2,  3,  5,  6,  7,  8,  9, 11, 12, 13, 14, 15, 16, 18, 19, 20, 22, 23, 
              24, 25, 26, 28, 30, 31, 32, 33, 34, 36, 39, 40, 41, 42, 43, 44,46, 47, 49]

    if idx_fig=="gen_psycho_curves":
        if figver=="1st":
            beh_all=np.load("beh_all_T600.npy")
            suc_list=suc_listT600
        tmp_curve=gen_psycho_curve(beh_all,diff,False)
        pl.figure()
        for inet in suc_list:
            pl.plot(np.arange(7,0,-1),tmp_curve[inet-1],c="gray")
        inet=7
        pl.plot(np.arange(7,0,-1),tmp_curve[inet-1],c="orange")
        inet=20
        pl.plot(np.arange(7,0,-1),tmp_curve[inet-1],c="purple")
        pl.scatter(np.arange(7,0,-1),np.mean(tmp_curve[np.array(suc_list)-1],axis=0),c="black",s=50)
            
    if idx_fig=="gen_sensitivity_netid":
        if figver=="1st":
            beh_all=np.load("beh_all_T600.npy")
            suc_list=suc_listT600
            paras=np.load("paras.npy")
        
        psy_curve=gen_psycho_curve(beh_all,0.05,False)
        paras_boot,res_boot,boot_curve=gen_sensitivity_netid(suc_list,beh_all,paras)
        #plt_sensitivity(paras,paras_boot,suc_list)
        paras2,paras2_boot=gen_diff_func_sensitivity(suc_list,psy_curve,boot_curve)
        return paras2,paras,paras2_boot,paras_boot,psy_curve,boot_curve
        plt_diff_fit_func(paras2,paras2_boot,paras,paras_boot)
        
    if idx_fig=="gen_PCA_dyn":
        inet=11
        rate=np.load("backup_data/rate_long%d0.4.npy" % inet)
        pc_dyn=gen_PCA_dyn(beh_all,inet,rate[:,:,:61,:])
        
        pl.plot(pc_dyn[0,0,:61,0],pc_dyn[0,0,:61,1])
        pl.plot(pc_dyn[0,1,:61,0],pc_dyn[0,1,:61,1])
        pl.plot(pc_dyn[1,0,:61,0],pc_dyn[1,0,:61,1])
        pl.plot(pc_dyn[1,1,:61,0],pc_dyn[1,1,:61,1])
    if idx_fig=="gen_reg_dyn":
        # inet=11,36,39 are used. other networks have quite small number of incorrect trials (1 or 0)  
        inet=11
        rate=np.load("backup_data/rate_long%d0.4.npy" % inet)
        prj,prj_pop=gen_reg_dyn(inet,beh_all,rate[:,:,:61,:])
        twin=range(0,60)
        plt_reg_dyn(prj,prj_pop,twin,beh_all,inet)
    if idx_fig=="gen_FDA_dyn":
        inet=20
        rate=np.load("backup_data/rate_long%d0.4.npy" % inet)
        if figver=="1st":
            tend=1000
            beh_all=np.load("beh_all.npy")
            paras=np.load("paras.npy")
            suc_list=suc_listT600
            nfda=80
        elif figver=="T600":
            tend=600
            beh_all=np.load("beh_all_T600.npy")
            paras=np.load("paras.npy")
            suc_list=suc_listT600
            nfda=75
            
        tmp20=get_FDA_dyn([beh_all[inet-1,:,0],beh_all[inet-1,:,1],beh_all[inet-1,:,2],rate,0,0,"_",tend,nfda])
        plt_FDA_dyn(tmp20,beh_all,inet)
    if idx_fig=="gen_FDA_pfm":
        if figver=="1st":
            tend=1000
            beh_all=np.load("beh_all.npy")
            paras=np.load("paras.npy")
            suc_list=suc_listT600
            nfda=80
        elif figver=="T1000":
            tend=1000
            beh_all=np.load("beh_all.npy")
            paras=np.load("parasT1000.npy")
            suc_list=suc_listT1000
            nfda=80
        elif figver=="T600":
            tend=600
            beh_all=np.load("beh_all_T600.npy")
            paras=np.load("paras.npy")
            suc_list=suc_listT600
            nfda=75
            
        pfm_all=gen_FDA_pfm(beh_all,tend,suc_list,nfda)
        plt_FDA_pfm(pfm_all,suc_list,paras)
    if idx_fig=="gen_pca_dyn_pert":
        if figver=="1st":
            beh_all=np.load("beh_all.npy")
            tend=1000
            
        inet=7
        pca_dyn,pca_pert,id_t_term_long=gen_PCA_dyn_pert(inet,beh_all,tend)
        iinit=18
        for ipat in range(7):
            pl.plot(pca_dyn[ipat,iinit,:id_t_term_long[ipat,iinit],0],pca_dyn[ipat,iinit,:id_t_term_long[ipat,iinit],1])
        pl.plot(pca_pert[iinit*npert+1:iinit*npert+5,:,0].T,pca_pert[iinit*npert:iinit*npert+5,:,1].T,c="gray")
        pl.plot(pca_pert[iinit*npert,:,0],pca_pert[iinit*npert,:,1],c="black",lw=3)
        #when inet=20, init=46 and 6 are used.
        """
        inet,iinit=20,46
        dist2[suc_list.index(inet),iinit,60]
        Out[12]: 0.17809994512423896
        
        inet,iinit=7,18
        dist2[suc_list.index(inet),iinit,60]
        Out[14]: 0.21561557309819745
        """

    if idx_fig=="gen_chi_numL":# Fig5
        if figver=="1st":
            beh_all=np.load("beh_all.npy")
            suc_list=suc_listT600
            
        gen_chi_numL(beh_all,"high",suc_list)
        gen_chi_numL(beh_all,"low",suc_list)
        #        (-0.274,7.56e-5)
        #        (-0.562,1.34e-21)

    if idx_fig=="gen_dist2_S":
        if figver=="1st":
            paras=np.load("paras.npy")
            dist2=np.load("dist2.npy")
        pl.scatter(np.mean(dist2[:,:,60],axis=1),paras[:,2]/normS)
        func_para,_=optimize.curve_fit(fit_func_line, np.mean(dist2[:,:,60],axis=1),paras[:,2]/normS, [0.0,0.0])
        pl.plot(np.arange(0.08,0.2,0.005),fit_func_line(np.arange(0.08,0.2,0.005),func_para[0],func_para[1]))
    if idx_fig=="gen_out_nofb":
        Tend=1000
        nsmp=50
        
        tmp=gen_behav("backup_data/rbt56_fb_rnd_norm11-300_l00.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205",False,nsmp,Tend,diff)
        tmpdyn=np.loadtxt("backup_data/rbt56_nofb_rnd_norm11-300_l00.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205")
        dyn=[[],[],[],[]]        
        for i in range(50):
            if i in tmp[1]:
                dyn[0].append(tmpdyn[601*i:601*(i+1),1]-tmpdyn[601*i:601*(i+1),2])        
            elif i in tmp[2]:
                dyn[1].append(tmpdyn[601*i:601*(i+1),1]-tmpdyn[601*i:601*(i+1),2])
        tmp=gen_behav("backup_data/rbt56_fb_rnd_norm11-300_l0.60.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205",False,nsmp,Tend,diff)
        tmpdyn=np.loadtxt("backup_data/rbt56_nofb_rnd_norm11-300_l0.60.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205")
        for i in range(50):
            if i in tmp[1]:
                dyn[2].append(tmpdyn[601*i:601*(i+1),1]-tmpdyn[601*i:601*(i+1),2])
            elif i in tmp[2]:
                dyn[3].append(tmpdyn[601*i:601*(i+1),1]-tmpdyn[601*i:601*(i+1),2])
        plt_out_nofb(dyn)
    if idx_fig=="lrn_speed":
        if figver=="1st":
            paras=np.load("paras.npy")
            suc_list=suc_listT600
            dist2=np.load("dist2.npy")
            
        tmpscore=np.zeros((50,300))
        avescore=np.zeros((50,280))
        for inet in range(50):
            tmp=np.loadtxt("dbs56_fb_rnd_norm_%d-Si0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % (inet+1))
            for i in range(300):
                if tmp[i,2]>0.:
                    tmpscore[inet,i]=1
                else:
                    tmpscore[inet,i]=0
            for i in range(300-20):
                avescore[inet,i]=np.mean(tmpscore[inet,i:i+20])
    
        t_reach=np.zeros(50)
        for inet in range(50):
            tmp=[t for t in range(280) if avescore[inet,t]>0.8]
            if len(tmp)>0:
                t_reach[inet]=min(tmp)
            else:
                t_reach[inet]=300
                
        
        pl.figure()
        pl.subplot(2,1,1)
        pl.scatter(paras[:,2]/normS,t_reach[np.array(suc_list)-1])
        func_para,_=optimize.curve_fit(fit_func_line, paras[:,2]/normS,t_reach[np.array(suc_list)-1], [0.0,0.0])
        pl.plot(np.arange(0,0.9,0.01),fit_func_line(np.arange(0,0.9,0.01),func_para[0],func_para[1]))
#        stats.pearsonr(paras[:,2]/0.347,t_reach[np.array(suc_list)-1])
#        Out[123]: (0.36177907727610931, 0.04551701750606002)
        pl.subplot(2,1,2)
        pl.scatter(np.mean(dist2[:,:,60],axis=1),t_reach[np.array(suc_list)-1])
        func_para,_=optimize.curve_fit(fit_func_line, np.mean(dist2[:,:,60],axis=1),t_reach[np.array(suc_list)-1], [0.0,0.0])
        pl.plot(np.arange(0.08,0.2,0.005),fit_func_line(np.arange(0.08,0.2,0.005),func_para[0],func_para[1]))
#stats.pearsonr(np.mean(dist2[:,:,60],axis=1),t_reach[np.array(suc_list)-1])
#Out[127]: (0.50668943941286881, 0.0036285118317569112)
                
    if idx_fig=="gen_dist2_var":  #Fig6A
        # variance analysis in model.
        if figver=="1st":
            beh_all=np.load("beh_all.npy")
            dist2=np.load("dist2.npy")
            suc_list=suc_listT600
            paras=np.load("paras.npy")
                   
        cr=np.load("cr1st002.npy")
        
        """ when genrate cr
        pccurve01=calc_expansion_pop1(suc_list,0.02,0.3,False,True,beh_all)  #False: only non-receiving neurons are used
        cr=np.zeros(len(suc_list))
        for inet in range(len(suc_list)):
            smp_cond=[itmp for itmp in range(14) if pccurve01[inet,itmp,0,4,0]>0] # check available conditions
            for icond in smp_cond:
                nozero=[itmp for itmp in range(99) if pccurve01[inet,icond,itmp,4,0]>1.0]  # nonzero is independent of stim idx
                tmp =np.mean(np.log(pccurve01[inet,icond,nozero,4,1]))
                tmp1=np.mean(np.log(pccurve01[inet,icond,nozero,4,0]))
                cr[inet]+=tmp/tmp1   # ratio between pre and post for a given condition
            cr[inet]/=float(len(smp_cond))
        """
        plt_dist2_var(dist2,cr,paras)
        
    if idx_fig=="gen_dist2":
        beh_long=np.load("beh_all.npy")    ###  here we used long ver of histroy of decision making
        npca=5
        dist2=np.zeros((len(suc_list),50,101))
        str_pert=0.1
    
        for idx_suc_list in range(len(suc_list)):
            inet=suc_list[idx_suc_list]
            pca_pert,pca_norm=fp.gen_rg_prj_dyn(inet,beh_long,npca,str_pert)
            t_terminated=(fp.get_behav1(["pert_tmp","_","t100",False],[inet,-1,0.4,0.9,0.02,50*31,0.05,str_pert,1001]))[3]
            t_max=(np.zeros(t_terminated.shape)).astype(int)
    
        ### calc. normalization factor  (D(L,R) in the manuscript)
            pca_adp=np.zeros((31*50,npca))
            for j in range(31*50):
                t_max[j]=int(t_terminated[j]/10)
                if t_max[j]==0:  
                    t_max[j]=100
                pca_adp[j]=pca_pert[j,t_max[j]]
            scl_pca=np.max(pca_adp,axis=0)-np.min(pca_adp,axis=0)
    
            for j in range(50):
                for t in range(100):
                    pca_adp=np.zeros((31,npca))
                    for i in range(31):
                        if t<t_max[31*j+i]:
                            pca_adp[i]=pca_pert[j*31+i,t,:]
                        else:
                            pca_adp[i]=pca_pert[j*31+i,t_max[31*j+i],:]
                    center_place=np.mean(pca_adp,axis=0)
                    dx2=0
                    for i in range(31):
                        tmpdist=np.sum((pca_adp[i,:]-center_place[:])*(pca_adp[i,:]-center_place[:]))
                        dx2+=np.sqrt(tmpdist)
                    dist2[idx_suc_list,j,t]=dx2/(31*np.sqrt(np.sum(scl_pca*scl_pca)))  # np.sum(sca_pca^2) -> np.sum
                
 
###############################################################
            
def plt_out_nofb(dyn):
    iax=0
    pl.errorbar(range(601),np.mean(np.array(dyn[iax]),axis=0),yerr=np.std(np.array(dyn[iax]),axis=0),c="b")
    iax=1
    pl.errorbar(range(601),np.mean(np.array(dyn[iax]),axis=0),yerr=np.std(np.array(dyn[iax]),axis=0),c="cyan")
    iax=2
    pl.errorbar(range(601),np.mean(np.array(dyn[iax]),axis=0),yerr=np.std(np.array(dyn[iax]),axis=0),c="magenta")
    iax=3
    pl.errorbar(range(601),np.mean(np.array(dyn[iax]),axis=0),yerr=np.std(np.array(dyn[iax]),axis=0),c="r")
  

         
def plt_dist2_var(dist2,cr,paras):
    pl.figure()
    pl.subplot(2,1,1)
    pl.scatter(np.mean(dist2[:,:,60],axis=1),cr)
    func_para,_=optimize.curve_fit(fit_func_line, np.mean(dist2[:,:,60],axis=1),cr, [0.0,0.0])
    pl.plot(np.arange(0.08,0.2,0.005),fit_func_line(np.arange(0.08,0.2,0.005),func_para[0],func_para[1]))
    pl.subplot(2,1,2)
    pl.scatter(cr,paras[:,2]/normS)
    func_para,_=optimize.curve_fit(fit_func_line, cr,paras[:,2]/normS, [0.0,0.0])
    pl.plot(np.arange(0.2,0.6,0.01),fit_func_line(np.arange(0.2,0.6,0.01),func_para[0],func_para[1]))
    """
    stats.pearsonr(cr[:],paras[:,2])
Out[303]: (0.65175061034387305, 7.131509504133074e-05)
stats.pearsonr(np.mean(dist2[:,:,60],axis=1),cr)
Out[304]: (0.72857798528642748, 3.3667827380050207e-06)
    """


    
    
def sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat):

    pcasmp=np.mean(rate[:,:,min(tsmp):max(tsmp)+1,tmpord[-ncell:]],axis=2)
    meanrate=np.zeros((ntrial,ncell))
    for icell in range(ncell):
        meanrate[:,icell]=pcasmp[ipat,:,icell]/np.mean(pcasmp[ipat,:,icell])
    PC=PCA(meanrate.reshape(ntrial,ncell))
    return PC


def calc_expansion_pop1(suc_list,thrs_ave,thrs_diff,use_all,if_choice,beh_all):
    max_npca=100
    n_min_trial=10
    ntsmp =11   # num of obeservation time points check point
    nnet=len(suc_list)
    if use_all:
        geta=0
    else:
        geta=2000
    nall=5000
    
    if not if_choice:
        pccurve=np.zeros((nnet,7,max_npca,5,ntsmp))
    else:
        pccurve=np.zeros((nnet,7*2,max_npca,5,ntsmp))

    for idx_suc_list in range(nnet):
        inet=suc_list[idx_suc_list]
        rate=np.load("backup_data/rate_long%d0.4.npy" % inet )  # check point rate_many -> rate_long
        beh=beh_all[inet-1]

        # pickup cells
        ## union of high firing cells for each time steps
        tmpc_list=set(range(nall-geta))
        for ipat in range(7):
                # before stim
            tsmp=range(5,10)
            if not if_choice:  # for trials with a same stimulus
                tmpmr=np.mean(rate[ipat,:,tsmp,geta:],axis=(0,1))
                tmpc_list=tmpc_list & set([icell for icell in range(nall-geta) if tmpmr[icell]>thrs_ave]) # check point thrs_ave-0.05->thrs_ave
            else:  #for trials with a same stimulus and choice.
                for iLR in range(2):
                    if len(beh[ipat][iLR])>=n_min_trial:
                        tmpmr=np.mean(rate[ipat,beh[ipat][iLR]][:,tsmp,geta:],axis=(0,1))
                        tmpc_list=tmpc_list & set([icell for icell in range(nall-geta) if tmpmr[icell]>thrs_ave]) # check point thrs_ave-0.05->thrs_ave

            
            # after stim
            tsmp=range(10,(ntsmp+1)*5)
            if not if_choice:
                tmpmr=np.mean(rate[ipat,:,tsmp,geta:],axis=(0,1))
                tmpc_list=tmpc_list & set([icell for icell in range(nall-geta) if tmpmr[icell]>thrs_ave]) # check point thrs_ave-0.05->thrs_ave
            else:
                for iLR in range(2):
                    if len(beh[ipat][iLR])>=n_min_trial:
                        tmpmr=np.mean(rate[ipat,beh[ipat][iLR]][:,tsmp,geta:],axis=(0,1))
                        tmpc_list=tmpc_list & set([icell for icell in range(nall-geta) if tmpmr[icell]>thrs_ave]) # check point thrs_ave-0.05->thrs_av
        print(len(tmpc_list))
        ## sampling rule 1: pickup highest firing neurons within tmpc_list
 
        ## sampling rules 2-5: pickup neurons showing largest differnce before and after  within tmpc_list
        if not if_choice:
            diff=np.zeros((nall-geta,7))
            for ipat in range(7):
                diff[:,ipat]=np.fabs(np.mean(rate[ipat,:,5:10,geta:],axis=(0,1))-np.mean(rate[ipat,:,10:(ntsmp+1)*5,geta:],axis=(0,1)))
        else:
            diff=np.zeros((nall-geta,7*2))
            for ipat in range(7):
                for iLR in range(2):
                    if len(beh[ipat][iLR])>=n_min_trial:
                        diff[:,ipat*2+iLR]=np.fabs(np.mean(rate[ipat,beh[ipat][iLR]][:,5:10,geta:],axis=(0,1))-np.mean(rate[ipat,beh[ipat][iLR]][:,10:(ntsmp+1)*5,geta:],axis=(0,1)))
                    else:
                        diff[:,ipat*2+iLR]=0   # for avoiding this condition
                    
        tsmp=range(5,(ntsmp+1)*5)    
        tmpord=np.argsort(np.mean(rate[:,:,tsmp,geta:],axis=(0,1,2)))
        tmpord=[icell for icell in tmpord if (icell in tmpc_list) and (max(diff[icell])>thrs_diff)] # a neuron showing large difference for (at least) one of condition 
        tmpord=np.array(tmpord)+geta
            
        print(len([itmp for itmp in tmpord if itmp<2000]),len([itmp for itmp in tmpord if itmp>=2000]))
        
        ncell=len(tmpord)
        if ncell>=50: 
            ncell=49
       
        if not if_choice:
            tsmp=range(5,10)
            for ipat in range(7):
                PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                pccurve[idx_suc_list,ipat,:ncell,4,0]=PC[0]
            tsmp=range(10,(ntsmp+1)*5)
            for ipat in range(7):
                PC=sub_calc_expansion_pop1(tmpord,tsmp,rate,ncell,ntrial,ipat)
                pccurve[idx_suc_list,ipat,:ncell,4,1]=PC[0]
        else:           
            tsmp=range(5,10)
            for ipat in range(7):
                for iLR in range(2):
                    if len(beh[ipat][iLR])>=n_min_trial:
                        PC=sub_calc_expansion_pop1(tmpord,tsmp,rate[:,beh[ipat][iLR]],ncell,len(beh[ipat][iLR]),ipat)
                        pccurve[idx_suc_list,ipat*2+iLR,:ncell,4,0]=PC[0]
                    else:
                        pccurve[idx_suc_list,ipat*2+iLR,0,4,0]=-1
            tsmp=range(10,(ntsmp+1)*5)
            for ipat in range(7):
                for iLR in range(2):
                    if len(beh[ipat][iLR])>=n_min_trial:
                        PC=sub_calc_expansion_pop1(tmpord,tsmp,rate[:,beh[ipat][iLR]],ncell,len(beh[ipat][iLR]),ipat)
                        pccurve[idx_suc_list,ipat*2+iLR,:ncell,4,1]=PC[0]
                    else:
                        pccurve[idx_suc_list,ipat*2+iLR,0,4,0]=-1
    return pccurve


 
def gen_chi_numL(beh_long,flg_fig,suc_list):
    id_msr=60   # timing of measruing effect of perturbations
    dist2=np.load("dist2.npy")
    ave_dist=np.mean(dist2[:,:,id_msr],axis=1)
    tmpord=np.argsort(ave_dist)
    if flg_fig=="high":
        smp_nets=tmpord[-5:]
    elif flg_fig=="low":
        smp_nets=tmpord[:5]
        
    tmphist=[]
    tmpnumL=[]
    for itmp in smp_nets: 
        inet=suc_list[itmp]
        numL=np.zeros(ntrial)
        list_non_dec=[]
        for i in range(ntrial):
            for ipat in range(7):
                if i in beh_long[inet-1][ipat][0]:
                    numL[i]+=1
                elif not i in beh_long[inet-1][ipat][1]: 
                    list_non_dec.append(i)
                    if random.random()<0.5:
                        numL[i]+=1
        numL=np.fabs(numL-3.5)
    
        list_dec=[i for i in range(ntrial) if not i in list_non_dec]
        tmphist+=list(dist2[itmp,list_dec,id_msr])
        tmpnumL+=list(numL[list_dec])
    

    pl.figure()
    pl.subplot(1,2,1)
    pl.scatter(tmpnumL,tmphist)
    func_para,_=optimize.curve_fit(fit_func_line, tmpnumL, tmphist, [0.0,0.0])
    pl.plot(np.arange(0.1,3.9,0.1),fit_func_line(np.arange(0.1,3.9,0.1),func_para[0],func_para[1]))
    pl.subplot(1,2,2)
    pl.hist(tmphist,bins=10)

    
    return



def gen_PCA_dyn_pert(inet,beh_all,tend):
    upca=20
    sig_flt=3
    npca=100
    id_end=int(tend/10)+1
    diff_local=0.095  ### caution!!  its not usual diff (=0.05)
    
    tmp_t=[]
    for ipat in range(7):
        fname="backup_data/rbt56_fb_rnd_norm%d-300_l%g0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" %(inet,ipat*0.1)
        tmp=gen_behav(fname,False,ntrial,tend,diff_local)
        tmp_t.append(tmp[3])   
    tmp_t=np.array(tmp_t)
    id_t_term_long=t2id(tmp_t,tend)
    
    rate=np.load("backup_data/rate_long%d0.4.npy" % inet)
    rate=rate[:,:,:id_end,:]

    PCs,tmp_ord=gen_PCs(inet,id_t_term_long,rate)
    
    # generate projection dynamics of rate and rate_pert
    pca_dyn=np.zeros((7,ntrial,id_end,upca))
    for i,j,k in product(range(ntrial),range(7),range(upca)):
        pca_dyn[j,i,:,k]=np.dot(PCs[1][k,:],rate[j,i,:,tmp_ord[-npca:]])
        
    rate_pert=load_rate_pert(inet,-1,id_end)[:,:id_end,tmp_ord[-npca:]]
    pca_pert=np.zeros((npert*ntrial,id_end,upca))
    for j,k in product(range(npert*ntrial),range(upca)):
        pca_pert[j,:,k]=np.dot(PCs[1][k,:],rate_pert[j,:,:].T)
    
    #  apply a gaussian fileter
    for i,j in product(range(npert*ntrial),range(upca)):        
        pca_pert[i,:,j]=flt.gaussian_filter(pca_pert[i,:,j],sig_flt)
    for i,j,k in product(range(ntrial),range(7),range(upca)):
        pca_dyn[j,i,:,k]=flt.gaussian_filter(pca_dyn[j,i,:,k],sig_flt)
            
            
    return  pca_dyn,pca_pert,id_t_term_long
        

def t2id(t_terminated,tend):
    tshape=t_terminated.shape
    tmp=t_terminated.reshape(-1,)
    tmp_t=[]
    for t in tmp:
        if t<0.001:  # in this trial, a decision is not made
            t=tend
        tmp_t.append(int(t/10))
    return np.array(tmp_t).reshape(tshape)



def load_rate_pert(inet,ipat,id_end):
    rate_pert=np.zeros((npert*ntrial,id_end,5000))
    rate_pert[:10*31]=np.load("rate_pert%d_%d-0.npy" % (inet,ipat))
    rate_pert[31*10:31*20]=np.load("rate_pert%d_%d-1.npy" % (inet,ipat))
    rate_pert[31*20:31*30]=np.load("rate_pert%d_%d-2.npy" % (inet,ipat))
    rate_pert[31*30:31*40]=np.load("rate_pert%d_%d-3.npy" % (inet,ipat))
    rate_pert[31*40:31*50]=np.load("rate_pert%d_%d-4.npy" % (inet,ipat))
    
    return rate_pert
 
        
def gen_PCs(inet,id_t_term,rate):
    npca=100
    #make samples
    for ipat in [0,6]:
        init=0
        if ipat==0:
            smp_pca=rate[ipat,init,:id_t_term[ipat][init]-1,:]  # in the last time step, firint rate must be zero. we exclude this data.
        else:
            smp_pca=np.vstack((smp_pca,rate[ipat,init,:id_t_term[ipat][init]-1,:]))
        for init in range(1,ntrial):
            smp_pca=np.vstack((smp_pca,rate[ipat,init,:id_t_term[ipat][init]-1,:])) 

    # select neurons
    tmp_ord=np.argsort(np.mean(smp_pca,axis=0))
    smp_pca=smp_pca[:,tmp_ord[-npca:]]

    PCs=PCA(smp_pca)

    return PCs,tmp_ord

def gen_FDA_pfm(beh_all,tend,suc_list,nfda):
    pfm=[]
    for inet in suc_list:
        rate=np.load("backup_data/rate_long%d0.4.npy" % inet)
        fdadyn=get_FDA_dyn([beh_all[inet-1][:,0],beh_all[inet-1][:,1],beh_all[inet-1][:,2],rate[:,:,:int(tend/10)+1],0,0,"_",tend,nfda])
        tmppfm=calc_pfm_FDA([beh_all[inet-1,:,0],beh_all[inet-1,:,1],beh_all[inet-1,:,2],fdadyn[2]])
        pfm.append(tmppfm)
    return pfm # check point
    pfm_all=np.zeros((len(suc_list),7))
    for i in range(len(suc_list)):
        for j in range(7):
            pfm_all[i,j]=len(pfm[i][0][j]+pfm[i][1][j])/len(pfm[i][0][j]+pfm[i][1][j]+pfm[i][2][j]+pfm[i][3][j])

    return pfm_all

def plt_FDA_pfm(pfm_all,suc_list,paras):
    
    pl.figure()
    pl.scatter(np.mean(pfm_all,axis=1),paras[:,2]/normS)
    pl.scatter(np.mean(pfm_all[4]),paras[4,2]/normS,color="g")
    pl.scatter(np.mean(pfm_all[13]),paras[13,2]/normS,color="r")
    pl.xlim(0.8,1)
        
        #stats.pearsonr(np.mean(pfm_all,axis=1),paras[:,2])
        #Out[660]: (-0.085943120657213157, 0.64573216454655558)
    pl.figure()
    pl.scatter(np.arange(7,0,-1),pfm_all[4],c="g",zorder=6,s=60,lw=0)   # inet=7
    pl.scatter(np.arange(7,0,-1),pfm_all[13],c="r",zorder=6,s=60,lw=0)  # inet=20
    pl.bar(np.arange(7,0,-1),np.mean(pfm_all,axis=0))
    
    return

 
def plt_FDA_dyn(tmp20,beh,inet):
    twin=range(len(tmp20[2][0]),0,-1)
    pl.figure()
    pl.plot(twin,np.mean(tmp20[2][beh[inet-1][0][0],:],axis=0))
    pl.plot(twin,np.mean(tmp20[2][beh[inet-1][0][1],:],axis=0))
    ipat=6
    pl.plot(twin,np.mean(tmp20[2][np.array(beh[inet-1][ipat][0])+ntrial*ipat,:],axis=0))
    pl.plot(twin,np.mean(tmp20[2][np.array(beh[inet-1][ipat][1])+ntrial*ipat,:],axis=0))

    pl.figure()
    pl.plot(twin,np.mean(tmp20[2][beh[inet-1][0][0],:],axis=0))
    ipat=6
    pl.plot(twin,np.mean(tmp20[2][np.array(beh[inet-1][ipat][1])+ntrial*ipat,:],axis=0))
    ipat=2
    pl.plot(twin,np.mean(tmp20[2][np.array(beh[inet-1][ipat][0])+ntrial*ipat,:],axis=0))
    pl.plot(twin,np.mean(tmp20[2][np.array(beh[inet-1][ipat][1])+ntrial*ipat,:],axis=0))
    
    return


def plt_reg_dyn(prj,prj_pop,twin,beh04,inet):

    coh=np.zeros((len(twin),2,2))
    for t in twin:
        coh[t-min(twin),:,0]=cohen_d(prj_pop[beh04[inet-1][0][0],0,t],prj_pop[np.array(beh04[inet-1][6][1])+ntrial,0,t])
        coh[t-min(twin),:,1]=cohen_d(prj_pop[beh04[inet-1][0][0],1,t],prj_pop[np.array(beh04[inet-1][6][1])+ntrial,1,t])    
    t_sig=[]
    iax=0    
    t_sig.append([t for t in range(len(twin)) if (coh[t,0,iax]-1.96*coh[t,1,iax])*(coh[t,0,iax]+1.96*coh[t,1,iax])>0])
    iax=1
    t_sig.append([t for t in range(len(twin)) if (coh[t,0,iax]-1.96*coh[t,1,iax])*(coh[t,0,iax]+1.96*coh[t,1,iax])>0])
        
    pl.figure()
    pl.subplot(2,1,1)
    iax=0
    tmpmax=np.max(prj[:,:,iax,twin])  
    for t in t_sig[iax]:
        pl.scatter(t+min(twin),tmpmax+1,c="black",s=10)
        
    if len(beh04[inet-1][0][0])!=0:
        pl.plot(range(len(twin)),prj[0,0,iax,twin],c="b")
        pl.scatter([10],prj[0,0,iax,10],c="black")
        RT=np.mean(beh04[inet-1][0][2][beh04[inet-1][0][0]])/10
        pl.scatter([int(RT)],prj[0,0,iax,int(RT)])
    if len(beh04[inet-1][0][1])!=0:
        pl.plot(range(len(twin)),prj[0,1,iax,twin],c="cyan")
        pl.scatter([10],prj[0,1,iax,10],c="black")
        RT=np.mean(beh04[inet-1][0][2][beh04[inet-1][0][1]])/10
        pl.scatter([int(RT)],prj[0,1,iax,int(RT)])
    if len(beh04[inet-1][6][0])!=0:
        pl.plot(range(len(twin)),prj[1,0,iax,twin],c="magenta")
        pl.scatter([10],prj[1,0,iax,10],c="black")
        RT=np.mean(beh04[inet-1][6][2][beh04[inet-1][6][0]])/10
        pl.scatter([int(RT)],prj[1,0,iax,int(RT)])
    if len(beh04[inet-1][6][1])!=0:
        pl.plot(range(len(twin)),prj[1,1,iax,twin],c="r")
        pl.scatter([10],prj[1,1,iax,10],c="black")
        RT=np.mean(beh04[inet-1][6][2][beh04[inet-1][6][1]])/10
        pl.scatter([int(RT)],prj[1,1,iax,int(RT)])
    
        
    pl.subplot(2,1,2)
    iax=1
    tmpmax=np.max(prj[:,:,iax,twin])  
    for t in t_sig[iax]:
        pl.scatter(t+min(twin),tmpmax+1,c="black",s=10)
    if len(beh04[inet-1][0][0])!=0:
        pl.plot(range(len(twin)),prj[0,0,iax,twin],c="b")
        pl.scatter([10],prj[0,0,iax,10],c="black")
        RT=np.mean(beh04[inet-1][0][2][beh04[inet-1][0][0]])/10
        pl.scatter([int(RT)],prj[0,0,iax,int(RT)])
    if len(beh04[inet-1][0][1])!=0:
        pl.plot(range(len(twin)),prj[0,1,iax,twin],c="cyan")
        pl.scatter([10],prj[0,1,iax,10],c="black")
        RT=np.mean(beh04[inet-1][0][2][beh04[inet-1][0][1]])/10
        pl.scatter([int(RT)],prj[0,1,iax,int(RT)])
    if len(beh04[inet-1][6][0])!=0:
        pl.plot(range(len(twin)),prj[1,0,iax,twin],c="magenta")
        pl.scatter([10],prj[1,0,iax,10],c="black")
        RT=np.mean(beh04[inet-1][6][2][beh04[inet-1][6][0]])/10
        pl.scatter([int(RT)],prj[1,0,iax,int(RT)])
    if len(beh04[inet-1][6][1])!=0:
        pl.plot(range(len(twin)),prj[1,1,iax,twin],c="r")
        pl.scatter([10],prj[1,1,iax,10],c="black")
        RT=np.mean(beh04[inet-1][6][2][beh04[inet-1][6][1]])/10
        pl.scatter([int(RT)],prj[1,1,iax,int(RT)])
        
    return


def gen_reg_dyn(inet,beh_all,rate):
    beh04=beh_all
    
    prj,prj_pop=rg.main([rate,beh04[inet-1][:,:2],inet,"_"],["evk","evk",False,False,False])
    
    return prj,prj_pop

    
    
    
    

def gen_PCA_dyn(beh,inet,rate):
    npca=10
    
    tmp=rg.main([rate,beh[inet-1][:,:2],inet,"_"],["evk","get_PCA",False,False,False])
   
    ave_dyn=np.zeros((2,2,61,100))
    ave_dyn[0,0]=np.mean(tmp[1][beh[inet-1][0][0],:,:],axis=0)
    ave_dyn[0,1]=np.mean(tmp[1][beh[inet-1][0][1],:,:],axis=0)
    ave_dyn[1,0]=np.mean(tmp[1][np.array(beh[inet-1][6][0])+ntrial,:,:],axis=0)
    ave_dyn[1,1]=np.mean(tmp[1][np.array(beh[inet-1][6][1])+ntrial,:,:],axis=0)
    
    pc_dyn=np.zeros((2,2,61,npca))
    for i in range(2):
        for j in range(2):
            for k in range(npca):
                for t in range(61):
                    pc_dyn[i,j,t,k]=np.mean(tmp[0][1][k,:]*ave_dyn[i,j,t,:])
   
    return pc_dyn
    
    
    
def gen_sensitivity_netid(suc_list,beh_all,paras): # Fig2F in the revised manuscript
        
    tmp_boot_curve=np.zeros((Nboot,Nnet,7))
    for iboot in range(Nboot):
        tmp_boot_curve[iboot]=gen_psycho_curve(beh_all,diff,True)

    paras_boot=np.zeros((Nboot,len(suc_list),3))
    res_boot=np.zeros((Nboot,len(suc_list)))
    for iboot in range(Nboot):
        for itmp in range(len(suc_list)):
            inet=suc_list[itmp]
            tmp=calc_type_psy(tmp_boot_curve[iboot][inet-1][::-1])
            paras_boot[iboot,itmp]=tmp[0]
            res_boot[iboot,itmp]  =tmp[1]
            
    return paras_boot,res_boot,tmp_boot_curve

def plt_sensitivity(paras,paras_boot,suc_list):
    pl.figure()
    tmpidx=np.argsort(paras[:,2])
    for iboot in range(Nboot):
        pl.scatter(range(len(suc_list)),paras_boot[iboot,tmpidx,2]/normS,lw=0,s=3,c="gray")
    pl.scatter(range(len(suc_list)),paras[tmpidx,2]/normS,lw=0,s=50,c="black")

    pl.scatter([list(tmpidx).index(suc_list.index(7))],paras[suc_list.index(7),2]/normS,lw=0,s=50,c="orange")  # inet=6
    pl.scatter([list(tmpidx).index(suc_list.index(20))],paras[suc_list.index(20),2]/normS,lw=0,s=50,c="purple")  # inet=20
    pl.savefig("fig2F_rev.eps")


def gen_diff_func_sensitivity(suc_list,psy_curves,boot_curve):
    nnet=len(suc_list)
    
    # get optimal direction of psychometric curve
    res2=np.zeros(nnet)
    res21=np.zeros(nnet)
    for i in range(nnet):
        inet=suc_list[i]-1
        tmp=fit_psy1(psy_curves[inet][::-1])
        res2[i]=tmp[1]
        tmp=fit_psy1(np.ones(7)-psy_curves[inet])
        res21[i]=tmp[1]

    if_bias=np.zeros(nnet)
    for i in range(nnet):
        if res2[i]<res21[i]:
            if_bias[i]=0
        else:
            if_bias[i]=1
    # get fitting parameters
    tmp_bias_curve=np.zeros((nnet,7))    
    for i in range(nnet):
        inet=suc_list[i]-1
        if if_bias[i]==0:
            tmp=psy_curves[inet][::-1]
        else:
            tmp=np.ones(7)-psy_curves[inet]
        tmp_bias_curve[i]=(tmp-tmp[0])/(tmp[6]-tmp[0])
    
    paras2=np.zeros((nnet,2))
    for i in range(nnet):
        tmp=fit_psy1(tmp_bias_curve[i])
        paras2[i]=tmp[0]
        res2[i]=tmp[1]

    # get fitting parameters for resampling curves
    tmp_bias_boot_curve=np.zeros((Nboot,nnet,7))
    for i in range(nnet):
        inet=suc_list[i]-1
        if if_bias[i]==0:
            tmp=boot_curve[:,inet,::-1]
        else:
            tmp=np.ones((Nboot,7))-boot_curve[:,inet]
        for j in range(Nboot):
            tmp_bias_boot_curve[j,i]=(tmp[j]-tmp[j,0])/(tmp[j,6]-tmp[j,0])

    paras2_boot=np.zeros((Nboot,nnet,2))
    res2_boot=np.zeros((Nboot,nnet))
    for i in range(nnet):
        for j in range(Nboot):
            tmp=fit_psy1(tmp_bias_boot_curve[j,i])
            paras2_boot[j,i]=tmp[0]
            res2_boot[j,i]=tmp[1]

    return paras2,paras2_boot
       

def plt_diff_fit_func(paras2,paras2_boot,paras,paras_boot):
    nnet=len(paras2)
    pl.figure()
    tmpord=np.argsort(paras2[:,0]*paras2[:,1])
    pl.scatter(range(nnet),paras2[tmpord,0]*paras2[tmpord,1],c="r",s=50,lw=0,zorder=6)
    for i in range(50):
        pl.scatter(range(nnet),(paras2_boot[i,:,0]*paras2_boot[i,:,1])[tmpord],c="gray",lw=0,alpha=0.5)

    pl.figure()
    sd=np.std(paras_boot[:,:,2],axis=0)
    sd2=np.std(paras2_boot[:,:,0]*paras2_boot[:,:,1],axis=0)
    
    #pl.scatter(paras[:,2],paras2[:,0]*paras2[:,1])
    #for i in range(nnet):
    #    pl.errorbar(paras[i,2],paras2[i,0]*paras2[i,1],xerr=sd[i],yerr=sd2[i])
    
    err=np.zeros((nnet,2))
    err2=np.zeros((nnet,2))
    for i in range(nnet):
        err[i,0]=np.fabs(paras[i,2]-np.sort(paras_boot[:,i,2])[12])  #25%
        err[i,1]=np.fabs(paras[i,2]-np.sort(paras_boot[:,i,2])[37])  #75%
        err2[i,0]=np.fabs(paras2[i,0]*paras2[i,1]-np.sort(paras2_boot[:,i,0]*paras2_boot[:,i,1])[12])
        err2[i,1]=np.fabs(paras2[i,0]*paras2[i,1]-np.sort(paras2_boot[:,i,0]*paras2_boot[:,i,1])[37])

    pl.errorbar(paras[:,2]/normS,(paras2[:,0]*paras2[:,1]),xerr=(err[:,0]/normS,err[:,1]/normS),yerr=(err2[:,0],err2[:,1]),fmt="ro")

    return

   




################
################    functions
################
def calc_pfm_FDA(args):
    pfm=[]
    list_L  =np.copy(args[0])
    list_R  =np.copy(args[1])
    rtime_tmp=np.copy(args[2])
    FDA_data =np.copy(args[3])

    # convert to the same form as rat.
    list_tone=[]
    for i in range(7):
        list_tone.append(list(range(i*ntrial,(i+1)*ntrial)))
    list_LR=[[],[]]
    for i in range(7):
        for j in list_L[i]:
            list_LR[0].append(j+i*ntrial)
        for j in list_R[i]:
            list_LR[1].append(j+i*ntrial)

    rtime=rtime_tmp[0].astype(int)
    for i in range(1,7):
        rtime=np.hstack((rtime,rtime_tmp[i].astype(int)))
      
    tmplist=list(set(list_tone[0][:]) & set(list_LR[0]))
    tmplist1=list(set(list_tone[6][:]) & set(list_LR[0]))
    tmplistL=tmplist+tmplist1
        
    tmplist=list(set(list_tone[0][:]) & set(list_LR[1]))
    tmplist1=list(set(list_tone[6][:]) & set(list_LR[1]))
    tmplistR=tmplist+tmplist1

    smpL=FDA_data[tmplistL,0]
    smpR=FDA_data[tmplistR,0]
    theta_LR=(np.mean(smpL)+np.mean(smpR))/2.0

    CL=[]
    CR=[]
    FL=[]
    FR=[]
    for j in range(7):
        CL.append([])
        FL.append([])
        CR.append([])
        FR.append([])
        tmplistL=list(set(list_tone[j][:]) & set(list_LR[0]))
        tmplistR=list(set(list_tone[j][:]) & set(list_LR[1]))
        for i in tmplistL+tmplistR:
            if (FDA_data[i,0]-theta_LR)*(np.mean(smpL)-theta_LR)>0:
                if i in list_LR[0]:
                    CL[j].append(i)
                else:
                    FL[j].append(i)
            else:
                if i in list_LR[1]:
                    CR[j].append(i)
                else:
                    FR[j].append(i)
        
        
    pfm.append(CL)
    pfm.append(CR)
    pfm.append(FL)
    pfm.append(FR)

    return pfm


def FDA_anly(data1,data2):
    n_dim=len(data1)
    flg,J,W,cell_rank=fda.FDA2(data1,data2,range(n_dim),n_dim)
    
    return flg,J,W,cell_rank


def get_FDA_dyn(argset):  # tmp_FDA -> get_FDA_dyn
    list_L  =np.copy(argset[0])
    list_R  =np.copy(argset[1])
    rtime_tmp  =np.copy(argset[2])
    rate_tmp     =np.copy(argset[3])
    flg_tone =argset[4] # 1: discriminate high and low, 0: discriminate right and left
    t_bf_dec =argset[5]
    t_tone   =argset[6] # only when flg_tone is 1, t_tone is used
    t_over   =argset[7]  #[ms]
    ndim     =argset[8]  # ndim=80   #check point 2018.5.21   ndim=80->75 due to too small effective dim for inet=41  (Tend=600). 
    # previously, Tend=1000 is used.
    stimonset=100  #[ms]
    
    flg_sort =0   # 1: align by time 0, 0: align by decision time
    t_offset=10
    t_end   =len(rate_tmp[0,0])-t_offset

    tbin=10
   
    
    
    # convert to the form of rat.
    ttime=len(rate_tmp[0,0])
    tmp=rate_tmp.reshape(7*ntrial,ttime,5000)
    tmp=np.swapaxes(tmp,0,1)
    rate=np.swapaxes(tmp,0,2)

    list_tone=[]
    for i in range(7):
        list_tone.append(list(range(i*ntrial,(i+1)*ntrial)))
    list_LR=[[],[]]
    for i in range(7):
        for j in list_L[i]:
            list_LR[0].append(j+i*ntrial)
        for j in list_R[i]:
            list_LR[1].append(j+i*ntrial)

    
    rtime=rtime_tmp[0].astype(int)
    for i in range(1,7):
        rtime=np.hstack((rtime,rtime_tmp[i].astype(int)))
    for i in range(len(rtime)):
        if rtime[i]<=0.001:
            rtime[i]=t_over-stimonset  # modified 2016.12.26 -stimonset
        rtime[i]=rtime[i]-stimonset
        if rtime[i]<0.0:
            print("error too early response!!\n")
            return    
    
    for i in range(len(rate)):
        for j in range(len(rate[0])):
            rate[i,j,:]=flt.gaussian_filter(rate[i,j,:],3)
    
    # normalize rate
    tmplist=list_tone[0]+list_tone[6]
    tmpord=np.argsort(np.mean(rate[:,tmplist,:],axis=(1,2)))
    zs_rate=np.zeros((ndim,len(rate[0]),len(rate[0][0])))
    for i in range(ndim):
        itmp=tmpord[-ndim+i]
        zs_rate[i]=(rate[itmp]-np.mean(rate[itmp]))/np.std(rate[itmp])
    
    smpL=[]
    smpR=[]
    
    if flg_tone==1:
        for i in list_tone[6]:
            smpL.append(np.mean(zs_rate[:,i,t_offset+t_tone:t_offset+t_tone+tbin],axis=1))
        for i in list_tone[0]:
            smpR.append(np.mean(zs_rate[:,i,t_offset+t_tone:t_offset+t_tone+tbin],axis=1))
    else:
        for i in list(set(list_LR[0])&set(list_tone[6]))+list(set(list_LR[0])&set(list_tone[0])):
            if rtime[i]>=(t_end+t_bf_dec)*10:
                smpL.append(np.mean(zs_rate[:,i,-tbin:],axis=1))
            else:
                smpL.append(np.mean(zs_rate[:,i,int(rtime[i]/10)+t_offset-tbin-t_bf_dec:int(rtime[i]/10)+t_offset-t_bf_dec],axis=1))
        for i in list(set(list_LR[1])&set(list_tone[0]))+list(set(list_LR[1])&set(list_tone[6])):
            if rtime[i]>=(t_end+t_bf_dec)*10:
                smpR.append(np.mean(zs_rate[:,i,-tbin:],axis=1))
            else:
                smpR.append(np.mean(zs_rate[:,i,int(rtime[i]/10)+t_offset-tbin-t_bf_dec:int(rtime[i]/10)+t_offset-t_bf_dec],axis=1))
    
    smpR=np.array(smpR)[:,:]
    smpL=np.array(smpL)[:,:]

    W=FDA_anly(smpL[:,:].T,smpR[:,:].T)
    
    if W[0]==1:
        print("error!! effective dimension is too small!")
        return W[3],smpL,smpR
    
    ntrial=len(rate[0])
    if flg_sort==1:
        rate_prj=np.zeros((ntrial,t_end+t_offset))
        for i in range(ntrial):
            rate_prj[i,:]=np.dot(W[2].T,zs_rate[:,i,:])
    else:
        min_t=int(np.min(rtime)/10)+t_offset
        rate_prj=np.zeros((ntrial,min_t))
            #for i in range(ntrial):
            #rate_prj[i,:]=np.dot(W[2].T,zs_rate[:,i,t_end-1+t_offset::-1])
        for i in range(len(rtime)):
            if rtime[i]>=(t_end+t_bf_dec)*10:
                rate_prj[i,:]=np.dot(W[2].T,zs_rate[:,i,t_end-1+t_offset:t_end-1+t_offset-min_t:-1])/len((W[2].T)[0])
            else:
                rate_prj[i,:]=np.dot(W[2].T,zs_rate[:,i,int(rtime[i]/10)+t_offset:int(rtime[i]/10)+t_offset-min_t:-1])/len((W[2].T)[0])

    return W[1],W[2],rate_prj



def cohen_d(x,y):
    nx=len(x)
    ny=len(y)
    dof=nx+ny-2
    d=(np.mean(x)-np.mean(y))/np.sqrt(((nx-1)*np.std(x,ddof=1)**2+(ny-1)*np.std(y,ddof=1)**2)/dof)
    sig_d=np.sqrt((nx+ny)/(nx*ny)  + d**2/(2*dof))
    return d,sig_d
    
def gen_psycho_curve(beh,diff,if_sample):
    nsmp=len(beh)

    tmp_curve3=np.zeros((nsmp,7))
    for i in range(nsmp):
        for j in range(7):
            nL=0
            nR=0
            if not if_sample:
                for k in range(ntrial):
                    if ((beh[i][j][3][k,0]-beh[i][j][3][k,1])/(2*diff)+0.5)>random.random():
                        nL+=1
                    else:
                        nR+=1
            else:
                for k in random.sample(range(ntrial),40):
                    if ((beh[i][j][3][k,0]-beh[i][j][3][k,1])/(2*diff)+0.5)>random.random():
                        nL+=1
                    else:
                        nR+=1
            tmp_curve3[i,j]=nL/float(nL+nR) # change nR -> nL  2016.12.21
    return tmp_curve3



def fit_func_line(x,a,b):
    return a+b*x



def fit_func(para,x):
    a=para[0]
    b=para[1]
    c=para[2]
    return c*np.tan((x/3.-a))+b

def resid_fit(para,x,y):
    res=y-fit_func(para,x)
    return res

def calc_type_psy(beh):
    para0=[1.1,10,0.5]
    res=optimize.leastsq(resid_fit,para0,args=(np.arange(7),beh[:]))
    return res[0],np.mean(np.abs(resid_fit(res[0],np.arange(7),beh[:])))





def fit_func1(para,x):
    a=para[0]
    b=para[1]
    return a*np.tan(b*x/6.)+(1-a*np.tan(b))

def resid_fit1(para,x,y):
    res=y-fit_func1(para,x)
    return res

def fit_psy1(beh):
    para0=[0.5,1.1]
    res=optimize.leastsq(resid_fit1,para0,args=(np.arange(7),beh[:]))
    return res[0],np.mean(np.abs(resid_fit1(res[0],np.arange(7),beh[:])))

def PCA(P):
    m = sum(P) / float(len(P))
    P_m = P - m
    l,v = np.linalg.eig( np.dot(P_m.T,P_m) )
    idx=l.argsort()
    l=l[idx][::-1]
    v=v[:,idx][:,::-1]
    return l,v.T

def get_file_name(flgs,paras):
    
    if flgs[0]=="normal":
        if len(paras)!=5:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl,GEfb)
        elif(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl,GEfb)
    elif flgs[0]=="nofb":
        if len(paras)!=5:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb]=paras
        if(flgs[1]=="r"):
            str="rbr56_nofb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl,GEfb)
        elif(flgs[1]=="t"):
            str="rbt56_nofb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt1_21hb205" % (inet,ipat,Si,scl,GEfb)
    elif(flgs[0]=="tmp_t"):
        [inet,ipat,Si,scl,GEfb]=paras
        str="tmp_dbt56_fb_rnd_norm_%d%d-Si0.40.9-0.03101000-500.0050.020.020.51.2.rnd.txt1_21hb205" % (inet,ipat)
    elif flgs[0]=="weak":
        if len(paras)!=5:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_weak751_21hb205" % (inet,ipat,Si,scl,GEfb)
        elif(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_weak751_21hb205" % (inet,ipat,Si,scl,GEfb)
    elif flgs[0]=="many":
        if len(paras)!=5:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_many1_21hb205" % (inet,ipat,Si,scl,GEfb)
        elif(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_many1_21hb205" % (inet,ipat,Si,scl,GEfb)
    elif flgs[0]=="pert":
        if len(paras)!=6:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,str_pert]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txt_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
    elif flgs[0]=="pert_tmp":
        if len(paras)!=6:
            return "error in %s!" % sys._getframe().f_code.co_name
        [inet,ipat,Si,scl,GEfb,str_pert]=paras
        if(flgs[1]=="r"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t200"):
        #            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp1_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp3_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t150"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp2_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t250"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp4_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t300"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp5_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="t100"):
            if(str_pert==0.1 and inet<=30):
                str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp1_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
            else:
                str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        # this file data is identical as *txttmp11_pert*
        if(flgs[1]=="t100_add"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        # this file includes only init 50-99. this is only for two networks histgram in Fig.7
        if(flgs[1]=="rt100"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g0" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_1"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g10" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_2"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g20" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_3"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g30" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_4"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g40" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_5"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g50" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_6"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g60" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_7"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g70" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_8"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g80" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="rt100_9"):
            str="rbr56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp11_pert1_21hb205%g90" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="evkspnt150"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp21_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)
        if(flgs[1]=="evkspnt200"):
            str="rbt56_fb_rnd_norm%d-300_l%g%g%g-0.03101000-500.0050.02%g0.51.2.rnd.txttmp31_pert1_21hb205%g" % (inet,ipat,Si,scl,GEfb,str_pert)



    return str



def gen_behav(fname,if_trj,nsmp,Tend,diff):  # <- get_behav1
    # set parameters
    cnt=0
    behav_ind=np.zeros(nsmp)
    behav_list=[]
    colist=[]
    t_end=np.zeros(nsmp)
    state_end=np.zeros((nsmp,2))
    
    tmp=np.loadtxt(fname)
    tmptmp=tmp[0,:3]
    
    if if_trj:
        tmp_trj=[]
    
    for i in range(len(tmp[:,0])):       # store 1 trial into tmptmp
        if i>0 and tmp[i,0]<tmp[i-1,0]:  # detection of a new trial
            if if_trj:
                tmp_trj.append(tmptmp)
            for j in range(len(tmptmp)):
                if tmptmp[j,1] - tmptmp[j,2]>diff and tmptmp[j,0]<Tend:
                    t_end[cnt]=tmptmp[j,0]
                    behav_list.append(cnt)
                    break
                elif tmptmp[j,2] - tmptmp[j,1]>diff and tmptmp[j,0]<Tend:
                    t_end[cnt]=tmptmp[j,0]
                    colist.append(cnt)
                    break
            
            state_end[cnt][0]=tmptmp[j,1]
            state_end[cnt][1]=tmptmp[j,2]
            
            tmptmp=tmp[i,:3]
            cnt+=1
            if cnt>=nsmp:
                break
        
        elif i>0:  # store a trajectory of a al in tmptmp
            tmptmp=np.vstack((tmptmp,tmp[i,:3]))

    if cnt<=nsmp-1:
        if if_trj:
            tmp_trj.append(tmptmp)
        for j in range(len(tmptmp)):
            if tmptmp[j,1] - tmptmp[j,2]>diff and tmptmp[j,0]<Tend:
                t_end[cnt]=tmptmp[j,0]
                behav_list.append(cnt)
                break
            elif tmptmp[j,2] - tmptmp[j,1]>diff and tmptmp[j,0]<Tend:
                t_end[cnt]=tmptmp[j,0]
                colist.append(cnt)
                break
        state_end[cnt][0]=tmptmp[j,1]
        state_end[cnt][1]=tmptmp[j,2]
    del tmp

    if if_trj:
        return behav_ind,behav_list,colist,t_end,state_end,tmp_trj
    else:
        return behav_ind,behav_list,colist,t_end,state_end
